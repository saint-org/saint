import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class ProductViewTest {

    @Test
    public void testProductView() {
        // Test 1: User selects a product to view
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Catalog.action?productId=P123")
                .then()
                .statusCode(200)
                .body(is(notNullValue()));

        // Test 2: User views the product's associated items
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Catalog.action?itemId=item1")
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }
}

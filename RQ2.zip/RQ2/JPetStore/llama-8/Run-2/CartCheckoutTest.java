import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class CartCheckoutTest {

    @Test
    public void clearCart() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }

    @Test
    public void createANewOrder() {
        RestAssured.given()
                .queryParam("shippingAddressRequired", "False")
                .queryParam("serialVersionUID", "9876543210")
                .queryParam("orderId", "67890")
                .queryParam("username", "user2")
                .queryParam("orderDate", "2022-12-31")
                .queryParam("shipAddress1", "456 Elm St")
                .queryParam("shipAddress2", "Apt 202")
                .queryParam("shipCity", "Los Angeles")
                .queryParam("shipState", "CA")
                .queryParam("shipZip", "90001")
                .queryParam("shipCountry", "Canada")
                .queryParam("billAddress1", "456 Elm St")
                .queryParam("billAddress2", "Apt 202")
                .queryParam("billCity", "Los Angeles")
                .queryParam("billState", "CA")
                .queryParam("billZip", "90001")
                .queryParam("billCountry", "Canada")
                .queryParam("courier", "FedEx")
                .queryParam("totalPrice", "20.99")
                .queryParam("billToFirstName", "Jane")
                .queryParam("billToLastName", "Smith")
                .queryParam("shipToFirstName", "Jane")
                .queryParam("shipToLastName", "Smith")
                .queryParam("creditCard", "9876-5432-1098-7654")
                .queryParam("expiryDate", "06/2027")
                .queryParam("cardType", "Mastercard")
                .queryParam("locale", "fr-CA")
                .queryParam("status", "shipped")
                .when()
                .get("http://localhost:9080/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }
}

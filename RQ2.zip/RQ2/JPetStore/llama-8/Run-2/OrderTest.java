import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class OrderTest {

    @Test
    public void testCreateOrder() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500);
    }

    @Test
    public void testSelectOrderWithCorrectErrorHandling() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500);
    }

    @Test
    public void testDisplayOrderDetailsWithCorrectErrorHandling() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500);
    }
}

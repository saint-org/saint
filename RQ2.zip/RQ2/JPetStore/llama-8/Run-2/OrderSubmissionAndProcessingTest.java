import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class OrderSubmissionAndProcessingTest {

    @Test
    public void testClearCart() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .body(containsString("Exception thrown by application class 'net.sourceforge.stripes.controller.AnnotatedClassActionResolver.getDefaultHandler:632'"));
    }

    @Test
    public void testSubmitOrderToCartActionBean() {
        RestAssured.given()
                .queryParam("shippingAddressRequired", "True")
                .queryParam("serialVersionUID", "1234567890")
                .queryParam("orderId", "12345")
                .queryParam("username", "user1")
                .queryParam("orderDate", "2022-01-01")
                .queryParam("shipAddress1", "123 Main St")
                .queryParam("shipAddress2", "Apt 101")
                .queryParam("shipCity", "New York")
                .queryParam("shipState", "NY")
                .queryParam("shipZip", "10001")
                .queryParam("shipCountry", "USA")
                .queryParam("billAddress1", "123 Main St")
                .queryParam("billAddress2", "Apt 101")
                .queryParam("billCity", "New York")
                .queryParam("billState", "NY")
                .queryParam("billZip", "10001")
                .queryParam("billCountry", "USA")
                .queryParam("courier", "UPS")
                .queryParam("totalPrice", "10.99")
                .queryParam("billToFirstName", "John")
                .queryParam("billToLastName", "Doe")
                .queryParam("shipToFirstName", "John")
                .queryParam("shipToLastName", "Doe")
                .queryParam("creditCard", "1234-5678-9012-3456")
                .queryParam("expiryDate", "12/2025")
                .queryParam("cardType", "Visa")
                .queryParam("locale", "en-US")
                .queryParam("status", "pending")
                .when()
                .get("http://localhost:9080/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .body(containsString("Exception thrown by application class 'net.sourceforge.stripes.controller.AnnotatedClassActionResolver.getDefaultHandler:632'"));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestingOrderListAndView {

    @Test
    public void testGetListOfOrders() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500)
                .body(containsString("Exception thrown by application class 'net.sourceforge.stripes.controller.AnnotatedClassActionResolver.getDefaultHandler:632'"));
    }

    @Test
    public void testViewOrderDetailsWithErrorHandlingForOrderActionBean() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500)
                .body(containsString("Exception thrown by application class 'net.sourceforge.stripes.controller.AnnotatedClassActionResolver.getDefaultHandler:632'"));
    }
}

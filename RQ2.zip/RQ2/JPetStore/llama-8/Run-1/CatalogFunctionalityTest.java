import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class CatalogFunctionalityTest {

    @Test
    public void viewACategory() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Catalog.action?categoryId=cat1")
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }
}

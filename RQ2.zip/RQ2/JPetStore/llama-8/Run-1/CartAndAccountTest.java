import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class CartAndAccountTest {

    @Test
    public void testAddItemToCart() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Cart.action?workingItemId=item123")
                .then()
                .statusCode(500);
    }

    @Test
    public void testViewAccountInformation() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Account.action?serialVersionUID=1234567890&username=user123&password=password123&email=user%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%20101&city=New%20York&state=NY&zip=10001&country=USA&phone=123-456-7890&favouriteCategoryId=CAT1&languagePreference=English&listOption=true&bannerOption=true&bannerName=Banner1")
                .then()
                .statusCode(200);
    }

    @Test
    public void testVerifyAccountDetails() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Account.action?serialVersionUID=1234567890&username=user123&password=password123&email=user%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%20101&city=New%20York&state=NY&zip=10001&country=USA&phone=123-456-7890&favouriteCategoryId=CAT1&languagePreference=English&listOption=true&bannerOption=true&bannerName=Banner1")
                .then()
                .statusCode(200);
    }
}

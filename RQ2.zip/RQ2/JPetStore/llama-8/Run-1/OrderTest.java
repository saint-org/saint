import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class OrderTest {

    @Test
    public void placeANewOrder() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?shippingAddressRequired=True&serialVersionUID=1234567890&orderId=12345&username=user123&orderDate=2022-01-01&shipAddress1=123%20Main%20St&shipAddress2=Apt%20101&shipCity=New%20York&shipState=NY&shipZip=10001&shipCountry=USA&billAddress1=789%20Oak%20St&billAddress2=Apt%20202&billCity=Chicago&billState=IL&billZip=60601&billCountry=USA&courier=UPS&totalPrice=10.99&billToFirstName=John&billToLastName=Doe&shipToFirstName=Bob&shipToLastName=Johnson&creditCard=1234-5678-9012-3456&expiryDate=12/2025&cardType=Visa&locale=en-US&status=pending")
                .then()
                .statusCode(500)
                .body("error", is(notNullValue()));
    }

    @Test
    public void viewOrderHistory() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user123")
                .then()
                .statusCode(500)
                .body("error", is(notNullValue()));
    }

    @Test
    public void checkIfOrderExistsWithCorrectOrderId() {
        RestAssured.given()
                .get("http://localhost:9080/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .body("error", is(notNullValue()));
    }
}

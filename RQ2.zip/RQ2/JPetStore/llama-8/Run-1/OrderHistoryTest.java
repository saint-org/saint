import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class OrderHistoryTest {

    @Test
    public void testViewOrderHistory() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=admin")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }

    @Test
    public void testViewOrderDetails() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=admin")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }

    @Test
    public void testCheckIfOrderExists() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/jpetstore/actions/Order.action?username=user1")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }
}

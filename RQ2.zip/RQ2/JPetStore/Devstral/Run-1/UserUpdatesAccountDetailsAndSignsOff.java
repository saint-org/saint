import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserUpdatesAccountDetailsAndSignsOff {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void updateAccountDetailsAndSignOff() {
        // Update account details
        Response response = given()
                .when()
                .get("/actions/Account.action?serialVersionUID=1&username=user1&password=password123&email=user%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%201&city=New%20York&state=NY&zip=10001&country=USA&phone=123-456-7890&favouriteCategoryId=cat1&languagePreference=en&listOption=True&bannerOption=True&bannerName=banner1")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Sign off from the account
        response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify the response
        response.then()
                .body(equalTo("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"\n\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\n<head>\n<link rel=\"StyleSheet\" href=\"../css/jpetstore.css\" type=\"text/css\"\n\tmedia=\"screen\" />\n\n<meta name=\"generator\"\n\tcontent=\"HTML Tidy for Linux/x86 (vers 1st November 2002), see www.w3.org\" />\n<title>JPetStore Demo</title>\n<meta content=\"text/html; charset=windows-1252\"\n\thttp-equiv=\"Content-Type\" />\n<meta http-equiv=\"Cache-Control\" content=\"max-age=0\" />\n<meta http-equiv=\"Cache-Control\" content=\"no-cache\" />\n<meta http-equiv=\"expires\" content=\"0\" />\n<meta http-equiv=\"Expires\" content=\"Tue, 01 Jan 1980 1:00:00 GMT\" />\n<meta http-equiv=\"Pragma\" content=\"no-cache\" />\n</head>\n\n<body>\n\n<div id=\"Header\">\n\n<div id=\"Logo\">\n<div id=\"LogoContent\"><a href=\"/jpetstore/actions/Catalog.action\"><img src=\"../images/logo-topbar.gif\" /></a></div>\n</div>\n\n<div id=\"Menu\">\n<div id=\"MenuContent\"><a href=\"/jpetstore/actions/Cart.action?viewCart=\"><img align=\"middle\" name=\"img_cart\" src=\"../images/cart.gif\" /></a> <img align=\"middle\" src=\"../images/separator.gif\" /> \n\t<a href=\"/jpetstore/actions/Account.action?signonForm=\">Sign In</a>\n   <img align=\"middle\" src=\"../images/separator.gif\" /> <a\n\thref=\"../help.html\">?</a></div>\n</div>\n\n<div id=\"Search\">\n<div id=\"SearchContent\"><form method=\"post\" action=\"/jpetstore/actions/Catalog.action\">\n\t<input size=\"14\" name=\"keyword\" type=\"text\" />\n\t<input name=\"searchProducts\" type=\"submit\" value=\"Search\" />\n<div style=\"display: none;\"><input type=\"hidden\" name=\"_sourcePage\" value=\"2oynWgHpWO5Zz4qG9QXJ0wvlDwJopfXbVFC9TzwKAn2IiV-AhRyHYJROCOIOwtxOVlThcckrJNqCjj_HZiJghaEB1VM4zvDGL20pZrtI7vU=\" /><input type=\"hidden\" name=\"__fp\" value=\"d669C_-SkIeZool-kxT4eQ8M372Q8UYiApAQrWbcQoqQVCr8YAC0QxrohFvc1vju\" /></div></form></div>\n</div>\n\n<div id=\"QuickLinks\"><a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=FISH\"><img src=\"../images/sm_fish.gif\" /></a> <img src=\"../images/separator.gif\" /> <a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=DOGS\"><img src=\"../images/sm_dogs.gif\" /></a> <img src=\"../images/separator.gif\" /> <a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=REPTILES\"><img src=\"../images/sm_reptiles.gif\" /></a> <img src=\"../images/separator.gif\" /> <a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=CATS\"><img src=\"../images/sm_cats.gif\" /></a> <img src=\"../images/separator.gif\" /> <a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=BIRDS\"><img src=\"../images/sm_birds.gif\" /></a></div>\n\n</div>\n\n<div id=\"Content\">\n\n\n<div id=\"Catalog\"><form method=\"post\" action=\"/jpetstore/actions/Account.action\">\n\n\t<p>Please enter your username and password.</p>\n\t<p>Username:<input name=\"username\" id=\"stripes--788173733\" type=\"text\" /><script type=\"text/javascript\">setTimeout(function(){try{var z=document.getElementById('stripes--788173733');z.focus();z.select();}catch(e){}},1);</script> <br />\n\tPassword:<input name=\"password\" type=\"password\" value=\"j2ee\" /></p>\n\t<input name=\"signon\" type=\"submit\" value=\"Login\" />\n\n<div style=\"display: none;\"><input type=\"hidden\" name=\"_sourcePage\" value=\"AjTfLPGbHVU4YaxLjZB9BaB2bO3WobS7aMmulEdaJUBLZathwR5Y4WcC9ZT69BJy8mC5hoI5ioZOl9sYLrZsvYTWdYSTzvt9QdtcExUV7lE=\" /><input type=\"hidden\" name=\"__fp\" value=\"suOwpgnntWrpVr3LIGDQI8uDx6u34SKQWcPGaS9kKYPMkMzeyQ9ENMAPyUGpoU12\" /></div></form> Need a user name and password? <a href=\"/jpetstore/actions/Account.action?newAccountForm=\">Register Now!</a></div>\n\n\n</div>\n\n<div id=\"Footer\">\n\n<div id=\"PoweredBy\">&nbsp;<a href=\"http://www.mybatis.org\">www.mybatis.org</a>\n</div>\n\n<div id=\"Banner\"></div>\n\n</div>\n\n</body>\n</html>"));
    }
}

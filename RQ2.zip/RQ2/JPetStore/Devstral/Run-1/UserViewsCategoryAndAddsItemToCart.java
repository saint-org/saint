import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserViewsCategoryAndAddsItemToCart {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void userViewsCategoryAndAddsItemToCart() {
        // View category details
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?categoryId=Electronics")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add item to cart from Electronics category
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500);

        // View cart
        given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500);
    }
}

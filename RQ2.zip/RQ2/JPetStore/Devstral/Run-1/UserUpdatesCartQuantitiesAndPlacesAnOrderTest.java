import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserUpdatesCartQuantitiesAndPlacesAnOrderTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void testUserUpdatesCartQuantitiesAndPlacesAnOrder() {
        // View the cart
        Response response = given()
                .when()
                .get("/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Fix the issue with the CartActionBean and then update cart quantities
        response = given()
                .when()
                .get("/actions/Cart.action?itemId=12345&parameter=5")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Proceed to checkout
        response = given()
                .when()
                .get("/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Create a new order
        response = given()
                .when()
                .get("/actions/Order.action?shippingAddressRequired=true&serialVersionUID=1&orderId=1&username=user&orderDate=2023-01-01&shipAddress1=123%20Main%20St&shipAddress2=Apt%201&shipCity=New%20York&shipState=NY&shipZip=10001&shipCountry=USA&billAddress1=123%20Main%20St&billAddress2=Apt%201&billCity=New%20York&billState=NY&billZip=10001&billCountry=USA&courier=FedEx&totalPrice=100.00&billToFirstName=John&billToLastName=Doe&shipToFirstName=John&shipToLastName=Doe&creditCard=1234-5678-9012-3456&expiryDate=12/25&cardType=Visa&locale=en_US&status=Pending")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSignsInViewsOrderHistoryAndUpdatesAccountDetailsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserSignsInViewsOrderHistoryAndUpdatesAccountDetails() {
        // Redirect to signon form
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Sign on with valid credentials (username: j2ee, password: j2ee)
        response = given()
                .queryParam("username", "j2ee")
                .queryParam("password", "j2ee")
                .queryParam("favouriteCategoryId", "1")
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Retrieve order history
        response = given()
                .queryParam("username", "user123")
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Redirect to edit account form
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Update account details
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

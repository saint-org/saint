import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class UserSearchesForProductsAndViewsItemDetails {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 9080;
    }

    @Test
    public void testUserSearchesForProductsAndViewsItemDetails() {
        // Search for products based on a keyword
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .body(containsString("JPetStore Demo"))
                .extract()
                .response();

        // View item details for a specific product
        given()
                .when()
                .get("/jpetstore/actions/Catalog.action?itemId=12345")
                .then()
                .statusCode(200)
                .body(containsString("JPetStore Demo"));
    }
}

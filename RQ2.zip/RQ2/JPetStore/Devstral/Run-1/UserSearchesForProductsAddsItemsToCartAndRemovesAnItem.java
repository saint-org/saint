import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class UserSearchesForProductsAddsItemsToCartAndRemovesAnItem {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserSearchesForProductsAddsItemsToCartAndRemovesAnItem() {
        // Search for products based on a keyword
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?keyword=apple")
                .then()
                .statusCode(200)
                .body(containsString("JPetStore Demo"))
                .extract()
                .response();

        // Add an item to the cart by searching for 'apple'
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"));

        // Remove an item from the cart
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"));

        // View the updated cart
        given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"));
    }
}

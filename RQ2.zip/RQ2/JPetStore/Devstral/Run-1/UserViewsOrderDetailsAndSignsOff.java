import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class UserViewsOrderDetailsAndSignsOff {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void testUserViewsOrderDetailsAndSignsOff() {
        // Retrieve list of orders for a specific user
        Response response = given()
                .when()
                .get("/actions/Order.action?username=user123")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // View order details for a specific order for user123
        response = given()
                .when()
                .get("/actions/Order.action?username=user123")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Sign off the user
        response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

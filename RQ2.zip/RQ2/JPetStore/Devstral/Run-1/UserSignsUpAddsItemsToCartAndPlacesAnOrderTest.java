import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSignsUpAddsItemsToCartAndPlacesAnOrderTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void userSignsUpAddsItemsToCartAndPlacesAnOrder() {
        // Navigate to the sign-up page
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the sign-in form
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Browse the catalog
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a category
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?categoryId=Electronics")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a product
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?productId=12345")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View an item
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?itemId=12345")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add an item to the cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // View the cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Proceed to checkout
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Create a new order form
        response = given()
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Submit the order
        response = given()
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

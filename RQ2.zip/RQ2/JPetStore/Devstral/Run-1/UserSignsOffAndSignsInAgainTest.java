import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSignsOffAndSignsInAgainTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void userSignsOffAndSignsInAgain() {
        // Sign off the user
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Navigate to sign-in page
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Sign in the user with username and password
        response = given()
                .queryParam("username", "user")
                .queryParam("password", "password123")
                .queryParam("favouriteCategoryId", "1")
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserViewsProductDetailsAndAddsItemToCartTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 9080;
    }

    @Test
    public void testUserViewsProductDetailsAndAddsItemToCart() {
        // Navigate to the catalog page
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Select a category from the list of categories
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?categoryId=Electronics")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View product details by clicking on a product
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?productId=12345")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add item to cart by selecting the desired quantity and clicking 'Add to Cart'
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // View updated cart by clicking on the 'Cart' link
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserViewsOrdersAndUpdatesAccountInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void testUserViewsOrdersAndUpdatesAccountInformation() {
        // Retrieve a list of orders for a specific user
        Response response = given()
                .when()
                .get("/actions/Order.action?username=user1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Navigate to the 'Edit Account' form
        response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Update account information
        response = given()
                .when()
                .get("/actions/Account.action?serialVersionUID=1&username=user1&password=password123&email=user%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%201&city=New%20York&state=NY&zip=10001&country=USA&phone=123-456-7890&favouriteCategoryId=cat1&languagePreference=en&listOption=True&bannerOption=False&bannerName=banner1")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify the account information is updated
        response = given()
                .when()
                .get("/actions/Account.action?username=user1")
                .then()
                .statusCode(200)
                .body("username", equalTo("user1"))
                .body("password", equalTo("password123"))
                .body("email", equalTo("user@example.com"))
                .body("firstName", equalTo("John"))
                .body("lastName", equalTo("Doe"))
                .body("status", equalTo("active"))
                .body("address1", equalTo("123 Main St"))
                .body("address2", equalTo("Apt 1"))
                .body("city", equalTo("New York"))
                .body("state", equalTo("NY"))
                .body("zip", equalTo("10001"))
                .body("country", equalTo("USA"))
                .body("phone", equalTo("123-456-7890"))
                .body("favouriteCategoryId", equalTo("cat1"))
                .body("languagePreference", equalTo("en"))
                .body("listOption", equalTo("True"))
                .body("bannerOption", equalTo("False"))
                .body("bannerName", equalTo("banner1"))
                .extract()
                .response();
    }
}

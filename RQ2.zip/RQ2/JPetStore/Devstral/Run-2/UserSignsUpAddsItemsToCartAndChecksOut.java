import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class UserSignsUpAddsItemsToCartAndChecksOut {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void userSignsUpAddsItemsToCartAndChecksOut() {
        // Navigate to the sign-up form
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the sign-in form
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action?serialVersionUID=1&username=john_doe&password=securepassword123&email=john.doe%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%201&city=New%20York&state=NY&zip=10001&country=USA&phone=%2B12345678901&favouriteCategoryId=Electronics&languagePreference=en&listOption=True&bannerOption=False&bannerName=Welcome%20Banner")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Browse the catalog
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a category
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?categoryId=Electronics")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a product
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?productId=12345")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View an item
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?itemId=12345")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add an item to the cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Update cart quantities
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?itemId=12345&parameter=1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Proceed to checkout
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Process the new order
        response = given()
                .when()
                .get("/jpetstore/actions/Order.action?shippingAddressRequired=True&serialVersionUID=1&orderId=1001&username=john_doe&orderDate=2023-01-01&shipAddress1=123%20Main%20St&shipAddress2=Apt%201&shipCity=New%20York&shipState=NY&shipZip=10001&shipCountry=USA&billAddress1=123%20Main%20St&billAddress2=Apt%201&billCity=New%20York&billState=NY&billZip=10001&billCountry=USA&courier=FedEx&totalPrice=100.0&billToFirstName=John&billToLastName=Doe&shipToFirstName=John&shipToLastName=Doe&creditCard=1234567890123456&expiryDate=12/23&cardType=Visa&locale=en_US&status=Pending")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class UserViewsCategoryAddsItemsToCartAndRemovesItems {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testViewCategoryAndAddRemoveItems() {
        // View a specific category
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?categoryId=Electronics")
                .then()
                .statusCode(200)
                .body(containsString("Electronics"))
                .extract()
                .response();

        // View a specific product in the Electronics category
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action?productId=12345")
                .then()
                .statusCode(200)
                .body(containsString("12345"))
                .extract()
                .response();

        // Add items from the Electronics category to the cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=validItemId1")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"))
                .extract()
                .response();

        // Remove items from the Electronics category from the cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=valid_item_id")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"))
                .extract()
                .response();

        // View the cart with items from the Electronics category
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .body(containsString("No default handler could be found for ActionBean of type: org.mybatis.jpetstore.web.actions.CartActionBean"))
                .extract()
                .response();
    }
}

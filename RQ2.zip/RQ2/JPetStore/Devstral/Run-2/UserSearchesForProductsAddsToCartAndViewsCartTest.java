import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSearchesForProductsAddsToCartAndViewsCartTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserSearchesForProductsAddsToCartAndViewsCart() {
        // Search for products
        Response searchResponse = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add item to cart
        Response addToCartResponse = given()
                .when()
                .get("/jpetstore/actions/Cart.action?addItemToCart=validItemId1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // View cart
        Response viewCartResponse = given()
                .when()
                .get("/jpetstore/actions/Cart.action?viewCart=")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

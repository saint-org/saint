import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSignsOffAndSignsBackInTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void userSignsOffAndSignsBackIn() {
        // User signs out
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // User navigates to sign-in form
        response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // User signs in with username and password
        response = given()
                .queryParam("username", "user")
                .queryParam("password", "password123")
                .queryParam("favouriteCategoryId", "1")
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify the response contains the expected content
        response.then()
                .body("html.body.div#Content.div#Catalog.form.p", equalTo("Please enter your username and password."));
    }
}

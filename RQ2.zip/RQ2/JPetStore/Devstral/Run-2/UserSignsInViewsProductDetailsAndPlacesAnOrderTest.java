import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserSignsInViewsProductDetailsAndPlacesAnOrderTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserSignsInViewsProductDetailsAndPlacesAnOrder() {
        // Navigate to the sign-in form
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit sign-in form with credentials 'username': 'j2ee', 'password': 'j2ee'
        response = given()
                .queryParam("username", "j2ee")
                .queryParam("password", "j2ee")
                .queryParam("favouriteCategoryId", "1")
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View the main catalog
        response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a specific category
        response = given()
                .queryParam("categoryId", "Electronics")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View product details
        response = given()
                .queryParam("productId", "12345")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add item to cart
        response = given()
                .queryParam("workingItemId", "validItemId1")
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500) // Expected error due to invalid item ID
                .extract()
                .response();

        // View cart
        response = given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500) // Expected error due to invalid item ID
                .extract()
                .response();

        // Place an order
        response = given()
                .queryParam("shippingAddressRequired", "True")
                .queryParam("serialVersionUID", "1")
                .queryParam("orderId", "1")
                .queryParam("username", "j2ee")
                .queryParam("orderDate", "2023-01-01")
                .queryParam("shipAddress1", "123 Main St")
                .queryParam("shipAddress2", "Apt 1")
                .queryParam("shipCity", "New York")
                .queryParam("shipState", "NY")
                .queryParam("shipZip", "10001")
                .queryParam("shipCountry", "USA")
                .queryParam("billAddress1", "123 Main St")
                .queryParam("billAddress2", "Apt 1")
                .queryParam("billCity", "New York")
                .queryParam("billState", "NY")
                .queryParam("billZip", "10001")
                .queryParam("billCountry", "USA")
                .queryParam("courier", "FedEx")
                .queryParam("totalPrice", "100.0")
                .queryParam("billToFirstName", "John")
                .queryParam("billToLastName", "Doe")
                .queryParam("shipToFirstName", "John")
                .queryParam("shipToLastName", "Doe")
                .queryParam("creditCard", "1234567890123456")
                .queryParam("expiryDate", "12/23")
                .queryParam("cardType", "Visa")
                .queryParam("locale", "en_US")
                .queryParam("status", "Pending")
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(500) // Expected error due to invalid item ID
                .extract()
                .response();
    }
}

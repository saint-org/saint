import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class UserAddsItemsToCartAndUpdatesCartQuantitiesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserAddsItemsToCartAndUpdatesCartQuantities() {
        // View the main catalog page
        Response response = given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a specific category in the catalog
        response = given()
                .queryParam("categoryId", "Electronics")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // View a specific product in the catalog
        response = given()
                .queryParam("viewProduct", "validProductId1")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Add an item to the cart
        response = given()
                .queryParam("addItemToCart", "validItemId1")
                .when()
                .post("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Update the quantities of items in the cart
        response = given()
                .queryParam("updateCartQuantities", "validItemId1")
                .queryParam("quantity", "2")
                .when()
                .post("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // View the cart
        response = given()
                .queryParam("viewCart", "")
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UserEditsAccountInformationAndViewsUpdatedDetailsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void testUserEditsAccountInformationAndViewsUpdatedDetails() {
        // Navigate to the 'Edit Account' form
        Response response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Enter the username and password, then submit the form
        response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Navigate to the 'My Account' page
        response = given()
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

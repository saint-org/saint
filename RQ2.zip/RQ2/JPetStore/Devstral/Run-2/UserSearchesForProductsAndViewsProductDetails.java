import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class UserSearchesForProductsAndViewsProductDetails {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void searchForProductsAndViewProductDetails() {
        // Search for products based on a keyword
        Response response = given()
                .queryParam("keyword", "a")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .body(containsString("JPetStore Demo"))
                .extract()
                .response();

        // View details of a specific product by searching for 'a'
        given()
                .queryParam("productId", "12345")
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200)
                .body(containsString("JPetStore Demo"));
    }
}

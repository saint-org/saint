package com.example.jpetstore.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class UpdatingAccountDetailsAndPlacingOrderTest {

    private static final String BASE_URL = "http://localhost:9080/jpetstore";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void updatingAccountDetailsAndPlacingOrder() {
        // Call editAccountForm() to update account details
        given()
                .contentType(ContentType.URLENCODED)
                .param("username", "existing_username")
                .param("password", "existing_password")
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200);

        // Submit the form to update account details
        given()
                .contentType(ContentType.URLENCODED)
                .param("username", "existing_username")
                .param("password", "existing_password")
                .param("email", "existing_email")
                .param("firstName", "updated_first_name")
                .param("lastName", "updated_last_name")
                .param("status", "active")
                .param("address1", "updated_address1")
                .param("address2", "optional_address2")
                .param("city", "updated_city")
                .param("state", "updated_state")
                .param("zip", "updated_zip")
                .param("country", "updated_country")
                .param("phone", "updated_phone")
                .param("favouriteCategoryId", "existing_category_id")
                .param("languagePreference", "preferred_language")
                .param("listOption", "True")
                .param("bannerOption", "True")
                .param("bannerName", "updated_banner_name")
                .when()
                .get("/actions/Account.action")
                .then()
                .statusCode(200);

        // Add items to the cart
        given()
                .contentType(ContentType.URLENCODED)
                .param("workingItemId", "item1")
                .when()
                .get("/actions/Cart.action")
                .then()
                .statusCode(200);

        // Proceed to checkout (after resolving the StripesServletException)
        given()
                .contentType(ContentType.URLENCODED)
                .param("shippingAddressRequired", "True")
                .param("serialVersionUID", "a")
                .param("orderId", "1")
                .param("username", "existing_username")
                .param("orderDate", "current_date")
                .param("shipAddress1", "updated_address1")
                .param("shipAddress2", "optional_address2")
                .param("shipCity", "updated_city")
                .param("shipState", "updated_state")
                .param("shipZip", "updated_zip")
                .param("shipCountry", "updated_country")
                .param("billAddress1", "updated_address1")
                .param("billAddress2", "optional_address2")
                .param("billCity", "updated_city")
                .param("billState", "updated_state")
                .param("billZip", "updated_zip")
                .param("billCountry", "updated_country")
                .param("courier", "courier_name")
                .param("totalPrice", "total_cart_price")
                .param("billToFirstName", "updated_first_name")
                .param("billToLastName", "updated_last_name")
                .param("shipToFirstName", "updated_first_name")
                .param("shipToLastName", "updated_last_name")
                .param("creditCard", "credit_card_number")
                .param("expiryDate", "expiry_date")
                .param("cardType", "card_type")
                .param("locale", "preferred_language")
                .param("status", "pending")
                .when()
                .get("/actions/Order.action")
                .then()
                .statusCode(200);
    }
}

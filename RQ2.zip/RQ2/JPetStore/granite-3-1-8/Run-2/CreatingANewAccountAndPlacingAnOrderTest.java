package com.example.jpetstore.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class CreatingANewAccountAndPlacingAnOrderTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void creatingANewAccountAndPlacingAnOrder() {
        // Create a new owner
        Response response = given().get("/actions/Account.action").then().statusCode(200);
        response.then().assertThat("Homepage content", equalTo("<title>JPetStore Demo</title>"));

        // Submit new account form
        response = given().get("/actions/Account.action").then().statusCode(200);
        response.then().assertThat("New account form", equalTo("<form>"));

        // Sign on to the application
        response = given().param("username", "user1").param("password", "pass123").get("/actions/Account.action");
        response.then().statusCode(200);
        response.then().assertThat("Sign on form", equalTo("<form>"));

        // Add items to the cart
        response = given().get("/actions/Cart.action?workingItemId=item1");
        response.then().statusCode(500);
        response.then().assertThat("Error message", equalTo("Exception thrown by application class"));

        // Resolve the exception and proceed to checkout
        response = given().get("/actions/Cart.action");
        response.then().statusCode(500);
        response.then().assertThat("Error message", equalTo("Exception thrown by application class"));

        // Create a new order after resolving the exception
        response = given().get("/actions/Order.action");
        response.then().statusCode(500);
        response.then().assertThat("Error message", equalTo("Exception thrown by application class"));
    }
}

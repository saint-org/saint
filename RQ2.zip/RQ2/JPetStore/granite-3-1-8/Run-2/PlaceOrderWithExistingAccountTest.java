package com.example.jpetstore.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;

public class PlaceOrderWithExistingAccountTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore";
    }

    @Test
    public void placeOrderWithExistingAccount() {
        // Login with existing account
        Response response = given()
                .auth().preemptive().basic("user10", "password")
                .when()
                .get("/actions/Login.action")
                .then()
                .statusCode(200);

        // Checkout from the cart
        response = given()
                .when()
                .get("/actions/Cart.action")
                .then()
                .statusCode(500);

        // Create a new order with the correct ActionBean
        response = given()
                .when()
                .get("/actions/Order.action")
                .then()
                .statusCode(500);

        // View the order
        response = given()
                .when()
                .get("/actions/Order.action?username=user10")
                .then()
                .statusCode(500);
    }
}

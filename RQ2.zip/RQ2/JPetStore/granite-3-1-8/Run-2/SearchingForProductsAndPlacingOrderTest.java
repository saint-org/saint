package com.example.jpetstore.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsString;

public class SearchingForProductsAndPlacingOrderTest {

    private String baseUrl = "http://localhost:9080";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = baseUrl;
    }

    @Test
    public void searchingForProductsAndPlacingOrder() {
        // Search for products in the catalog
        given()
                .when()
                .get("/jpetstore/actions/Catalog.action?keyword=apple")
                .then()
                .statusCode(200)
                .body("html()", containsString("apple"));

        // Add a product to the cart (assuming the product is found and added successfully)
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=item1")
                .then()
                .statusCode(200)
                .body("html()", containsString("item1"));

        // Proceed to checkout (assuming the cart is not empty)
        given()
                .when()
                .get("/jpetstore/actions/Cart.action")
                .then()
                .statusCode(200)
                .body("html()", containsString("Checkout"));

        // Create a new order (assuming the checkout process is successful)
        given()
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(200)
                .body("html()", containsString("Order Confirmation"));
    }
}

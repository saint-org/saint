import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class SearchingForProductsAndAddingThemToCartTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void searchingForProductsAndAddingThemToCart() {
        // View catalog and search for products
        given()
                .when()
                .get("/jpetstore/actions/Catalog.action?keyword=apple")
                .then()
                .statusCode(200);

        // Add search results to cart
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=item1")
                .then()
                .statusCode(200);
    }
}

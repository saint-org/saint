package com.example.jpetstore.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class UpdatingAnAccountAndPlacingAnOrderTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.when().contentType(ContentType.JSON).accept(ContentType.JSON);
    }

    @Test
    public void updatingAnAccountAndPlacingAnOrder() {
        // Navigate to 'Edit account' page
        given().get("/jpetstore/actions/Account.action")
                .then().statusCode(200);

        // Update account details
        given().get("/jpetstore/actions/Account.action?serialVersionUID=a&username=user1&password=no-empty-string&email=no-empty-string-valid-email&firstName=no-empty-string-axu50ch&lastName=no-empty-string-axu50ch&status=no-empty-string-f%27acvd&address1=no-empty-string-axu10ch&address2=empty-string-axu10ch&city=no-empty-string-axu50ch&state=no-empty-string-axu50ch&zip=no-empty-string-valid-US-zip&country=no-empty-string-axu50ch&phone=no-empty-string-valid-hubf&favouriteCategoryId=no-empty-string-valid-cID&languagePreference=no-empty-string&listOption=boolean-value&bannerOption=boolean-value&bannerName=no-empty-string-axu50ch")
                .then().statusCode(200);

        // Navigate to 'Place a new order' page
        given().get("/jpetstore/actions/Order.action")
                .then().statusCode(500);

        // Navigate to 'Edit account' page and fill out order form, then submit
        given().get("/jpetstore/actions/Order.action?shippingAddressRequired=true&serialVersionUID=a&orderId=any%20positive%20integer&username=user1&orderDate=any%20valid%20date&shipAddress1=no-empty-string&shipAddress2=no-empty-string&shipCity=no-empty-string&shipState=no-empty-string&shipZip=no-empty-string-valid-zip&shipCountry=no-empty-string&billAddress1=no-empty-string&billAddress2=empty-string-axu10ch&billCity=no-empty-string-axu50ch&billState=no-empty-string-axu50ch&billZip=no-empty-string-valid-zip&billCountry=no-empty-string-axu50ch&courier=no-empty-string&totalPrice=any%20positive%20decimal%20value&billToFirstName=no-empty-string&billToLastName=no-empty-string-axu50ch&shipToFirstName=no-empty-string&shipToLastName=no-empty-string-axu50ch&creditCard=no-empty-string&expiryDate=any%20valid%20date&cardType=no-empty-string&locale=no-empty-string&status=Pending")
                .then().statusCode(500);

        // Navigate to 'View order' page and view order details
        given().get("/jpetstore/actions/Order.action?username=user1")
                .then().statusCode(500);

        // View order details
        given().get("/jpetstore/actions/Order.action?username=user1")
                .then().statusCode(500);
    }
}

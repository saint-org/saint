import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class ViewingProductDetailsAndAddingToCartTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.when().contentType(ContentType.HTML);
    }

    @Test
    public void viewingProductDetailsAndAddingToCart() {
        // View catalog and select a product
        given()
            .when()
            .get("/jpetstore/actions/Catalog.action")
            .then()
                .statusCode(200);

        // Add selected product to cart
        given()
            .when()
            .get("/jpetstore/actions/Cart.action?workingItemId=item1")
            .then()
                .statusCode(200);
    }
}

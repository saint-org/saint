package com.example.jpetstore.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsString;

public class CreatingANewAccountAndPlacingAnOrderTest {

    private static final String NEW_USERNAME = "newUsername";
    private static final String NEW_PASSWORD = "newPassword";
    private static final String NEW_EMAIL = "newEmail@example.com";
    private static final String NEW_FIRST_NAME = "newFirstName";
    private static final String NEW_LAST_NAME = "newLastName";
    private static final String NEW_ADDRESS1 = "newAddress1";
    private static final String NEW_CITY = "newCity";
    private static final String NEW_STATE = "newState";
    private static final String NEW_ZIP = "newZip";
    private static final String NEW_COUNTRY = "newCountry";
    private static final String NEW_PHONE = "newPhone";
    private static final String NEW_FAVOURITE_CATEGORY_ID = "newFavouriteCategoryId";
    private static final String NEW_BANNER_NAME = "newBannerName";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.when().contentType(ContentType.URLENCODED);
    }

    @Test
    public void creatingANewAccountAndPlacingAnOrder() {
        // Create a new account
        given()
                .when()
                .get("/jpetstore/actions/Account.action?serialVersionUID=a&username=" + NEW_USERNAME +
                        "&password=" + NEW_PASSWORD + "&email=" + NEW_EMAIL +
                        "&firstName=" + NEW_FIRST_NAME + "&lastName=" + NEW_LAST_NAME +
                        "&status=n&address1=" + NEW_ADDRESS1 + "&address2=newAddress2&city=" + NEW_CITY +
                        "&state=" + NEW_STATE + "&zip=" + NEW_ZIP + "&country=" + NEW_COUNTRY +
                        "&phone=" + NEW_PHONE + "&favouriteCategoryId=" + NEW_FAVOURITE_CATEGORY_ID +
                        "&languagePreference=d&listOption=True&bannerOption=True&bannerName=" + NEW_BANNER_NAME)
                .then()
                .statusCode(200);

        // Sign in with new account
        given()
                .when()
                .get("/jpetstore/actions/Account.action?username=" + NEW_USERNAME +
                        "&password=" + NEW_PASSWORD + "&favouriteCategoryId=" + NEW_FAVOURITE_CATEGORY_ID)
                .then()
                .statusCode(200);

        // View catalog
        given()
                .when()
                .get("/jpetstore/actions/Catalog.action")
                .then()
                .statusCode(200);

        // Add items to cart (Assuming items are added successfully)
        given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=item1")
                .then()
                .statusCode(200);

        // Resolve the exception and proceed to checkout (Assuming the exception is resolved)
        given()
                .when()
                .get("/jpetstore/actions/Order.action?shippingAddressRequired=True&serialVersionUID=a&orderId=&username=" + NEW_USERNAME +
                        "&orderDate=currentDate&shipAddress1=" + NEW_ADDRESS1 + "&shipAddress2=newAddress2&shipCity=" + NEW_CITY +
                        "&shipState=newState&shipZip=" + NEW_ZIP + "&shipCountry=" + NEW_COUNTRY +
                        "&billAddress1=" + NEW_ADDRESS1 + "&billAddress2=newAddress2&billCity=" + NEW_CITY +
                        "&billState=newState&billZip=" + NEW_ZIP + "&billCountry=" + NEW_COUNTRY +
                        "&courier=courierName&totalPrice=totalCost&billToFirstName=" + NEW_FIRST_NAME +
                        "&billToLastName=" + NEW_LAST_NAME + "&shipToFirstName=" + NEW_FIRST_NAME +
                        "&shipToLastName=" + NEW_LAST_NAME + "&creditCard=cardNumber&expiryDate=expiryDate&cardType=cardType&locale=locale&status=Pending")
                .then()
                .statusCode(200);

        // View order details after successful checkout
        given()
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(200);
    }
}

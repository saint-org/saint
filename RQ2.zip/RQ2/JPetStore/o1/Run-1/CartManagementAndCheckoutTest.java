package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

class CartManagementAndCheckoutTest {

    @Test
    void addItemToCartITEM001() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action?workingItemId=ITEM-001")
            .then()
            .statusCode(500);
    }

    @Test
    void addItemToCartSKU9999() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action?workingItemId=SKU-9999")
            .then()
            .statusCode(500);
    }

    @Test
    void addItemToCartABC123() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action?workingItemId=ITEM-001")
            .then()
            .statusCode(500);
    }

    @Test
    void viewCartContents() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action")
            .then()
            .statusCode(500);
    }

    @Test
    void updateCartQuantitiesI12345() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action?itemId=I-12345&parameter=alpha_num_123")
            .then()
            .statusCode(500);
    }

    @Test
    void removeItemABC123FromCart() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action?workingItemId=ABC123")
            .then()
            .statusCode(500);
    }

    @Test
    void fixCartActionBeanAndProceedToCheckout() {
        given()
            .when()
            .get("http://localhost:9080/jpetstore/actions/Cart.action")
            .then()
            .statusCode(500);
    }
}

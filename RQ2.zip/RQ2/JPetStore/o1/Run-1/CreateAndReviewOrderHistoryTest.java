import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateAndReviewOrderHistoryTest {

    @Test
    void signOnUserWithValidCredentials() {
        given()
            .log().all()
        .when()
            .get("http://localhost:9080/jpetstore/actions/Account.action?username=testUser123&password=Pa%24%24w0rd&favouriteCategoryId=FISH")
        .then()
            .log().all()
            .statusCode(200);
    }

    @Test
    void initializeNewOrderFromAccountAndCart() {
        given()
            .log().all()
        .when()
            .get("http://localhost:9080/jpetstore/actions/Order.action")
        .then()
            .log().all()
            .statusCode(500);
    }

    @Test
    void finalizeNewOrder() {
        given()
            .log().all()
        .when()
            .get("http://localhost:9080/jpetstore/actions/Order.action?shippingAddressRequired=False&serialVersionUID=123456789&orderId=10001&username=testUser123&orderDate=2023-09-01&shipAddress1=123%20Main%20St&shipAddress2=&shipCity=SampleCity&shipState=SC&shipZip=12345&shipCountry=USA&billAddress1=123%20Main%20St&billAddress2=&billCity=SampleCity&billState=SC&billZip=12345&billCountry=USA&courier=UPS&totalPrice=99.99&billToFirstName=John&billToLastName=Doe&shipToFirstName=John&shipToLastName=Doe&creditCard=1234567812345678&expiryDate=12/30&cardType=VISA&locale=en_US&status=new")
        .then()
            .log().all()
            .statusCode(500);
    }

    @Test
    void listAllOrdersForUser() {
        given()
            .log().all()
        .when()
            .get("http://localhost:9080/jpetstore/actions/Order.action?username=testUser123")
        .then()
            .log().all()
            .statusCode(500);
    }

    @Test
    void viewSpecificOrderDetails() {
        given()
            .log().all()
        .when()
            .get("http://localhost:9080/jpetstore/actions/Order.action?username=username123")
        .then()
            .log().all()
            .statusCode(500);
    }
}

package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class SearchAndBrowseProductsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void openMainLandingPage() {
        given()
        .when()
            .get("/jpetstore/actions/Catalog.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void searchForProductsUsingAKeyword() {
        given()
            .queryParam("keyword", "shoes")
        .when()
            .get("/jpetstore/actions/Catalog.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void viewProductsByCategory() {
        given()
            .queryParam("categoryId", "CAT001")
        .when()
            .get("/jpetstore/actions/Catalog.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void viewProductDetails() {
        given()
            .queryParam("productId", "PROD123")
        .when()
            .get("/jpetstore/actions/Catalog.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void viewItemDetails() {
        given()
            .queryParam("itemId", "FISH-1001")
        .when()
            .get("/jpetstore/actions/Catalog.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }
}

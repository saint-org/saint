package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserRegistration_SignOn_SignOffTest {

    static {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    @Order(1)
    void displaySignonPage() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Please enter your username and password."));
    }

    @Test
    @Order(2)
    void navigateToCreateNewAccountPage() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Need a user name and password?"));
    }

    @Test
    @Order(3)
    void createNewAccount() {
        given()
            .queryParam("username", "user123")
            .queryParam("password", "pass_1234")
            .queryParam("favouriteCategoryId", "CATS")
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("value=\"user123\""));
    }

    @Test
    @Order(4)
    void returnToSignonPage() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Please enter your username and password."));
    }

    @Test
    @Order(5)
    void signOnWithNewAccount() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Sign In"));
    }
}

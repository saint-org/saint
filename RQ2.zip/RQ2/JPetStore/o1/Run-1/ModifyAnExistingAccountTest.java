package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ModifyAnExistingAccountTest {

    static {
        // Optionally set the base URI if desired
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void signInWithValidCredentials() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action?username=johnDoe2023&password=mySecret1&favouriteCategoryId=CATS")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void signInWithCorrectCredentials() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }

    @Test
    void navigateToEditAccountForm() {
        given()
        .when()
            .get("/jpetstore/actions/Account.action?serialVersionUID=1&username=johnDoe2023&password=mySecret1&email=john.doe%40example.com"
                 + "&firstName=John&lastName=Doe&status=ACTIVE&address1=123%20Main%20St&address2=Apt%204B&city=Springfield&state=Illinois"
                 + "&zip=12345&country=USA&phone=%2B1-555-1234&favouriteCategoryId=CATS&languagePreference=en&listOption=True&bannerOption=False&bannerName=")
        .then()
            .statusCode(200)
            .body(containsString("JPetStore Demo"));
    }
}

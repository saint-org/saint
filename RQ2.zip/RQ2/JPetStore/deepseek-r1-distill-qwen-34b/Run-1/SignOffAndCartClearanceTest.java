import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class SignOffAndCartClearanceTest {

    @Test
    public void testUserLogoutAndCartClearance() {
        // Logout request
        Response response = given()
                .baseUri("http://localhost:9080")
                .basePath("/jpetstore/actions/Account.action")
                .when()
                .get();

        // Verify status code
        assertEquals(200, response.getStatusCode());

        // Verify response content
        String responseBody = response.getBody().asString();
        assertEquals(200, response.getStatusCode());
        assertEquals("text/html; charset=windows-1252", response.getHeader("Content-Type"));
        assertEquals("no-cache", response.getHeader("Cache-Control"));
        assertEquals("0", response.getHeader("expires"));
        assertEquals("no-cache", response.getHeader("Pragma"));
        assertEquals("Tue, 01 Jan 1980 1:00:00 GMT", response.getHeader("Expires"));
        
        // Verify HTML content
        response.then().body(containsString("<title>JPetStore Demo</title>"));
        response.then().body(containsString("<a href=\"/jpetstore/actions/Account.action?signonForm=\">Sign In</a>"));
        response.then().body(containsString("Please enter your username and password."));
    }
}

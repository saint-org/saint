import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ProductSearchAndAdditionToCart {

    private static String baseUrl = "http://localhost:9080/jpetstore/actions/";
    private static String productId = "productIdFromSearch"; // Placeholder for actual product ID

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = baseUrl;
    }

    @Test
    public void searchForSpecificProduct() {
        given()
            .contentType(ContentType.HTML)
        .when()
            .get("Catalog.action?keyword=specificProduct")
        .then()
            .statusCode(200)
            .body(containsString("Search for specificProduct"));
    }

    @Test
    public void viewProductDetails() {
        given()
            .contentType(ContentType.HTML)
        .when()
            .get("Catalog.action?productId=" + productId)
        .then()
            .statusCode(200)
            .body(containsString("Product Details"));
    }

    @Test
    public void addProductToCart() {
        given()
            .contentType(ContentType.HTML)
        .when()
            .get("Cart.action?workingItemId=" + productId)
        .then()
            .statusCode(500)
            .body(containsString("StripesServletException"));
    }

    @Test
    public void updateCartQuantities() {
        given()
            .contentType(ContentType.HTML)
        .when()
            .get("Cart.action?itemId=" + productId + "&parameter=newQuantity")
        .then()
            .statusCode(500)
            .body(containsString("StripesServletException"));
    }
}

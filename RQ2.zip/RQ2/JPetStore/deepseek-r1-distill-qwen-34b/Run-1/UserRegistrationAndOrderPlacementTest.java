import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UserRegistrationAndOrderPlacementTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void accessSignOnForm() {
        given()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Sign In"));
    }

    @Test
    public void clickRegisterNow() {
        given()
            .get("/jpetstore/actions/Account.action")
        .then()
            .statusCode(200)
            .body(containsString("Register Now!"));
    }

    @Test
    public void enterCredentialsAndLogin() {
        given()
            .get("/jpetstore/actions/Account.action?username=user123&password=Passw0rd%21&favouriteCategoryId=1")
        .then()
            .statusCode(200)
            .body(containsString("Welcome, user123"));
    }

    @Test
    public void addItemToCart() {
        given()
            .get("/jpetstore/actions/Cart.action?workingItemId=existingItemId")
        .then()
            .statusCode(200)
            .body(containsString("Your cart has been updated"));
    }

    @Test
    public void proceedToCheckout() {
        given()
            .get("/jpetstore/actions/Cart.action")
        .then()
            .statusCode(200)
            .body(containsString("Proceed to Checkout"));
    }

    @Test
    public void placeOrder() {
        given()
            .get("/jpetstore/actions/Order.action?shippingAddressRequired=True&serialVersionUID=1234567890123456789&orderId=12345&username=john_doe&orderDate=2023-10-05&shipAddress1=123%20Main%20St&shipAddress2=Apt%204B&shipCity=New%20York&shipState=NY&shipZip=10001&shipCountry=USA&billAddress1=789%20Elm%20St&billAddress2=Suite%207&billCity=Chicago&billState=IL&billZip=60601&billCountry=USA&courier=FedEx&totalPrice=%24100.00&billToFirstName=John&billToLastName=Doe&shipToFirstName=Alice&shipToLastName=Smith&creditCard=4111111111111111&expiryDate=12/25&cardType=Visa&locale=en_US&status=COMPLETED")
        .then()
            .statusCode(200)
            .body(containsString("Order Placed Successfully"));
    }

    @Test
    public void viewOrderHistory() {
        given()
            .get("/jpetstore/actions/Order.action?username=john_doe")
        .then()
            .statusCode(200)
            .body(containsString("Order History"));
    }
}

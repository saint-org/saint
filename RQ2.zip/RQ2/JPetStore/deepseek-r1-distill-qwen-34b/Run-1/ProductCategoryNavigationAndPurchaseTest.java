import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductCategoryNavigationAndPurchaseTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testViewMainCatalogPage() {
        Response response = get("/jpetstore/actions/Catalog.action");
        assertEquals(200, response.statusCode());
        response.body().asString().contains("<title>JPetStore Demo</title>");
        response.body().asString().contains("<img src=\"../images/logo-topbar.gif\" />");
    }

    @Test
    public void testViewSpecificCategory() {
        Response response = get("/jpetstore/actions/Catalog.action?categoryId=123");
        assertEquals(200, response.statusCode());
        response.body().asString().contains("<title>JPetStore Demo</title>");
        response.body().asString().contains("<a href=\"/jpetstore/actions/Catalog.action?viewCategory=&amp;categoryId=FISH\">");
    }

    @Test
    public void testAddItemToCart() {
        Response response = get("/jpetstore/actions/Cart.action?workingItemId=existingItemId");
        assertEquals(500, response.statusCode());
        response.body().asString().contains("StripesServletException");
        response.body().asString().contains("No default handler could be found for ActionBean");
    }

    @Test
    public void testProceedToCheckout() {
        Response response = get("/jpetstore/actions/Cart.action");
        assertEquals(500, response.statusCode());
        response.body().asString().contains("StripesServletException");
        response.body().asString().contains("No default handler could be found for ActionBean");
    }
}

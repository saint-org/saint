import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

public class AccountEditingAndOrderPlacementTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void navigateToAccountEditForm() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .extract().response();

        assertTrue(response.body().asString().contains("Sign In"));
    }

    @Test
    public void loginToAccount() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Account.action?serialVersionUID=1L&username=john_doe&password=SecurePass123%21&email=john.doe%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%205B&city=New%20York&state=NY&zip=10001&country=USA&phone=%2B1%20212%20555%201234&favouriteCategoryId=123&languagePreference=en&listOption=True&bannerOption=False&bannerName=banner1")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .extract().response();

        assertTrue(response.body().asString().contains("john_doe"));
    }

    @Test
    public void updateAccountDetails() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Order.action")
                .then()
                .statusCode(500)
                .contentType(ContentType.HTML)
                .extract().response();

        assertTrue(response.body().asString().contains("StripesServletException"));
    }

    @Test
    public void initializeNewOrder() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Order.action?shippingAddressRequired=True&serialVersionUID=1234567890123456789&orderId=12345&username=john_doe&orderDate=2023-10-05&shipAddress1=123%20Main%20St&shipAddress2=Apt%204B&shipCity=New%20York&shipState=NY&shipZip=10001&shipCountry=USA&billAddress1=789%20Elm%20St&billAddress2=Suite%207&billCity=Chicago&billState=IL&billZip=60601&billCountry=USA&courier=FedEx&totalPrice=%24100.00&billToFirstName=John&billToLastName=Doe&shipToFirstName=Alice&shipToLastName=Smith&creditCard=4111111111111111&expiryDate=12/25&cardType=Visa&locale=en_US&status=PENDING")
                .then()
                .statusCode(500)
                .contentType(ContentType.HTML)
                .extract().response();

        assertTrue(response.body().asString().contains("StripesServletException"));
    }
}

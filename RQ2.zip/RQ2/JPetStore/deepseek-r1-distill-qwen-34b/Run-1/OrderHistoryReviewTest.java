import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class OrderHistoryReviewTest {

    private static final String BASE_URL = "http://localhost:9080/jpetstore/actions/Order.action";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void retrieveOrderHistoryForUser() {
        // Send a GET request with the username parameter
        Response response = given()
                .contentType(ContentType.TEXT)
                .queryParam("username", "john_doe")
                .when()
                .get();

        // Verify the response status code
        assertEquals(500, response.getStatusCode(), "Status code should be 500");

        // Verify the response content
        String expectedResponse = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";
        assertEquals(expectedResponse, response.getBody().asString().substring(0, expectedResponse.length()),
                "Response should contain the expected HTML content");
    }

    @Test
    public void fixExceptionWhenViewingSpecificOrderDetails() {
        // Send a GET request with the username parameter
        Response response = given()
                .contentType(ContentType.TEXT)
                .queryParam("username", "john_doe")
                .when()
                .get();

        // Verify the response status code
        assertEquals(500, response.getStatusCode(), "Status code should be 500");

        // Verify the response content
        String expectedResponse = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";
        assertEquals(expectedResponse, response.getBody().asString().substring(0, expectedResponse.length()),
                "Response should contain the expected HTML content");
    }
}

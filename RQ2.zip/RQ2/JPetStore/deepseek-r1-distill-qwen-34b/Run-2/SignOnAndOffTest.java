import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.get;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SignOnAndOffTest {

    @Test
    public void testAccessSignOnForm() {
        Response response = get("http://localhost:9080/jpetstore/actions/Account.action");
        assertEquals(200, response.statusCode());
        assertTrue(response.body().asString().contains("<title>JPetStore Demo</title>"));
    }

    @Test
    public void testSubmitSignOnRequestWithCredentials() {
        Response response = get("http://localhost:9080/jpetstore/actions/Account.action?username=john_doe&password=%21%40%23%24%25%5E%26%2A&favouriteCategoryId=electronics");
        assertEquals(200, response.statusCode());
        assertTrue(response.body().asString().contains("<title>JPetStore Demo</title>"));
    }

    @Test
    public void testLogInToTheSystem() {
        Response response = get("http://localhost:9080/jpetstore/actions/Account.action");
        assertEquals(200, response.statusCode());
        assertTrue(response.body().asString().contains("<title>JPetStore Demo</title>"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

class AddingAndModifyingCartItemsTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void addProductToCart() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=FISH2")
                .then()
                .extract().response();

        assertEquals(500, response.statusCode());
        assertTrue(response.body().asString().contains("StripesServletException"));
    }

    @Test
    void updateQuantityOfItem() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?itemId=FISH2&parameter=updateQuantity")
                .then()
                .extract().response();

        assertEquals(500, response.statusCode());
        assertTrue(response.body().asString().contains("StripesServletException"));
    }

    @Test
    void ensureCartItemRemovalHandlerExists() {
        Response response = given()
                .when()
                .get("/jpetstore/actions/Cart.action?workingItemId=FISH2")
                .then()
                .extract().response();

        assertEquals(500, response.statusCode());
        assertTrue(response.body().asString().contains("StripesServletException"));
    }
}

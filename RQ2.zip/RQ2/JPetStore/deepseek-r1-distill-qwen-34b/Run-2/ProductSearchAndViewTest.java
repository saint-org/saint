import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ProductSearchAndViewTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080/jpetstore/actions/Catalog.action";
    }

    @Test
    @DisplayName("View the main catalog page")
    void testViewMainCatalogPage() {
        given()
            .when()
            .get()
            .then()
            .statusCode(200)
            .contentType("text/html; charset=windows-1252")
            .body(containsString("JPetStore Demo"))
            .body(containsString("<img src=\"../images/logo-topbar.gif\" />"))
            .body(containsString("<input name=\"keyword\" type=\"text\" />"));
    }

    @Test
    @DisplayName("Search for products using keywords")
    void testSearchProducts() {
        given()
            .queryParam("keyword", "example_keyword")
            .when()
            .get()
            .then()
            .statusCode(200)
            .contentType("text/html; charset=windows-1252")
            .body(containsString("JPetStore Demo"))
            .body(containsString("<input name=\"keyword\" type=\"text\" value=\"example_keyword\" />"));
    }

    @Test
    @DisplayName("Select a product category to view product details")
    void testViewProductDetails() {
        given()
            .queryParam("productId", "123")
            .when()
            .get()
            .then()
            .statusCode(200)
            .contentType("text/html; charset=windows-1252")
            .body(containsString("JPetStore Demo"))
            .body(containsString("<img src=\"../images/splash.gif\" />"));
    }
}

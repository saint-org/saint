import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class NewAccountCreationTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }

    @Test
    void retrieveNewAccountFormTest() {
        Response response = RestAssured.get("/jpetstore/actions/Account.action");
        
        response.then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(Matchers.containsString("Please enter your username and password."))
            .body(Matchers.containsString("Register Now!"));
    }

    @Test
    void submitNewAccountFormTest() {
        Response response = RestAssured.get(
            "/jpetstore/actions/Account.action?serialVersionUID=1234567890&username=newUser123&password=Passw0rd%21&email=newuser%40example.com&firstName=John&lastName=Doe&status=active&address1=123%20Main%20St&address2=Apt%204B&city=New%20York&state=NY&zip=10001&country=USA&phone=%2B1%20212%20555%201234&favouriteCategoryId=electronics&languagePreference=en&listOption=True&bannerOption=True&bannerName=banner1"
        );
        
        response.then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(Matchers.containsString("Login"))
            .body(Matchers.containsString("Register Now!"));
    }
}

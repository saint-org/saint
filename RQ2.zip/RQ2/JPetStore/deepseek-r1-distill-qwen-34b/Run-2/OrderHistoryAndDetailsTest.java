import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

class OrderHistoryAndDetailsTest {

    private static final String BASE_URL = "http://localhost:9080/jpetstore/actions/Order.action";
    private static final String USERNAME = "testuser123";

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    void testRetrieveOrderList() {
        Response response = given()
                .contentType(ContentType.HTML)
                .queryParam("username", USERNAME)
                .when()
                .get()
                .then()
                .extract()
                .response();

        // Verify status code
        assertEquals(500, response.statusCode());

        // Verify response content
        String responseBody = response.getBody().asString();
        assertTrue(responseBody.contains("StripesServletException"));
        assertTrue(responseBody.contains("No default handler could be found for ActionBean of type"));
    }

    @Test
    void testViewOrderDetails() {
        Response response = given()
                .contentType(ContentType.HTML)
                .queryParam("username", USERNAME)
                .when()
                .get()
                .then()
                .extract()
                .response();

        // Verify status code
        assertEquals(500, response.statusCode());

        // Verify response content
        String responseBody = response.getBody().asString();
        assertTrue(responseBody.contains("StripesServletException"));
        assertTrue(responseBody.contains("No default handler could be found for ActionBean of type"));
    }
}

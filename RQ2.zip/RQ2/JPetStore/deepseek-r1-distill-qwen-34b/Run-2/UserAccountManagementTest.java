import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserAccountManagementTest {

    @Test
    public void editAccountDetails() {
        RestAssured.baseURI = "http://localhost:9080";
        
        Response response = given()
            .queryParam("serialVersionUID", "1L")
            .queryParam("username", "testuser123")
            .queryParam("password", "TestP%40ssw0rd123")
            .queryParam("email", "test%40example.com")
            .queryParam("firstName", "John")
            .queryParam("lastName", "Doe")
            .queryParam("status", "active")
            .queryParam("address1", "123%20Main%20St")
            .queryParam("address2", "Apt%205B")
            .queryParam("city", "New%20York")
            .queryParam("state", "NY")
            .queryParam("zip", "10001")
            .queryParam("country", "USA")
            .queryParam("phone", "%2B1234567890")
            .queryParam("favouriteCategoryId", "123")
            .queryParam("languagePreference", "en")
            .queryParam("listOption", "True")
            .queryParam("bannerOption", "True")
            .queryParam("bannerName", "banner1")
            .when()
            .get("/jpetstore/actions/Account.action")
            .then()
            .extract().response();

        assertEquals(200, response.statusCode());
        assertEquals("text/html; charset=windows-1252", response.contentType());
    }

    @Test
    public void signInWithNewPassword() {
        RestAssured.baseURI = "http://localhost:9080";
        
        Response response = given()
            .queryParam("username", "testuser123")
            .queryParam("password", "TestP%40ssw0rd123")
            .queryParam("favouriteCategoryId", "123")
            .when()
            .get("/jpetstore/actions/Account.action")
            .then()
            .extract().response();

        assertEquals(200, response.statusCode());
        assertEquals("text/html; charset=windows-1252", response.contentType());
    }
}

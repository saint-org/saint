import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CategoryNavigationTest {

    @Test
    public void testViewMainCatalogPage() {
        given()
            .baseUri("http://localhost:9080/jpetstore/actions/Catalog.action")
        .when()
            .get()
        .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("<div id=\"QuickLinks\">"))
            .body(containsString("<div id=\"Search\">"));
    }

    @Test
    public void testSelectCategory() {
        given()
            .baseUri("http://localhost:9080/jpetstore/actions/Catalog.action")
            .queryParam("categoryId", "123")
        .when()
            .get()
        .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("<div id=\"SidebarContent\">"))
            .body(containsString("<div id=\"MainImage\">"));
    }

    @Test
    public void testViewIndividualProductDetails() {
        given()
            .baseUri("http://localhost:9080/jpetstore/actions/Catalog.action")
            .queryParam("productId", "123")
        .when()
            .get()
        .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("<div id=\"SidebarContent\">"))
            .body(containsString("<div id=\"MainImage\">"));
    }
}

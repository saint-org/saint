package com.example.petclinic.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

class CreatingANewOwnerAndAddingAPetTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
        RestAssured.when().contentType(ContentType.URLENCODED);
    }

    @Test
    void creatingANewOwnerAndAddingAPet() {
        // Initialize creation form for a new owner
        given().get("/owners/new")
                .then().statusCode(200);

        // Create a new owner
        given().contentType(ContentType.URLENCODED)
                .body("owner.lastName=validLastName")
                .body("owner.firstName=validFirstName")
                .body("owner.address=validAddress")
                .body("owner.city=validCity")
                .body("owner.telephone=1234567890")
                .when().post("/owners/new")
                .then().statusCode(200);

        // Initialize creation form for a new pet
        given().get("/owners/1/pets/new")
                .then().statusCode(200);

        // Create a new pet
        given().contentType(ContentType.URLENCODED)
                .body("pet.name=validPetName")
                .body("pet.birthDate=2020-01-01")
                .when().post("/owners/1/pets/new")
                .then().statusCode(200);
    }
}

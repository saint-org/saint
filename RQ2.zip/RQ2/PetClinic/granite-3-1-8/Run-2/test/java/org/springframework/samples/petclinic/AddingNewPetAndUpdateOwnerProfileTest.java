package com.example.petclinic.service;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

class AddingNewPetAndUpdateOwnerProfileTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    void addingNewPetAndUpdateOwnerProfile() {
        // Initialize creation form for a new pet
        Response response1 = given()
                .when()
                .get("/owners/1/pets/new")
                .then()
                .statusCode(200);

        // Create a new pet
        Response response2 = given()
                .when()
                .post("/owners/1/pets/new")
                .param("pet.name", "NewPetName")
                .param("pet.birthDate", "YYYY-MM-DD")
                .then()
                .statusCode(200);

        // Initialize update form for the owner
        Response response3 = given()
                .when()
                .get("/owners/1/edit")
                .then()
                .statusCode(200);

        // Update the owner's details
        Response response4 = given()
                .when()
                .post("/owners/1/edit")
                .param("owner.lastName", "NewLastName")
                .param("owner.firstName", "NewFirstName")
                .param("owner.address", "NewAddress")
                .param("owner.city", "NewCity")
                .param("owner.telephone", "1234567890")
                .then()
                .statusCode(302);
    }
}

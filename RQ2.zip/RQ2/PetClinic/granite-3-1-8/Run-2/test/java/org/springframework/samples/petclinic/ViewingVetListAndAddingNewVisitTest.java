import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class ViewingVetListAndAddingNewVisitTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080";
        RestAssured.when().contentType(ContentType.HTML);
    }

    @Test
    public void viewingVetListAndAddingNewVisit() {
        // Retrieve vet information
        given()
            .when()
            .get("/vets.html?page=1")
            .then()
                .statusCode(200)
                .body("h2", equalTo("Veterinarians"));

        // Initialize new visit form
        given()
            .when()
            .get("/owners/1/pets/1/visits/new")
            .then()
                .statusCode(200)
                .body("h2", equalTo("New Visit"));

        // Create new visit
        given()
            .when()
            .post("/owners/1/pets/1/visits/new")
            .param("owner.lastName", "Owner's Last Name")
            .param("owner.firstName", "Owner's First Name")
            .param("owner.address", "Owner's Address")
            .param("owner.city", "Owner's City")
            .param("owner.telephone", "Owner's Telephone")
            .param("visit.date", "2025-06-29")
            .param("visit.description", "Visit Description")
            .then()
                .statusCode(200)
                .body("h2", equalTo("New Visit"));
    }
}

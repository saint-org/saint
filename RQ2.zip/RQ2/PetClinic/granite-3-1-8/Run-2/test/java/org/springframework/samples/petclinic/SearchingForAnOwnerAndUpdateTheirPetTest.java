import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class SearchingForAnOwnerAndUpdateTheirPetTest {

    private static final String LAST_NAME = "Davis";
    private static final String OWNER_URL = "http://localhost:8080/owners";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void searchingForAnOwnerAndUpdateTheirPet() {
        // Initialize search form for owners
        Response searchFormResponse = given()
                .when()
                .get("/owners/find")
                .then()
                .statusCode(200);

        // Search for owner by last name
        Response searchResponse = given()
                .when()
                .get(OWNER_URL)
                .param("lastName", LAST_NAME)
                .then()
                .statusCode(200);

        // Initialize update form for owner
        Response updateFormResponse = given()
                .when()
                .get("/owners/updateForm/{id}", LAST_NAME)
                .then()
                .statusCode(200);

        // Update owner's details
        Response updateResponse = given()
                .when()
                .put("/owners/{id}", LAST_NAME)
                .param("firstName", "NewFirstName")
                .param("lastName", "Davis")
                .param("address", "NewAddress")
                .param("city", "NewCity")
                .param("telephone", "NewTelephone")
                .then()
                .statusCode(302);

        // Verify updated owner's details
        Response updatedOwnerResponse = given()
                .when()
                .get(OWNER_URL)
                .param("lastName", LAST_NAME)
                .then()
                .statusCode(200);

        // Assert updated owner's details
        Response.ResponseAssertions assertions = searchResponse.then();
        assertions.body("owners[0].firstName", equalTo("NewFirstName"));
        assertions.body("owners[0].lastName", equalTo("Davis"));
        assertions.body("owners[0].address", equalTo("NewAddress"));
        assertions.body("owners[0].city", equalTo("NewCity"));
        assertions.body("owners[0].telephone", equalTo("NewTelephone"));
    }
}

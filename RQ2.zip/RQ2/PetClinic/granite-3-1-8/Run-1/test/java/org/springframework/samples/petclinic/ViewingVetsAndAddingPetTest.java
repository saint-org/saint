package com.example.demo;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;

public class ViewingVetsAndAddingPetTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080";
        RestAssured.when().contentType(ContentType.HTML);
    }

    @Test
    public void viewVetList() {
        given()
            .when().get("/vets.html?page=1")
            .then()
                .statusCode(200)
                .body(containsString("Veterinarians"));
    }

    @Test
    public void navigateToPetCreationForm() {
        given()
            .when().get("/owners/1/pets/new")
            .then()
                .statusCode(200)
                .body(containsString("New Pet"));
    }

    @Test
    public void fillOutPetCreationForm() {
        given()
            .when()
                .post("/owners/1/pets/new")
                .param("pet.name", "newPetName")
                .param("pet.birthDate", "2020-01-01")
            .then()
                .statusCode(200)
                .body(containsString("is required"));
    }
}

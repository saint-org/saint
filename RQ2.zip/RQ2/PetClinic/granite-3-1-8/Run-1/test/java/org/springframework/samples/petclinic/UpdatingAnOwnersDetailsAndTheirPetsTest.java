package com.example.petclinic.controller;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

class UpdatingAnOwnersDetailsAndTheirPetsTest {

    private static final String BASE_URL = "http://localhost:8080";

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    void updatingAnOwnersDetailsAndTheirPets() {
        // Navigate to owner update form
        given()
                .when()
                .get("/owners/1/edit")
                .then()
                .statusCode(200);

        // Update owner details
        given()
                .multiPart("owner.firstName", "John")
                .multiPart("owner.lastName", "Doe")
                .multiPart("owner.address", "123 Main St")
                .multiPart("owner.city", "Anytown")
                .multiPart("owner.telephone", "1234567890")
                .contentType(ContentType.URLENCODED)
                .when()
                .post("/owners/1/edit")
                .then()
                .statusCode(302);

        // Navigate to pet update form
        given()
                .when()
                .get("/owners/1/pets/1/edit")
                .then()
                .statusCode(200);

        // Update pet details
        given()
                .multiPart("pet.name", "Fluffy")
                .multiPart("pet.birthDate", "1990-01-01")
                .contentType(ContentType.URLENCODED)
                .when()
                .post("/owners/1/pets/1/edit")
                .then()
                .statusCode(302);
    }
}

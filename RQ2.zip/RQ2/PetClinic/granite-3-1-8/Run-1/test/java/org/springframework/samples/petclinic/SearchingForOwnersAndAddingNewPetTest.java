import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class SearchingForOwnersAndAddingNewPetTest {

    private static final String OWNER_SEARCH_URL = "/owners/search";
    private static final String PET_CREATION_URL = "/owners/{ownerId}/pets";
    private static final String PET_NAME = "NewPet";
    private static final String PET_BIRTH_DATE = "2020-01-01";
    private static final String OWNER_LAST_NAME = "TestOwner";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void searchingForOwnersAndAddingNewPet() throws Exception {
        // Initiate owner search form
        given()
                .contentType(ContentType.JSON)
                .body("{\"lastName\": \"" + OWNER_LAST_NAME + "\"}")
                .when()
                .post(OWNER_SEARCH_URL)
                .then()
                .statusCode(200);

        // Find a specific owner
        String ownerId = getOwnerIdFromResponse(given().when().get(OWNER_SEARCH_URL).then().statusCode(200).response());

        // Navigate to pet creation form
        given()
                .contentType(ContentType.JSON)
                .body("{\"name\": \"" + PET_NAME + "\", \"birthDate\": \"" + PET_BIRTH_DATE + "\"}")
                .when()
                .post(PET_CREATION_URL.replace("{ownerId}", ownerId))
                .then()
                .statusCode(302); // Redirect to owner's detail page

        // Verify pet is added to the owner's list
        given()
                .when()
                .get(PET_CREATION_URL.replace("{ownerId}", ownerId))
                .then()
                .statusCode(200);
    }

    private String getOwnerIdFromResponse(com.github.tomakehurst.wiremock.client.Response response) {
        // Extract ownerId from the response
        // This is a placeholder method. You need to implement the actual extraction logic based on the response structure.
        return "123";
    }
}

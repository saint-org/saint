package com.example.petclinic.controller;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PetControllerTest {

    private static final String OWNER_ID = "1";
    private static final String PET_NAME = "NewPetName";
    private static final String PET_BIRTH_DATE = "2020-01-01";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void adding_a_new_pet_to_an_owner_list() {
        // Initialize pet creation form
        given()
            .when()
                .get("/owners/" + OWNER_ID + "/pets/new")
            .then()
                .statusCode(200);

        // Create a new pet
        given()
            .contentType(ContentType.URLENCODED)
            .body(String.format("pet.name=%s&pet.birthDate=%s", PET_NAME, PET_BIRTH_DATE))
            .when()
                .post("/owners/" + OWNER_ID + "/pets/new")
            .then()
                .statusCode(200);
    }
}

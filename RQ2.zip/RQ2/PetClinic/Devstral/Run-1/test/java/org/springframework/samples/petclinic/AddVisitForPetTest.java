import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddVisitForPetTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void testAddVisitForPet() {
        // Initialize new visit form
        Response response = given()
                .when()
                .get("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Process new visit form for pet Leo owned by George Franklin
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("owner.firstName", "George")
                .formParam("owner.lastName", "Franklin")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "Springfield")
                .formParam("owner.telephone", "1234567890")
                .formParam("visit.date", "2023-10-01")
                .formParam("visit.description", "Routine check-up")
                .when()
                .post("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body("html.body.h2", equalTo("New Visit"))
                .body("html.body.table tr td", equalTo("Leo"))
                .body("html.body.table tr td", equalTo("2010-09-07"))
                .body("html.body.table tr td", equalTo("cat"))
                .body("html.body.table tr td", equalTo("George Franklin"));
    }
}

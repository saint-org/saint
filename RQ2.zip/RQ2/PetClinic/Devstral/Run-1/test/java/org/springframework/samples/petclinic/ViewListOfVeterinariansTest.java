import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class ViewListOfVeterinariansTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testRetrievePaginatedListOfVeterinarians() {
        Response response = given()
                .queryParam("page", 1)
                .when()
                .get("/vets.html")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Veterinarians"))
                .body(containsString("James Carter"))
                .body(containsString("Helen Leary"))
                .body(containsString("Linda Douglas"))
                .body(containsString("Rafael Ortega"))
                .body(containsString("Henry Stevens"))
                .body(containsString("Pages:"))
                .body(containsString("1"))
                .body(containsString("2"))
                .body(containsString("fa fa-fast-backward"))
                .body(containsString("fa fa-step-backward"))
                .body(containsString("fa fa-step-forward"))
                .body(containsString("fa fa-fast-forward"))
                .extract()
                .response();

        // Additional assertions can be added here if needed
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FindAndShowOwnerDetailsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void findAndShowOwnerDetails() {
        // Initialize the find owner form
        Response response = given()
                .when()
                .get("/owners/find")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the find owner form
        response = given()
                .when()
                .get("/owners?page=1")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Show owner details
        response = given()
                .when()
                .get("/owners/1")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Validate owner details
        response.then()
                .body("html.body.h2", equalTo("Owner Information"))
                .body("html.body.table.table-striped.tr", hasSize(4))
                .body("html.body.table.table-striped.tr[0].th", equalTo("Name"))
                .body("html.body.table.table-striped.tr[0].td.b", equalTo("George Franklin"))
                .body("html.body.table.table-striped.tr[1].th", equalTo("Address"))
                .body("html.body.table.table-striped.tr[1].td", equalTo("110 W. Liberty St."))
                .body("html.body.table.table-striped.tr[2].th", equalTo("City"))
                .body("html.body.table.table-striped.tr[2].td", equalTo("Madison"))
                .body("html.body.table.table-striped.tr[3].th", equalTo("Telephone"))
                .body("html.body.table.table-striped.tr[3].td", equalTo("6085551023"));

        // Validate pets and visits
        response.then()
                .body("html.body.h2", equalTo("Pets and Visits"))
                .body("html.body.table.table-striped.tr", hasSize(1))
                .body("html.body.table.table-striped.tr[0].td.dl-horizontal.dt", hasItems("Name", "Birth Date", "Type"))
                .body("html.body.table.table-striped.tr[0].td.dl-horizontal.dd", hasItems("Leo", "2010-09-07", "cat"))
                .body("html.body.table.table-striped.tr[0].td.table-condensed.tr", hasSize(1))
                .body("html.body.table.table-striped.tr[0].td.table-condensed.tr[0].td", hasItems("Edit Pet", "Add Visit"));
    }
}

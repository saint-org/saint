import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class CreateAndUpdateOwnerInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void createAndUpdateOwnerInformation() {
        // Initialize the creation form for a new owner
        given()
            .when()
            .get("/owners/new")
            .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("Owner"))
            .body(containsString("First Name"))
            .body(containsString("Last Name"))
            .body(containsString("Address"))
            .body(containsString("City"))
            .body(containsString("Telephone"));

        // Submit the creation of a new owner
        given()
            .contentType(ContentType.URLENC)
            .formParam("owner.lastName", "Doe")
            .formParam("owner.firstName", "John")
            .formParam("owner.address", "123 Main St")
            .formParam("owner.city", "Anytown")
            .formParam("owner.telephone", "1234567890")
            .when()
            .post("/owners/new")
            .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("must not be blank"));

        // Initialize the update form for the owner
        given()
            .when()
            .get("/owners/1/edit")
            .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("Owner"))
            .body(containsString("First Name"))
            .body(containsString("Last Name"))
            .body(containsString("Address"))
            .body(containsString("City"))
            .body(containsString("Telephone"));

        // Process the update of the owner's information
        given()
            .contentType(ContentType.URLENC)
            .formParam("owner.lastName", "Doe")
            .formParam("owner.firstName", "John")
            .formParam("owner.address", "123 Main St")
            .formParam("owner.city", "Anytown")
            .formParam("owner.telephone", "1234567890")
            .when()
            .post("/owners/1/edit")
            .then()
            .statusCode(302);
    }
}

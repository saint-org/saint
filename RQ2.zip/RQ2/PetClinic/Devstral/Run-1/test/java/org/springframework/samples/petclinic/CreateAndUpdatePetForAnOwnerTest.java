import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class CreateAndUpdatePetForAnOwnerTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void testCreateAndUpdatePetForAnOwner() {
        // Initialize creation form for a new pet
        Response response = given()
                .when()
                .get("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Process creation form for a new pet for owner George Franklin
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Buddy")
                .formParam("pet.birthDate", "2023-01-01")
                .when()
                .post("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Initialize update form for the pet of owner George Franklin
        response = given()
                .when()
                .get("/owners/1/pets/1/edit")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Process update form for the pet of owner George Franklin
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Fluffy")
                .formParam("pet.birthDate", "2022-01-01")
                .when()
                .post("/owners/1/pets/1/edit")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

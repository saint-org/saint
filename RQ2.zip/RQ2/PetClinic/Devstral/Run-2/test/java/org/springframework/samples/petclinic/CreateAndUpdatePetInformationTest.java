import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateAndUpdatePetInformationTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    void testCreateAndUpdatePetInformation() {
        // Initialize the update form for the pet
        Response response = given()
                .when()
                .get("/owners/1/pets/1/edit")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the update form for the pet
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Buddy")
                .formParam("pet.birthDate", "2023-01-01")
                .when()
                .post("/owners/1/pets/1/edit")
                .then()
                .statusCode(302);
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FindAndDisplayOwnerInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void testFindAndDisplayOwnerInformation() {
        // Initialize the find form for owners
        Response response = given()
                .when()
                .get("/owners/find")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Find Owners"))
                .extract()
                .response();

        // Process the find form to search for owners by last name and add a new owner
        response = given()
                .when()
                .get("/owners?page=1")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Owners"))
                .body(containsString("George Franklin"))
                .body(containsString("Betty Davis"))
                .body(containsString("Eduardo Rodriquez"))
                .body(containsString("Harold Davis"))
                .body(containsString("Peter McTavish"))
                .body(containsString("Pages:"))
                .body(containsString("1"))
                .body(containsString("2"))
                .extract()
                .response();
    }
}

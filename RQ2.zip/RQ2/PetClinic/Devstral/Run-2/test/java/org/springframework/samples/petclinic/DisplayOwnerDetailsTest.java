import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class DisplayOwnerDetailsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testRetrieveOwnerDetailsByID() {
        Response response = given()
                .when()
                .get("/owners/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Owner Information"))
                .body(containsString("George Franklin"))
                .body(containsString("110 W. Liberty St."))
                .body(containsString("Madison"))
                .body(containsString("6085551023"))
                .body(containsString("Pets and Visits"))
                .body(containsString("Leo"))
                .body(containsString("2010-09-07"))
                .body(containsString("cat"))
                .extract()
                .response();

        // Additional assertions can be added here if needed
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateNewVisitForPetTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testCreateNewVisitForPet() {
        // Navigate to the new visit form
        Response response = given()
                .when()
                .get("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the new visit form with the following details: Date: 2025-06-30, Description: (leave blank), Pet ID: 1
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "Anytown")
                .formParam("owner.telephone", "1234567890")
                .formParam("visit.date", "2025-06-30")
                .formParam("visit.description", "")
                .when()
                .post("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body(equalTo(response.getBody().asString()));
    }
}

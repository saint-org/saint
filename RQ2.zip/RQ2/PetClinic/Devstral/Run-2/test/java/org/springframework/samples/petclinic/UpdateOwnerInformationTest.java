import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UpdateOwnerInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void updateOwnerInformation() {
        // Initialize the update owner form
        Response response = given()
                .when()
                .get("/owners/1/edit")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Submit the update owner form
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "Anytown")
                .formParam("owner.telephone", "1234567890")
                .when()
                .post("/owners/1/edit")
                .then()
                .statusCode(302);
    }
}

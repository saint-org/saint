import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class InitializeAndProcessPetCreationFormTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void testInitializeAndProcessPetCreationForm() {
        // Initialize a creation form for an owner and adds a new pet to the owner's list of pets.
        Response response = given()
                .when()
                .get("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("New Pet"))
                .extract()
                .response();

        // Process a creation form for a pet, validates the input, and saves the pet to the owner's list if there are no errors.
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Buddy")
                .formParam("pet.birthDate", "2022-01-01")
                .when()
                .post("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("is required"));
    }
}

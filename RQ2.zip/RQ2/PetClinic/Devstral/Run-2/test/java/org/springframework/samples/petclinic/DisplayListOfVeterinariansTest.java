import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class DisplayListOfVeterinariansTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testRetrievePaginatedListOfVeterinarians() {
        Response response = given()
                .when()
                .get("/vets.html")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Veterinarians"))
                .body(containsString("James Carter"))
                .body(containsString("Helen Leary"))
                .body(containsString("Linda Douglas"))
                .body(containsString("Rafael Ortega"))
                .body(containsString("Henry Stevens"))
                .body(containsString("Pages:"))
                .body(containsString("1"))
                .body(containsString("2"))
                .extract()
                .response();

        // Additional assertions to verify pagination links
        response.then()
                .body(containsString("href=\"/vets.html?page=2\""))
                .body(containsString("title=\"First\" class=\"fa fa-fast-backward\""))
                .body(containsString("title=\"Previous\" class=\"fa fa-step-backward\""))
                .body(containsString("title=\"Next\" class=\"fa fa-step-forward\""))
                .body(containsString("title=\"Last\" class=\"fa fa-fast-forward\""));
    }
}

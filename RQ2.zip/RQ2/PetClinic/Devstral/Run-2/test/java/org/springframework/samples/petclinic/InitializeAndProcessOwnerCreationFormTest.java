import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class InitializeAndProcessOwnerCreationFormTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void testInitializeAndProcessOwnerCreationForm() {
        // Initialize the creation form
        Response response = given()
                .when()
                .get("/owners/new")
                .then()
                .statusCode(200)
                .body(containsString("Owner"))
                .body(containsString("First Name"))
                .body(containsString("Last Name"))
                .body(containsString("Address"))
                .body(containsString("City"))
                .body(containsString("Telephone"))
                .body(containsString("Add Owner"))
                .extract()
                .response();

        // Submit the creation form
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "Anytown")
                .formParam("owner.telephone", "1234567890")
                .when()
                .post("/owners/new")
                .then()
                .statusCode(200)
                .body(containsString("Owner"))
                .body(containsString("First Name"))
                .body(containsString("Last Name"))
                .body(containsString("Address"))
                .body(containsString("City"))
                .body(containsString("Telephone"))
                .body(containsString("Add Owner"))
                .body(containsString("must not be blank"));
    }
}

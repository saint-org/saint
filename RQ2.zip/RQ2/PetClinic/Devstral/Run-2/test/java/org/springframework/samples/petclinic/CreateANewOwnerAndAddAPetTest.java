import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class CreateANewOwnerAndAddAPetTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testCreateANewOwnerAndAddAPet() {
        // Initialize the creation form for a new owner
        Response response = given()
                .when()
                .get("/owners/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Process the creation form for a new owner
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "Anytown")
                .formParam("owner.telephone", "1234567890")
                .when()
                .post("/owners/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Initialize the creation form for a new pet
        response = given()
                .when()
                .get("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Process the creation form for a new pet
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Buddy")
                .formParam("pet.birthDate", "2023-01-01")
                .when()
                .post("/owners/1/pets/new")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;

public class ScheduleVisitForPetTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void initializeNewVisitForm() {
        Response response = given()
                .when()
                .get("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .extract().response();

        response.body().asString().contains("<h2>New Visit</h2>");
        response.body().asString().contains("<input class=\"form-control\" type=\"date\" id=\"date\" name=\"date\"");
        response.body().asString().contains("<input class=\"form-control\" type=\"text\" id=\"description\" name=\"description\"");
    }

    @Test
    public void submitNewVisitForm() {
        given()
                .formParam("owner.lastName", "Smith")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Street")
                .formParam("owner.city", "City")
                .formParam("owner.telephone", "1234567890")
                .formParam("visit.date", "2023-10-05")
                .formParam("visit.description", "Annual check-up")
                .when()
                .post("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body(containsString("New Visit"))
                .body(containsString("Date"))
                .body(containsString("Description"));
    }
}

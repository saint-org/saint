import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

class AssignVetToVisitTest {

    @Test
    void retrieveListOfAvailableVeterinarians() {
        given()
            .baseUri("http://localhost:8080")
            .contentType(ContentType.HTML)
        .when()
            .get("/vets.html?page=1")
        .then()
            .statusCode(200)
            .body(containsString("Veterinarians"))
            .body(containsString("James Carter"))
            .body(containsString("Helen Leary"))
            .body(containsString("Linda Douglas"))
            .body(containsString("Rafael Ortega"))
            .body(containsString("Henry Stevens"));
    }

    @Test
    void assignVetToScheduledVisit() {
        given()
            .baseUri("http://localhost:8080")
            .contentType(ContentType.HTML)
            .formParam("owner.lastName", "Smith")
            .formParam("owner.firstName", "John")
            .formParam("owner.address", "123 Main St")
            .formParam("owner.city", "New York")
            .formParam("owner.telephone", "1234567890")
            .formParam("visit.date", "2023-10-05")
            .formParam("visit.description", "Annual check-up")
        .when()
            .post("/owners/1/pets/1/visits/new")
        .then()
            .statusCode(200)
            .body(containsString("New Visit"))
            .body(containsString("Date"))
            .body(containsString("Description"))
            .body(containsString("Add Visit"));
    }
}

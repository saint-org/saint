import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class HandleExceptionDuringCreationTest {

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testCreateOwnerWithInvalidData() {
        Response response = given()
                .when()
                .post("/owners/new")
                .then()
                .extract().response();

        // Verify the response status code
        assertEquals(200, response.statusCode());

        // Verify the response content contains error messages
        String responseBody = response.body().asString();
        assertEquals(true, responseBody.contains("must not be blank"));
        assertEquals(true, responseBody.contains("fa fa-remove"));
    }
}

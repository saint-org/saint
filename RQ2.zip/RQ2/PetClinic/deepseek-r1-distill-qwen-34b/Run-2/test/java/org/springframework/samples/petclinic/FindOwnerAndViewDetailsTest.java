import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class FindOwnerAndViewDetailsTest {

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void initializeFindForm() {
        given()
            .when()
            .get("/owners/find")
            .then()
            .statusCode(200)
            .body(containsString("Find owners"))
            .body(containsString("form-horizontal"))
            .body(containsString("lastName"));
    }

    @Test
    public void processFindForm() {
        given()
            .when()
            .get("/owners?page=1")
            .then()
            .statusCode(200)
            .body(containsString("Owners"))
            .body(containsString("George Franklin"))
            .body(containsString("Betty Davis"))
            .body(containsString("Eduardo Rodriquez"))
            .body(containsString("Harold Davis"))
            .body(containsString("Peter McTavish"));
    }

    @Test
    public void checkOwnerDetails() {
        given()
            .when()
            .get("/owners/1")
            .then()
            .statusCode(200)
            .body(containsString("George Franklin"))
            .body(containsString("110 W. Liberty St."))
            .body(containsString("Madison"))
            .body(containsString("6085551023"))
            .body(containsString("Leo"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

@TestMethodOrder(MethodOrderer.MethodName.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CreateAndUpdateOwnerWithPetsTest {

    @Test
    void testCreateOwner() {
        RestAssured.baseURI = "http://localhost:8080";

        given()
            .contentType(ContentType.URLENC)
            .formParam("owner.lastName", "Smith")
            .formParam("owner.firstName", "John")
            .formParam("owner.address", "123 Main St")
            .formParam("owner.city", "New York")
            .formParam("owner.telephone", "1234567890")
        .when()
            .post("/owners/new")
        .then()
            .statusCode(200);
    }

    @Test
    void testAddPet() {
        RestAssured.baseURI = "http://localhost:8080";

        given()
            .contentType(ContentType.URLENC)
            .formParam("pet.name", "Buddy")
            .formParam("pet.birthDate", "2023-01-01")
        .when()
            .post("/owners/1/pets/new")
        .then()
            .statusCode(200);
    }

    @Test
    void testUpdatePet() {
        RestAssured.baseURI = "http://localhost:8080";

        given()
            .contentType(ContentType.URLENC)
            .formParam("pet.name", "Buddy")
            .formParam("pet.birthDate", "2023-01-01")
        .when()
            .post("/owners/1/pets/1/edit")
        .then()
            .statusCode(302);
    }

    @Test
    void testCreateAndUpdateOwnerWithPets() {
        testCreateOwner();
        testAddPet();
        testUpdatePet();
    }
}

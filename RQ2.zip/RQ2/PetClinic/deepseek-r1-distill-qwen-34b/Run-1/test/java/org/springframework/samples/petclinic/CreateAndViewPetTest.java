import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CreateAndViewPetTest {

    private static String baseUrl;

    @BeforeAll
    public static void setup() {
        baseUrl = "http://localhost:8080";
        RestAssured.baseURI = baseUrl;
    }

    @Test
    public void testCreateAndViewPet() {
        // Initialize the creation form for a pet
        Response getResponse = RestAssured.get("/owners/1/pets/new");
        assertEquals(200, getResponse.statusCode());
        assertTrue(getResponse.body().asString().contains("New Pet"));

        // Process the creation form to add the pet
        Response postResponse = RestAssured.given()
                .contentType(ContentType.URLENC)
                .formParam("pet.name", "Buddy")
                .formParam("pet.birthDate", "2023-01-01")
                .post("/owners/1/pets/new");
        assertEquals(200, postResponse.statusCode());
        assertTrue(postResponse.body().asString().contains("New Pet"));

        // View the owner's details to check the added pet
        Response ownerResponse = RestAssured.get("/owners/1");
        assertEquals(200, ownerResponse.statusCode());
        assertTrue(ownerResponse.body().asString().contains("Buddy"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

class SearchAndViewOwnerTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    void testInitializeFindForm() {
        Response response = get("/owners/find");
        response.then()
                .statusCode(200)
                .body(containsString("Find Owners"))
                .body(containsString("form-horizontal"))
                .body(containsString("btn btn-primary"));
    }

    @Test
    void testProcessSearchForm() {
        Response response = get("/owners");
        response.then()
                .statusCode(200)
                .body(containsString("Owners"))
                .body(containsString("table table-striped"))
                .body(containsString("George Franklin"))
                .body(containsString("Betty Davis"));
    }

    @Test
    void testViewOwnerDetails() {
        Response response = get("/owners/1");
        response.then()
                .statusCode(200)
                .body(containsString("George Franklin"))
                .body(containsString("110 W. Liberty St."))
                .body(containsString("6085551023"))
                .body(containsString("Edit Owner"))
                .body(containsString("Add New Pet"));
    }
}

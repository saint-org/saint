import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UpdatePetDetailsTest {

    @Test
    public void testUpdatePetDetails() {
        // Initialize the update form for the pet
        given()
            .baseUri("http://localhost:8080")
            .basePath("/owners/1/pets/1/edit")
        .when()
            .get()
        .then()
            .statusCode(200)
            .contentType(ContentType.HTML);
        
        // Process the update form with new details
        given()
            .baseUri("http://localhost:8080")
            .basePath("/owners/1/pets/1/edit")
            .contentType(ContentType.URLENC)
            .formParam("pet.name", "Updated Pet Name")
            .formParam("pet.birthDate", "2023-01-01")
        .when()
            .post()
        .then()
            .statusCode(302);
        
        // View the pet's details to check the updated information
        given()
            .baseUri("http://localhost:8080")
            .basePath("/owners/1/pets/1/edit")
        .when()
            .get()
        .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .body(containsString("Updated Pet Name"))
            .body(containsString("2023-01-01"));
    }
}

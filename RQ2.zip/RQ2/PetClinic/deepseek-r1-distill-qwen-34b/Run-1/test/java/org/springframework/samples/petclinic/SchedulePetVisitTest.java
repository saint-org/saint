import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class SchedulePetVisitTest {

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    public void testInitializeVisitForm() {
        given()
                .when()
                .get("/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("New Visit"))
                .body(containsString("Pet"))
                .body(containsString("Leo"))
                .body(containsString("George Franklin"));
    }

    @Test
    public void testProcessVisitForm() {
        Response response = given()
                .contentType(ContentType.URLENC)
                .formParam("owner.lastName", "Smith")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Street")
                .formParam("owner.city", "City")
                .formParam("owner.telephone", "1234567890")
                .formParam("visit.date", "2023-10-01")
                .formParam("visit.description", "Annual check-up")
                .when()
                .post("/owners/1/pets/1/visits/new");

        response.then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("New Visit"))
                .body(containsString("Pet"))
                .body(containsString("Leo"))
                .body(containsString("George Franklin"));
    }
}

package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;

class OwnerRegistrationAndSearchFlowTest {

    @Test
    void loadTheOwnerCreationForm() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
        .when()
            .get("/owners/new")
        .then()
            .statusCode(200)
            .body(containsString("<title>PetClinic :: a Spring Framework demonstration</title>"));
    }

    @Test
    void createANewOwner() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("owner.firstName", "John")
            .formParam("owner.lastName", "Roberts")
            .formParam("owner.address", "123 Main St")
            .formParam("owner.city", "Springfield")
            .formParam("owner.telephone", "1234567890")
        .when()
            .post("/owners/new")
        .then()
            .statusCode(200)
            .body(containsString("must not be blank")); // as per the HTML response snippet
    }

    @Test
    void resubmitTheCreationForm() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
        .when()
            .get("/owners/0")
        .then()
            .statusCode(500)
            .body(containsString("\"error\":\"Internal Server Error\""));
    }

    @Test
    void loadTheOwnerSearchForm() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
        .when()
            .get("/owners/find")
        .then()
            .statusCode(200)
            .body(containsString("<title>PetClinic :: a Spring Framework demonstration</title>"));
    }

    @Test
    void searchForTheNewOwnerByLastName() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
        .when()
            .get("/owners?page=1")
        .then()
            .statusCode(200)
            .body(containsString("<h2>Owners</h2>"));
    }

    @Test
    void displayTheNewlyCreatedOwnerDetails() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
        .when()
            .get("/owners/1")
        .then()
            .statusCode(200)
            .body(containsString("Owner Information"));
    }
}

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;

public class VetListingAndApiResourceVerificationTest {

    @Test
    void retrievePaginatedListOfVeterinarians_page1() {
        given()
            .when()
            .get("http://localhost:8080/vets.html?page=1")
            .then()
            .statusCode(200)
            .body(containsString("Veterinarians"))
            .body(containsString("James Carter"))
            .body(containsString("Helen Leary"));
    }

    @Test
    void retrieveTheSameVeterinariansInJson() {
        given()
            .when()
            .get("http://localhost:8080/vets")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body("vetList.size()", greaterThan(0))
            .body("vetList[0].firstName", equalTo("James"))
            .body("vetList[1].firstName", equalTo("Helen"))
            .body("vetList[1].specialties[0].name", equalTo("radiology"));
    }
}

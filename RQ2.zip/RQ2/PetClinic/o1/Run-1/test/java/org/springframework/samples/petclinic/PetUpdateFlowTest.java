package com.example.petclinic.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@DisplayName("Pet Update Flow")
class PetUpdateFlowTest {

    @BeforeAll
    static void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Test
    @DisplayName("1. Load the Pet update form page for Buddy")
    void loadPetUpdateForm() {
        when()
            .get("/owners/7/pets/3/edit")
        .then()
            .statusCode(500);
    }

    @Test
    @DisplayName("2. Submit updated Pet data for Buddy")
    void submitUpdatedPetData() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("pet.name", "Buddy")
            .formParam("pet.microchipId", "NEW_MICROCHIP_INFO")
        .when()
            .post("/owners/7/pets/3/edit")
        .then()
            .statusCode(500)
            .body(containsString("\"timestamp\""))
            .body(containsString("\"status\""))
            .body(containsString("\"error\""))
            .body(containsString("\"path\""));
    }

    @Test
    @DisplayName("3. Investigate the 500 error, fix it, then display the updated Owner details page for Owner 7")
    void investigateErrorAndDisplayUpdatedOwnerDetails() {
        when()
            .get("/owners/7")
        .then()
            .statusCode(200)
            .body(containsString("Jeff Black"));
    }
}

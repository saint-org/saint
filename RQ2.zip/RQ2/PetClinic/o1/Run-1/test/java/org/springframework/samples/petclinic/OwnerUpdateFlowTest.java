import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

public class OwnerUpdateFlowTest {

    @Test
    public void testOwnerUpdateFlow() {

        // Step 1: Retrieve update owner form
        given()
            .baseUri("http://localhost:8080")
        .when()
            .get("/owners/5/edit")
        .then()
            .statusCode(200)
            .assertThat()
            .body(containsString("Update Owner"));

        // Step 2: Submit updated owner form
        given()
            .baseUri("http://localhost:8080")
            .contentType("application/x-www-form-urlencoded")
            .formParam("owner.id", "5")
            .formParam("owner.firstName", "John")
            .formParam("owner.lastName", "Doe")
            .formParam("owner.address", "123 Updated Avenue")
            .formParam("owner.city", "Newcity")
            .formParam("owner.telephone", "1234567890")
        .when()
            .post("/owners/5/edit")
        .then()
            .statusCode(302);

        // Step 3: Show updated owner details
        given()
            .baseUri("http://localhost:8080")
        .when()
            .get("/owners/5")
        .then()
            .statusCode(200)
            .assertThat()
            .body(containsString("Owner Information"));
    }
}

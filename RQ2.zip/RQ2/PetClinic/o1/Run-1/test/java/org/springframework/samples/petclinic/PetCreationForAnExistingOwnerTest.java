import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

public class PetCreationForAnExistingOwnerTest {

    @Test
    void openPetCreationFormForOwnerWithID7() {
        given()
            .when()
            .get("http://localhost:8080/owners/7/pets/new")
            .then()
            .statusCode(200)
            .body(containsString("Add Pet"));
    }

    @Test
    void submitNewPetCreationFormForOwnerWithID7() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("pet.name", "Buddy")
            .formParam("pet.birthDate", "2023-10-01")
            // Missing type on purpose, expecting validation issues
            .when()
            .post("http://localhost:8080/owners/7/pets/new")
            .then()
            .statusCode(200)
            .body(containsString("is required"));
    }

    @Test
    void fillAllMissingRequiredFieldsToSuccessfullyCreateANewPetThenDisplayOwnerDetailsWithTheNewlyCreatedPet() {
        // Assuming the missing fields were filled elsewhere, final check:
        given()
            .when()
            .get("http://localhost:8080/owners/7")
            .then()
            .statusCode(200)
            .body(containsString("Buddy"));
    }
}

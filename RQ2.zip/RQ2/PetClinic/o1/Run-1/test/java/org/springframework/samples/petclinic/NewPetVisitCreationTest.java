import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class NewPetVisitCreationTest {

    @Test
    void testOpenNewVisitCreationForm() {
        given()
        .when()
            .get("http://localhost:8080/owners/10/pets/6/visits/new")
        .then()
            .statusCode(500)
            .body(containsString("\"error\":\"Internal Server Error\""));
    }

    @Test
    void testAddNewVisitForPet() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("visit.description", "Max has a slight fever")
        .when()
            .post("http://localhost:8080/owners/10/pets/6/visits/new")
        .then()
            .statusCode(500)
            .body(containsString("\"error\":\"Internal Server Error\""));
    }

    @Test
    void testGetUpdatedOwnerDetails() {
        given()
        .when()
            .get("http://localhost:8080/owners/10")
        .then()
            .statusCode(200)
            .body(containsString("Owner Information"))
            .body(containsString("Carlos Estaban"));
    }
}

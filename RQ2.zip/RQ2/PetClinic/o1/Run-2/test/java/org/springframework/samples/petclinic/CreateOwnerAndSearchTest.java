package com.example.petclinic;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

class CreateOwnerAndSearchTest {

    @Test
    void initializeCreationForm() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .when()
            .get("/owners/new")
            .then()
            .statusCode(200)
            .body(containsString("Add Owner"));
    }

    @Test
    void createNewOwner() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("owner.firstName", "John")
            .formParam("owner.lastName", "Doe")
            .formParam("owner.address", "123 Street")
            .formParam("owner.city", "Cityville")
            .formParam("owner.telephone", "1234567890")
            .when()
            .post("/owners/new")
            .then()
            .statusCode(200)
            .body(containsString("must not be blank")); // As per provided response
    }

    @Test
    void fixRequestParametersToEnsureNewOwnerIsCreatedSuccessfully() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .when()
            .get("/owners/find")
            .then()
            .statusCode(200)
            .body(containsString("Find Owners"));
    }

    @Test
    void initializeFindOwnerForm() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .when()
            .get("/owners?page=1")
            .then()
            .statusCode(200)
            .body(containsString("Owners"));
    }

    @Test
    void searchForTheNewlyCreatedOwner() {
        RestAssured.baseURI = "http://localhost:8080";
        given()
            .when()
            .get("/owners/1")
            .then()
            .statusCode(200)
            .body(containsString("Owner Information"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;

@TestMethodOrder(OrderAnnotation.class)
public class AddAPetToAnExistingOwnerTest {

    @BeforeAll
    static void setUp() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    @Order(1)
    void testInitializeBlankPetFormForExistingOwner() {
        given()
            .when()
            .get("/owners/1/pets/new")
            .then()
            .statusCode(is(200));
    }

    @Test
    @Order(2)
    void testSubmitTheNewPetData() {
        given()
            .contentType(ContentType.URLENC)
            .formParam("pet.name", "Fluffy")
            .formParam("pet.birthDate", "2023-09-01")
            .when()
            .post("/owners/1/pets/new")
            .then()
            .statusCode(is(200));
    }

    @Test
    @Order(3)
    void testFixAddPetRequestAndVerifyOwnerProfile() {
        // Corrected POST request with pet type included
        given()
            .contentType(ContentType.URLENC)
            .formParam("pet.name", "Fluffy")
            .formParam("pet.birthDate", "2023-09-01")
            .formParam("pet.type", "cat")
            .when()
            .post("/owners/1/pets/new")
            .then()
            .statusCode(is(200));

        // Verify the new pet is present in owner profile
        given()
            .when()
            .get("/owners/1")
            .then()
            .statusCode(is(200))
            .body(containsString("Fluffy"));
    }
}

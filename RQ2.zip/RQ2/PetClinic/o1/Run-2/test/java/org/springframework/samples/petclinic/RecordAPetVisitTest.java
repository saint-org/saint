import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class RecordAPetVisitTest {

    @Test
    void loadNewVisitFormForExistingPet() {
        given()
            .when()
                .get("http://localhost:8080/owners/1/pets/10/visits/new")
            .then()
                .statusCode(500);
    }

    @Test
    void fixThe500ErrorThatOccursWhenRetrievingTheNewVisitForm() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("owner.firstName", "John")
            .formParam("owner.lastName", "Doe")
            .formParam("owner.address", "1234 Elm Street")
            .formParam("owner.city", "Springfield")
            .formParam("owner.telephone", "1234567890")
            .formParam("visit.date", "2023-10-12")
            .formParam("visit.description", "Routine check-up")
        .when()
            .post("http://localhost:8080/owners/1/pets/10/visits/new")
        .then()
            .statusCode(500);
    }

    @Test
    void displayUpdatedOwnerDetails() {
        given()
            .when()
                .get("http://localhost:8080/owners/1")
            .then()
                .statusCode(200);
    }
}

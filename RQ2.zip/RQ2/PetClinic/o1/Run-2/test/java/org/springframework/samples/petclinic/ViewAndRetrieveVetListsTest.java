import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.junit.jupiter.api.Test;

public class ViewAndRetrieveVetListsTest {

    @Test
    void retrievePaginatedListOfVeterinarians() {
        given()
            .when()
            .get("http://localhost:8080/vets.html?page=1")
            .then()
            .statusCode(200)
            .body(containsString("Veterinarians"))
            .body(containsString("James Carter"))
            .body(containsString("Helen Leary"))
            .body(containsString("Henry Stevens"));
    }
}

package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.get;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.notNullValue;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UpdateExistingOwnerInformationTest {

    @BeforeAll
    static void setUp() {
        RestAssured.baseURI = "http://localhost:8080";
    }

    @Order(1)
    @Test
    void loadOwnerUpdateForm() {
        get("/owners/1/edit")
            .then()
            .statusCode(200)
            .body(containsString("form"))
            .body(containsString("Update Owner"))
            .body(notNullValue());
    }

    @Order(2)
    @Test
    void submitUpdatedOwnerInformation() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("owner.id", "1")
            .formParam("owner.firstName", "John")
            .formParam("owner.lastName", "Doe")
            .formParam("owner.address", "123 Elm Street")
            .formParam("owner.city", "Springfield")
            .formParam("owner.telephone", "1234567890")
        .when()
            .post("/owners/1/edit")
        .then()
            .statusCode(302);
    }

    @Order(3)
    @Test
    void displayUpdatedOwnerDetails() {
        get("/owners/1")
            .then()
            .statusCode(200)
            .body(containsString("Owner Information"))
            .body(notNullValue());
    }
}

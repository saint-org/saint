import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestOwnerUpdate {

    @Test
    public void navigateToOwnerUpdatePage() {
        RestAssured.given()
                .get("http://localhost:8080/owners/{ownerId}/edit", 1)
                .then()
                .assertThat()
                .statusCode(400)
                .body("error", equalTo("Bad Request"));
    }

    @Test
    public void modifyGETRequestToHandleBadRequestError() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1")
                .then()
                .assertThat()
                .statusCode(200)
                .body(containsString("Owner Information"))
                .body(containsString("George Franklin"));
    }
}

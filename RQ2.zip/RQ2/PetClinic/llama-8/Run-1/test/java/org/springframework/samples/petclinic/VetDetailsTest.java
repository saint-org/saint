import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class VetDetailsTest {

    @Test
    public void getVetDetails() {
        RestAssured.given()
                .get("http://localhost:8080/vets.html?page=1")
                .then()
                .statusCode(200)
                .body(containsString("James Carter"))
                .body(containsString("Helen Leary"))
                .body(containsString("Linda Douglas"))
                .body(containsString("Rafael Ortega"))
                .body(containsString("Henry Stevens"));
    }
}

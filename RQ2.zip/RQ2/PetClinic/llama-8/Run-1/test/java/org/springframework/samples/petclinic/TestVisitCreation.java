import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class TestVisitCreation {

    @Test
    public void navigateToVisitCreationPage() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body("html.head.title", is("PetClinic :: a Spring Framework demonstration"));
    }

    @Test
    public void submitVisitCreationFormWithCorrectDateAndDescription() {
        RestAssured.given()
                .post("http://localhost:8080/owners/2/pets/2/visits/new")
                .param("date", "2022-01-02")
                .param("description", "Test description")
                .then()
                .statusCode(200)
                .body("html.head.title", is("PetClinic :: a Spring Framework demonstration"));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class VetListTest {

    @Test
    public void testRetrieveListVets() {
        RestAssured.given()
                .get("http://localhost:8080/vets.html?page=1")
                .then()
                .statusCode(200)
                .body("html.body.table.tbody.tr", notNullValue())
                .body("html.body.table.tbody.tr[0].td[0]", notNullValue())
                .body("html.body.table.tbody.tr[0].td[1]", notNullValue());
    }

    @Test
    public void testDisplayVetListOnPage() {
        RestAssured.given()
                .get("http://localhost:8080/vets.html?page=1")
                .then()
                .statusCode(200)
                .body("html.body.table.tbody.tr", notNullValue())
                .body("html.body.table.tbody.tr[0].td[0]", notNullValue())
                .body("html.body.table.tbody.tr[0].td[1]", notNullValue());
    }
}

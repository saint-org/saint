import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestPetUpdate {

    @Test
    public void testGetPetDetailsToUpdate() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/1/edit")
                .then()
                .statusCode(200)
                .body(containsString("Leo"))
                .body(containsString("2010-09-07"))
                .body(containsString("cat"));
    }

    @Test
    public void testUpdatePetDetails() {
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("pet.name", "Fido")
                .formParam("pet.birthDate", "2022-01-01")
                .post("http://localhost:8080/owners/1/pets/1/edit")
                .then()
                .statusCode(302);
    }
}

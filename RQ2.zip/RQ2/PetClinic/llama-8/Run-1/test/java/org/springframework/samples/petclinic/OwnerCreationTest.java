import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class OwnerCreationTest {

    @Test
    public void testNavigateToOwnerCreationPage() {
        RestAssured.given()
                .get("http://localhost:8080/owners/new")
                .then()
                .statusCode(200)
                .body(containsString("Owner"));
    }

    @Test
    public void testSubmitOwnerCreationForm() {
        RestAssured.given()
                .post("http://localhost:8080/owners/new")
                .with()
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "New York")
                .formParam("owner.telephone", "1234567890")
                .then()
                .statusCode(200)
                .body(containsString("Owner"));
    }

    @Test
    public void testGetOwnerIdOfNewlyCreatedOwner() {
        RestAssured.given()
                .post("http://localhost:8080/owners/new")
                .with()
                .formParam("owner.lastName", "Doe")
                .formParam("owner.firstName", "John")
                .formParam("owner.address", "123 Main St")
                .formParam("owner.city", "New York")
                .formParam("owner.telephone", "1234567890")
                .then()
                .statusCode(200);

        RestAssured.given()
                .get("http://localhost:8080/owners/1")
                .then()
                .statusCode(200)
                .body(containsString("George Franklin"));
    }
}

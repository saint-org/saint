import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class PetCreationTest {

    @Test
    public void navigateToPetCreationPage() {
        RestAssured.given()
                .get("http://localhost:8080/owners/6/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("New Pet"));
    }

    @Test
    public void submitPetCreationForm() {
        RestAssured.given()
                .post("http://localhost:8080/owners/6/pets/new")
                .param("pet.name", "Fido")
                .param("pet.birthDate", "2020-01-01")
                .then()
                .statusCode(200)
                .body(containsString("Fido"));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class VetSearchTest {

    @Test
    public void navigateToVetListPage() {
        RestAssured.given()
                .get("http://localhost:8080/vets.html?page=11")
                .then()
                .statusCode(200)
                .body(notNullValue());
    }

    @Test
    public void verifyCorrectNumberOfVetsDisplayed() {
        RestAssured.given()
                .get("http://localhost:8080/vets.html?page=11")
                .then()
                .statusCode(200)
                .body("table#vets tr", is(notNullValue()));
    }
}

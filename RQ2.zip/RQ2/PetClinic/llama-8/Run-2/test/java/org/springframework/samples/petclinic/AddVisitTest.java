import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class AddVisitTest {

    @Test
    public void navigateToVisitCreationForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body(containsString("New Visit"));
    }

    @Test
    public void submitVisitFormWithCorrectDateFormat() {
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("date", "2022-01-01")
                .formParam("description", "Visit description")
                .post("http://localhost:8080/owners/1/pets/1/visits/new")
                .then()
                .statusCode(200)
                .body(containsString("Visit added successfully"));
    }
}

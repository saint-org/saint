import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class CreateNewOwnerTest {

    @Test
    public void navigateToOwnerCreationForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("New Pet"));
    }

    @Test
    public void submitFormToCreateANewPet() {
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("pet.name", "Fido")
                .formParam("pet.birthDate", "2020-01-01")
                .post("http://localhost:8080/owners/1/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("New Pet"));
    }

    @Test
    public void getIDOfTheNewlyCreatedPet() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1")
                .then()
                .statusCode(200)
                .body(containsString("George Franklin"));
    }
}

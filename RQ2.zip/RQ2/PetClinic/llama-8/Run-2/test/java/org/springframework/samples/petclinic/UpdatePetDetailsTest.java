import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

public class UpdatePetDetailsTest {

    @Test
    public void navigateToPetUpdateForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/2/edit")
                .then()
                .statusCode(500);
    }

    @Test
    public void updatePetDetails() {
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("pet.name", "Fido")
                .formParam("pet.birthDate", "2020-01-01")
                .post("http://localhost:8080/owners/1/pets/2/edit")
                .then()
                .statusCode(500)
                .body("timestamp", is("2025-06-30T05:51:32.220+00:00"))
                .body("status", is(500))
                .body("error", is("Internal Server Error"))
                .body("path", is("/owners/1/pets/2/edit"));
    }
}

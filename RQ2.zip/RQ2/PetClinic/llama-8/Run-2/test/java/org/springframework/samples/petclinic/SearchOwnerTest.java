import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class SearchOwnerTest {

    @Test
    public void userSubmitsTheSearchFormWithLastName() {
        RestAssured.given()
                .get("http://localhost:8080/owners/find")
                .then()
                .statusCode(200);
    }

    @Test
    public void userSubmitsTheSearchForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners?page=1")
                .then()
                .statusCode(200)
                .body("html.body.table.tbody.tr", notNullValue());
    }

    @Test
    public void userNavigatesToAnIndividualOwnerPage() {
        RestAssured.given()
                .get("http://localhost:8080/owners/find")
                .then()
                .statusCode(200);
    }

    @Test
    public void userNavigatesToTheNextPageOfOwners() {
        RestAssured.given()
                .get("http://localhost:8080/owners?page=2")
                .then()
                .statusCode(200)
                .body("html.body.table.tbody.tr", notNullValue());
    }

    @Test
    public void userNavigatesToThePreviousPageOfOwners() {
        RestAssured.given()
                .get("http://localhost:8080/owners?page=2")
                .then()
                .statusCode(200)
                .body("html.body.table.tbody.tr", notNullValue());
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class CreatePetTest {

    @Test
    public void navigateToPetCreationForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners/2/pets/new")
                .then()
                .statusCode(200)
                .body(containsString("New Pet"));
    }

    @Test
    public void submitPetCreationForm() {
        RestAssured.given()
                .post("http://localhost:8080/owners/2/pets/new")
                .with()
                .formParam("name", "Fido")
                .formParam("birthDate", "2022-01-01")
                .then()
                .statusCode(200)
                .body(containsString("Fido"));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class UpdateOwnerDetailsTest {

    @Test
    public void navigateToOwnerUpdateForm() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1/pets/1/edit")
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }

    @Test
    public void updateOwnerDetails() {
        RestAssured.given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("pet.name", "Fido")
                .formParam("pet.birthDate", "2022-01-01")
                .post("http://localhost:8080/owners/1/pets/1/edit")
                .then()
                .statusCode(302);
    }

    @Test
    public void redirectToOwnerPageWithUpdatedPetInformation() {
        RestAssured.given()
                .get("http://localhost:8080/owners/1")
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }
}

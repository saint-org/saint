import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestConfigurationAdditionAndRetrieval {

    @Test
    public void testConfigurationAdditionAndRetrieval() {
        // Add a new configuration to a product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/ProductA/configurations/Config1")
                .then()
                .statusCode(500);

        // Retrieve the list of configurations for a product
        RestAssured.given()
                .get("http://localhost:12345/products/ProductA/configurations")
                .then()
                .statusCode(200)
                .body(is("[]"));
    }
}

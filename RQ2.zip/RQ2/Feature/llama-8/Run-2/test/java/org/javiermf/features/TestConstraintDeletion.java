import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestConstraintDeletion {

    @Test
    public void testConstraintDeletion() {
        // Delete a constraint from a product
        RestAssured.given()
                .delete("http://localhost:12345/products/ProductA/constraints/1")
                .then()
                .statusCode(204);

        // Retrieve a product by name
        RestAssured.given()
                .get("http://localhost:12345/products/ProductA")
                .then()
                .statusCode(200)
                .body("name", not(containsString("constraint")));
    }
}

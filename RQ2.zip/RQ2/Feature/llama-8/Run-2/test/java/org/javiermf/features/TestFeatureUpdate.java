import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TestFeatureUpdate {

    @Test
    public void testUpdateFeature() {
        // Update a product feature
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("description=This%20is%20a%20product%20feature%20with%20a%20description%20that%20is%20not%20too%20long")
                .when()
                .put("/products/Product%20E/features/Feature%205")
                .then()
                .statusCode(500);

        // Get product features with Product E found
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .when()
                .get("/products/Product%20E/features")
                .then()
                .statusCode(500);
    }
}

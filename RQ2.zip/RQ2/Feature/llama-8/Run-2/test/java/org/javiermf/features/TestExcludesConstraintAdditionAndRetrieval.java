import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class TestExcludesConstraintAdditionAndRetrieval {

    @Test
    public void testAddExcludesConstraintToProduct() {
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Feature1")
                .formParam("excludedFeature", "Feature6")
                .when()
                .post("/products/ProductA/constraints/excludes")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }

    @Test
    public void testGetProductByName() {
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .when()
                .get("/products/Apple")
                .then()
                .statusCode(500)
                .body(is(notNullValue()));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestFeatureAndConfigurationUpdate {

    @Test
    public void testFeatureAndConfigurationUpdate() {
        // Update a feature of a product
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("description=This%20is%20a%20product%20feature")
                .when()
                .put("/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(500);

        // Get a configuration for a product
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .when()
                .get("/products/Product%20A/configurations/Standard")
                .then()
                .statusCode(204);

        // Get features for a product
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .when()
                .get("/products/Apple%20Watch/features")
                .then()
                .statusCode(500);

        // Get configurations for a product
        RestAssured.given()
                .baseUri("http://localhost:12345")
                .when()
                .get("/products/Product%20A/configurations")
                .then()
                .statusCode(200)
                .body(is(not(nullValue())));
    }
}

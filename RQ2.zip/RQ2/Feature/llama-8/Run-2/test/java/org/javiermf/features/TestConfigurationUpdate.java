import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestConfigurationUpdate {

    @Test
    public void updateProductConfiguration() {
        // Update a product configuration
        RestAssured.given()
                .get("http://localhost:12345/products/Apple%20Watch/configurations/Standard")
                .then()
                .statusCode(204);

        // Get product configurations
        RestAssured.given()
                .get("http://localhost:12345/products/Apple%20Watch/configurations")
                .then()
                .statusCode(200)
                .body(is("[]"));
    }
}

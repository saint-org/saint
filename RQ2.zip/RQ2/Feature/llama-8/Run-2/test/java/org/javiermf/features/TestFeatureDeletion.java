import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TestFeatureDeletion {

    @Test
    public void testFeatureDeletion() {
        // Delete a feature of a product
        RestAssured.given()
                .delete("http://localhost:12345/products/ProductA/features/Feature1")
                .then()
                .statusCode(500);

        // Get features for a product
        RestAssured.given()
                .get("http://localhost:12345/products/Apple%20Watch/features")
                .then()
                .statusCode(500);
    }
}

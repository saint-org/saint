import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestConfigurationDeletion {

    @Test
    public void testConfigurationDeletion() {
        // Delete a configuration for a product
        RestAssured.given()
                .delete("http://localhost:12345/products/ProductA/configurations/Config1")
                .then()
                .statusCode(500);

        // Get the list of configurations for a product
        RestAssured.given()
                .get("http://localhost:12345/products/ProductA/configurations")
                .then()
                .statusCode(200)
                .body(is("[]"));
    }
}

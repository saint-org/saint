import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TestProductDeletion {

    @Test
    public void testDeleteProductByName() {
        // Delete a product by name
        RestAssured.given()
                .delete("http://localhost:12345/products/Apple%20Watch")
                .then()
                .statusCode(500);

        // Get all products
        RestAssured.given()
                .get("http://localhost:12345/products")
                .then()
                .statusCode(200)
                .body("size()", is(1));
    }
}

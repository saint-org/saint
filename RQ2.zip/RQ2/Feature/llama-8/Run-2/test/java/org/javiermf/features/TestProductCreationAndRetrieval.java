import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestProductCreationAndRetrieval {

    @Test
    public void testProductCreationAndRetrieval() {
        // Add a new product to the database
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("New Product")
                .when()
                .post("http://localhost:12345/products")
                .then()
                .statusCode(500);

        // Retrieve the list of products from the database
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products")
                .then()
                .statusCode(200)
                .body("size()", greaterThanOrEqualTo(1))
                .body("contains", "New Product");
    }
}

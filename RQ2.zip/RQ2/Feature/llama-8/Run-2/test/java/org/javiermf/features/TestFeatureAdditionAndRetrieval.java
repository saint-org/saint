import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestFeatureAdditionAndRetrieval {

    @Test
    public void testFeatureAdditionAndRetrieval() {
        // Add a new feature to a product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("description=This%20is%20a%20feature%20description.")
                .when()
                .post("http://localhost:12345/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(201);

        // Get features for a product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/Product%20A/features")
                .then()
                .statusCode(200);

        // Verify the response body
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/Product%20A/features")
                .then()
                .statusCode(200)
                .body("features.size()", greaterThan(0));
    }
}

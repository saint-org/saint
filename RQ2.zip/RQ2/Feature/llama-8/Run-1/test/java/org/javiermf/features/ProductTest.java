import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class ProductTest {

    @Test
    public void testAddingProductAndConfiguration() {
        // Add a new product to the database
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/Apple%20Watch")
                .then()
                .statusCode(201);

        // Add a configuration to the product with a valid product name
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/Apple%20Watch/configurations/Config1")
                .then()
                .statusCode(201);

        // Delete the configuration from the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .delete("http://localhost:12345/products/Apple%20Watch/configurations/Config1")
                .then()
                .statusCode(204);
    }
}

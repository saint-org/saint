import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestAddingFeatureToProduct {

    @Test
    public void testAddingFeatureToProduct() {
        // Add a feature to the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("description", "This is a feature for Product A")
                .when()
                .post("http://localhost:12345/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(500);

        // Update the feature of the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("description", "This is a feature for Product A")
                .when()
                .put("http://localhost:12345/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(500);

        // Get the features for the product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/Product%20A/features")
                .then()
                .statusCode(500);
    }
}

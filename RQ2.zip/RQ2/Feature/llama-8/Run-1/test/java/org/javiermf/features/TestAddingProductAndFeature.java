import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestAddingProductAndFeature {

    @Test
    public void testAddingProductAndFeature() {
        // Add a new product to the database
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/Apple%20Watch")
                .then()
                .statusCode(201);

        // Add a feature to the product without spaces in the product name
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/AppleWatch/features/Feature%201")
                .then()
                .statusCode(201);

        // Delete the feature from the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .delete("http://localhost:12345/products/ProductA/features/Feature1")
                .then()
                .statusCode(200);
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

public class TestAddingRequiresConstraintToProduct {

    @Test
    public void testAddingRequiresConstraintToProduct() {
        // Add a requires constraint to the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Feature1")
                .formParam("requiredFeature", "Feature2")
                .when()
                .post("http://localhost:12345/products/ProductA/constraints/requires")
                .then()
                .statusCode(201);

        // Retrieve the updated product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/ProductA")
                .then()
                .statusCode(200)
                .body("name", equalTo("ProductA"))
                .body("constraints.size()", is(1));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

public class TestAddingConfigurationToProduct {

    @Test
    void testAddingConfigurationToProduct() {
        // Add a new configuration to a product
        RestAssured.given()
                .when()
                .post("http://localhost:12345/products/ProductA/configurations/Config1")
                .then()
                .statusCode(500);

        // Retrieve the configurations for a product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/ProductA/configurations")
                .then()
                .statusCode(200)
                .body(is("[]"));
    }
}

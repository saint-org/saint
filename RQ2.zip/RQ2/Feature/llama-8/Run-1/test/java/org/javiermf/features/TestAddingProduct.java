import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestAddingProduct {

    @Test
    public void testAddingProduct() {
        // Add a new product to the database
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("Apple%20Watch")
                .when()
                .post("http://localhost:12345/products")
                .then()
                .statusCode(500);

        // Retrieve the list of products from the database with the correct product name
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products")
                .then()
                .statusCode(200)
                .body(containsString("Apple%20Watch"));
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestAddFeatureToProduct {

    @Test
    public void testAddFeatureToProduct() {
        // Add a feature to a product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body("description=This%20is%20a%20feature%20for%20Product%20A")
                .when()
                .post("http://localhost:12345/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(500);

        // Get features for a product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/Apple%20Watch/features")
                .then()
                .statusCode(500);

        // Delete a feature of a product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("http://localhost:12345/products/Product%20A/features/Feature%201")
                .then()
                .statusCode(500);

        // Get features for a product
        RestAssured.given()
                .when()
                .get("http://localhost:12345/products/Apple%20Watch/features")
                .then()
                .statusCode(500);
    }
}

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class TestAddingProductAndConstraint {

    @Test
    public void testAddingProductAndConstraint() {
        // Add a new product to the database
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post("http://localhost:12345/products/Apple%20Watch")
                .then()
                .statusCode(201);

        // Add a requires constraint to the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Feature1")
                .formParam("requiredFeature", "Feature2")
                .post("http://localhost:12345/products/Apple%20Watch/constraints/requires")
                .then()
                .statusCode(201);

        // Delete the constraint from the product
        RestAssured.given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .delete("http://localhost:12345/products/Apple%20Watch/constraints/1")
                .then()
                .statusCode(204);
    }
}

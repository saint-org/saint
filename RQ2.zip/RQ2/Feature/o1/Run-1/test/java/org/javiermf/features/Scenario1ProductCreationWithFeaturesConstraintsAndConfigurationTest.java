package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@TestMethodOrder(OrderAnnotation.class)
public class Scenario1ProductCreationWithFeaturesConstraintsAndConfigurationTest {

    static {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    @Order(1)
    void createNewProductLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("/products/Laptop")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(2)
    void addFeatureTouchScreenToLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Supports stylus usage")
        .when()
            .post("/products/Laptop/features/TouchScreen")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(3)
    void addFeatureStylusToLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Supports stylus usage")
        .when()
            .post("/products/Laptop/features/TouchScreen")
        .then()
            .statusCode(500);
    }

    @Test
    @Order(4)
    void addFeatureFingerprintScanToLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Enhanced security")
        .when()
            .post("/products/Laptop/features/FingerprintScan")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(5)
    void addRequiresConstraintBetweenTouchScreenAndStylus() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("sourceFeature", "TouchScreen")
            .formParam("requiredFeature", "Stylus")
        .when()
            .post("/products/Laptop/constraints/requires")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(6)
    void addExcludesConstraintBetweenStylusAndFingerprintScan() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("sourceFeature", "Stylus")
            .formParam("excludedFeature", "FingerprintScan")
        .when()
            .post("/products/Laptop/constraints/excludes")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(7)
    void addANewConfigurationBaseConfigToLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("/products/Laptop/configurations/BaseConfig")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(8)
    void addFeatureTouchScreenToBaseConfigInLaptop() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("/products/Laptop/configurations/BaseConfig/features/TouchScreen")
        .then()
            .statusCode(500);
    }

    @Test
    @Order(9)
    void addFeatureStylusToLaptopAgainToEnsureItExists() {
        given()
        .when()
            .get("/products/Laptop/configurations/BaseConfig/features")
        .then()
            .statusCode(200)
            .body(equalTo("[]"));
    }
}

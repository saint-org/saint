package com.example.tests.scenario2;

import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Scenario2RemovingAFeatureFromProductAndConfigurationsTest {

    @Test
    void removeTheFeatureGPSFromTheProductSmartPhoneAndAnyActiveProductConfigurations() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("http://localhost:12345/products/SmartPhone/features/GPS")
        .then()
            .statusCode(500);
    }

    @Test
    void cannotRetrieveFeaturesForSmartPhoneBecauseItDoesNotExist() {
        given()
        .when()
            .get("http://localhost:12345/products/SmartPhone/features")
        .then()
            .statusCode(500);
    }

    @Test
    void cannotVerifyGPSInDefaultConfigForSmartPhoneBecauseItDoesNotExist() {
        given()
        .when()
            .get("http://localhost:12345/products/SmartPhone/configurations/DefaultConfig/features")
        .then()
            .statusCode(500);
    }
}

package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AddVerifyAndRemoveProductConstraintsTest {

    private static final String BASE_URI = "http://localhost:12345";
    private static final String PRODUCT_NAME = "LaptopPro";
    private static int requiresConstraintId;
    private static int excludesConstraintId;

    static {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    @Order(1)
    void addRequiresConstraint() {
        // Add 'requires' constraint
        requiresConstraintId =
            given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "ExtendedWarranty")
                .formParam("requiredFeature", "ShippingInsurance")
            .when()
                .post("/products/{productName}/constraints/requires", PRODUCT_NAME)
            .then()
                .statusCode(201)
                .extract().path("id");
    }

    @Test
    @Order(2)
    void addExcludesConstraint() {
        // Add 'excludes' constraint
        excludesConstraintId =
            given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "ExtendedWarranty")
                .formParam("excludedFeature", "BaseWarranty")
            .when()
                .post("/products/{productName}/constraints/excludes", PRODUCT_NAME)
            .then()
                .statusCode(201)
                .extract().path("id");
    }

    @Test
    @Order(3)
    void deleteRequiresConstraint() {
        // Delete the previously added 'requires' constraint
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("/products/{productName}/constraints/{constraintId}", PRODUCT_NAME, requiresConstraintId)
        .then()
            .statusCode(204);
    }
}

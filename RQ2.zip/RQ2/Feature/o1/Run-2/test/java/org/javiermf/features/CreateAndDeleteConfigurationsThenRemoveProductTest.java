import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.isEmptyOrNullString;

public class CreateAndDeleteConfigurationsThenRemoveProductTest {

    @Test
    void createNewConfigurationForNotebookXNamedConfBasic() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("http://localhost:12345/products/NotebookX/configurations/ConfBasic")
        .then()
            .statusCode(500);
    }

    @Test
    void createProductNotebookX() {
        given()
        .when()
            .get("http://localhost:12345/products/NotebookX/configurations")
        .then()
            .statusCode(200)
            .body(equalTo("[]"));
    }

    @Test
    void getAllConfigurationsForProductNotebookX() {
        given()
        .when()
            .get("http://localhost:12345/products/NotebookX/configurations/ConfBasic")
        .then()
            .statusCode(204)
            .body(isEmptyOrNullString());
    }

    @Test
    void retrieveConfigurationConfBasicForProductNotebookX() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("http://localhost:12345/products/NotebookX/configurations/ConfBasic")
        .then()
            .statusCode(500);
    }

    @Test
    void deleteConfigurationConfBasicFromProductNotebookX() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("http://localhost:12345/products/NotebookX")
        .then()
            .statusCode(500);
    }
}

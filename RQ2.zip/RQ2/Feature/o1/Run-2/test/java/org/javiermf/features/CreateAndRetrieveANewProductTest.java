import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class CreateAndRetrieveANewProductTest {

    @Test
    void testCreateAndRetrieveNewProduct() {
        // Step 1: Add a new product 'LaptopPro'
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("http://localhost:12345/products/LaptopPro")
        .then()
            .statusCode(201);

        // Step 2: Get all products
        given()
        .when()
            .get("http://localhost:12345/products")
        .then()
            .statusCode(200)
            .body("$", hasItem("LaptopPro"));

        // Step 3: Get product by name 'LaptopPro'
        given()
        .when()
            .get("http://localhost:12345/products/LaptopPro")
        .then()
            .statusCode(200)
            .body("id", equalTo(1))
            .body("name", equalTo("LaptopPro"))
            .body("features", hasSize(0))
            .body("constraints", hasSize(0));
    }
}

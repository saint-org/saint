package com.example.tests;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ConfigureAProductAndManageActiveFeaturesTest {

    @Test
    @Order(1)
    void createConfigurationTest() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("http://localhost:12345/products/LaptopPro/configurations/LaptopProConf1")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(2)
    void activateFeatureTest() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .post("http://localhost:12345/products/LaptopPro/configurations/LaptopProConf1/features/ExtendedWarranty")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(3)
    void checkActiveFeaturesTest() {
        given()
        .when()
            .get("http://localhost:12345/products/LaptopPro/configurations/LaptopProConf1/features")
        .then()
            .statusCode(200)
            .body("$", hasSize(1))
            .body("$", hasItem("ExtendedWarranty"));
    }

    @Test
    @Order(4)
    void removeFeatureTest() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("http://localhost:12345/products/LaptopPro/configurations/LaptopProConf1/features/ExtendedWarranty")
        .then()
            .statusCode(204);
    }

    @Test
    @Order(5)
    void checkActiveFeaturesAgainTest() {
        given()
        .when()
            .get("http://localhost:12345/products/LaptopPro/configurations/LaptopProConf1/features")
        .then()
            .statusCode(200)
            .body("$", hasSize(0));
    }
}

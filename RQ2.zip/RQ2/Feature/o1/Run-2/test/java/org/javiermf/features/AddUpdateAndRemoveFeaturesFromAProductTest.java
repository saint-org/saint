import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AddUpdateAndRemoveFeaturesFromAProductTest {

    @BeforeAll
    static void setUp() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    @Order(1)
    void addFeatureExtendedWarrantyToProductLaptopPro() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Extra 2 years of coverage")
        .when()
            .post("/products/LaptopPro/features/ExtendedWarranty")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(2)
    void addFeatureShippingInsuranceToProductLaptopPro() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Covers shipping damages")
        .when()
            .post("/products/LaptopPro/features/ShippingInsurance")
        .then()
            .statusCode(201);
    }

    @Test
    @Order(3)
    void getFeaturesForProductLaptopPro() {
        given()
        .when()
            .get("/products/LaptopPro/features")
        .then()
            .statusCode(200)
            .body("size()", is(2))
            .body("[0].id", is(1))
            .body("[0].name", is("ExtendedWarranty"))
            .body("[0].description", is("Extra 2 years of coverage"))
            .body("[1].id", is(2))
            .body("[1].name", is("ShippingInsurance"))
            .body("[1].description", is("Covers shipping damages"));
    }

    @Test
    @Order(4)
    void updateFeatureExtendedWarrantyForProductLaptopPro() {
        given()
            .contentType("application/x-www-form-urlencoded")
            .formParam("description", "Extra 2 years of coverage")
        .when()
            .put("/products/LaptopPro/features/ExtendedWarranty")
        .then()
            .statusCode(200)
            .body("id", is(1))
            .body("name", is("ExtendedWarranty"))
            .body("description", is("Extra 2 years of coverage"));
    }

    @Test
    @Order(5)
    void deleteFeatureShippingInsuranceForProductLaptopPro() {
        given()
            .contentType("application/x-www-form-urlencoded")
        .when()
            .delete("/products/LaptopPro/features/ShippingInsurance")
        .then()
            .statusCode(204);
    }

    @Test
    @Order(6)
    void getFeaturesForProductLaptopProToVerifyChanges() {
        given()
        .when()
            .get("/products/LaptopPro/features")
        .then()
            .statusCode(200)
            .body("size()", is(1))
            .body("[0].id", is(1))
            .body("[0].name", is("ExtendedWarranty"))
            .body("[0].description", is("Extra 2 years of coverage"));
    }
}

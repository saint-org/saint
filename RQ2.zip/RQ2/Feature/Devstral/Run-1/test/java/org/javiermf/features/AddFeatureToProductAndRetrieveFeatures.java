import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddFeatureToProductAndRetrieveFeatures {

    private static final String BASE_URI = "http://localhost:12345";
    private static final String PRODUCT_NAME = "product1";
    private static final String FEATURE_NAME = "feature1";
    private static final String DESCRIPTION = "This is a description";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    public void addFeatureToProductAndRetrieveFeatures() {
        // Add a feature 'Feature1' to 'Product1'
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", DESCRIPTION)
                .when()
                .post("/products/" + PRODUCT_NAME + "/features/" + FEATURE_NAME)
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the error message
        String errorMessage = response.getBody().asString();
        assert errorMessage.contains("Object with id product1 has not been found");

        // Create 'Product1' before retrieving features
        response = given()
                .when()
                .get("/products/" + PRODUCT_NAME + "/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the error message
        errorMessage = response.getBody().asString();
        assert errorMessage.contains("Object with id product1 has not been found");
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddExcludesConstraintToProductTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testAddExcludesConstraintToProduct() {
        // Retrieve the product 'Product1' before adding the excludes constraint
        Response response = given()
                .when()
                .get("/products/Product1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Add an excludes constraint to 'Product1'
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Feature1")
                .formParam("excludedFeature", "Feature4")
                .when()
                .post("/products/Product1/constraints/excludes")
                .then()
                .statusCode(500);

        // Retrieve the product 'Product1' after adding the excludes constraint
        given()
                .when()
                .get("/products/Product1")
                .then()
                .statusCode(500);
    }
}

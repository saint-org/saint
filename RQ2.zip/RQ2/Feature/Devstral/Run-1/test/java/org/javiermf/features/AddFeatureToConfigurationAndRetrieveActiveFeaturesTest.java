import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddFeatureToConfigurationAndRetrieveActiveFeaturesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void addFeatureToConfigurationAndRetrieveActiveFeatures() {
        // Add a feature to a product configuration
        Response addFeatureResponse = given()
                .when()
                .post("/products/Product1/configurations/Config1/features/Feature1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, addFeatureResponse.statusCode());
        assertEquals("java.lang.NullPointerException", addFeatureResponse.jsonPath().getString("message"));

        // Retrieve active features for a product configuration
        Response getFeaturesResponse = given()
                .when()
                .get("/products/Product1/configurations/Config1/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, getFeaturesResponse.statusCode());
        assertEquals("java.lang.NullPointerException", getFeaturesResponse.jsonPath().getString("message"));
    }
}

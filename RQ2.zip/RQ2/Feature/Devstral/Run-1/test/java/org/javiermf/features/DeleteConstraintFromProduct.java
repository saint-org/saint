import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class DeleteConstraintFromProduct {

    private static final String BASE_URI = "http://localhost:12345";
    private static final String PRODUCT_NAME = "product1";
    private static final Long CONSTRAINT_ID = 1L;

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    public void deleteConstraintFromProduct() {
        // Delete the constraint from 'Product1'
        Response deleteResponse = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/{productName}/constraints/{constraintId}", PRODUCT_NAME, CONSTRAINT_ID)
                .then()
                .statusCode(204)
                .extract()
                .response();

        // Retrieve the product 'product1'
        Response getResponse = given()
                .when()
                .get("/products/{productName}", PRODUCT_NAME)
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify that the constraint is not present
        String responseBody = getResponse.getBody().asString();
        assert responseBody.contains("Object with id product1 has not been found");
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.empty;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndDeleteConfigurationFromProductTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testDeleteAndRetrieveConfigurations() {
        // Delete the configuration 'Config1' from 'Product1'
        Response deleteResponse = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/Product1/configurations/Config1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve configurations for 'Product1' after ensuring the configuration 'Config1' exists
        Response getResponse = given()
                .when()
                .get("/products/Product1/configurations")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify that 'Config1' is not present in the list
        assertEquals(empty(), getResponse.jsonPath().getList("$"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndDeleteFeatureFromConfiguration {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testDeleteAndRetrieveFeatures() {
        // Delete the feature 'Feature1' from 'Config1'
        Response deleteResponse = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/Product1/configurations/Config1/features/Feature1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve active features for 'Product1' and 'Config1' after ensuring the feature 'Feature1' is deleted
        Response getResponse = given()
                .when()
                .get("/products/Product1/configurations/Config1/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify that 'Feature1' is not present in the list
        assertEquals(500, getResponse.statusCode());
        assertEquals("java.lang.NullPointerException", getResponse.jsonPath().getString("message"));
    }
}

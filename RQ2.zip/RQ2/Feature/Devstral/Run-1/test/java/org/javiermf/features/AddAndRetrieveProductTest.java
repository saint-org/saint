import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndRetrieveProductTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 12345;
    }

    @Test
    public void addAndRetrieveProductTest() {
        // Add a new product
        Response addProductResponse = given()
                .contentType("application/x-www-form-urlencoded")
                .post("/products/ProductA");

        assertEquals(201, addProductResponse.getStatusCode());

        // Retrieve all products
        Response getAllProductsResponse = given()
                .get("/products");

        assertEquals(200, getAllProductsResponse.getStatusCode());
        getAllProductsResponse.then()
                .body(containsInAnyOrder("ProductA", "ProductB", "ProductC", "ProductD", "ProductE"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddRequiresConstraintToProductTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 12345;
    }

    @Test
    public void testAddRequiresConstraintToProduct() {
        // Create the product 'Product1'
        Response response = given()
                .when()
                .get("/products/Product1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Add a requires constraint to 'Product1'
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Feature1")
                .formParam("requiredFeature", "Feature4")
                .when()
                .post("/products/Product1/constraints/requires")
                .then()
                .statusCode(500);

        // Retrieve the product 'Product1' and verify that the requires constraint is present
        given()
                .when()
                .get("/products/Product1")
                .then()
                .statusCode(500);
    }
}

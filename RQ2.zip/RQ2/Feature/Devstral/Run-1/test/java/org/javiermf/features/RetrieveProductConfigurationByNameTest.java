import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class RetrieveProductConfigurationByNameTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testRetrieveConfiguration() {
        String productName = "Product1";
        String configurationName = "Config1";

        Response response = RestAssured.given()
                .pathParam("productName", productName)
                .pathParam("configurationName", configurationName)
                .when()
                .get("/products/{productName}/configurations/{configurationName}");

        assertEquals(204, response.getStatusCode());
    }
}

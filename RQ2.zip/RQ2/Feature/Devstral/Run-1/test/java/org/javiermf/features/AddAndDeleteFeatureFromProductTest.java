import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddAndDeleteFeatureFromProductTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testDeleteAndRetrieveFeatures() {
        // Delete the feature 'Feature1' from 'Product1'
        Response deleteResponse = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/Product1/features/Feature1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve features for 'Product1'
        Response getResponse = given()
                .when()
                .get("/products/Product1/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify that 'Feature1' is not present in the list
        String responseBody = getResponse.getBody().asString();
        assert !responseBody.contains("Feature1");
    }
}

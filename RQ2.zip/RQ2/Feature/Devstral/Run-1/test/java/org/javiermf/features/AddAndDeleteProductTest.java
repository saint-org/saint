import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

class AddAndDeleteProductTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    void testDeleteAndRetrieveProducts() {
        // Delete the product 'Product1'
        Response deleteResponse = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/Product1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the error message
        String errorMessage = deleteResponse.getBody().asString();
        assertTrue(errorMessage.contains("Object with id Product1 has not been found"));

        // Retrieve all products
        Response getResponse = given()
                .when()
                .get("/products")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify 'Product1' is not present in the list
        String[] products = getResponse.getBody().as(String[].class);
        assertFalse(Arrays.asList(products).contains("Product1"));
    }
}

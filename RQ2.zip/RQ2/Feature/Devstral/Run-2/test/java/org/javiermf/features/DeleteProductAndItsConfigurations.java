import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class DeleteProductAndItsConfigurations {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void deleteProductAndItsConfigurations() {
        // Delete the 'Scanner' product
        Response response = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .delete("/products/Scanner")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the response body
        String responseBody = response.getBody().asString();
        assert responseBody.contains("Object with id Scanner has not been found");
    }
}

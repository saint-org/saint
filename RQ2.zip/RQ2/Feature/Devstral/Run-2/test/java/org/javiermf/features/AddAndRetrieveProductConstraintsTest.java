import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddAndRetrieveProductConstraintsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testAddAndRetrieveProductConstraints() {
        // Create the 'Tablet' product first before retrieving its details.
        Response response = given()
                .when()
                .get("/products/Tablet")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Add a 'requires' constraint 'Battery' to the 'Tablet' product.
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "Battery")
                .formParam("requiredFeature", "Battery")
                .when()
                .post("/products/Tablet/constraints/requires")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve the 'Tablet' product details.
        response = given()
                .when()
                .get("/products/Tablet")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify that the 'requires' constraint 'Battery' is present in the list of constraints for the 'Tablet' product.
        response.then()
                .body("constraints.requires", equalTo("Battery"));
    }
}

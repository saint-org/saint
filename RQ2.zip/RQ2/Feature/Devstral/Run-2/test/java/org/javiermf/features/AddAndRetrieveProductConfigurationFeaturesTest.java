import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndRetrieveProductConfigurationFeaturesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testAddAndRetrieveProductConfigurationFeatures() {
        // Add a feature 'Duplex' to the 'Color' configuration of the 'Printer' product
        Response response = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .post("/products/Printer/configurations/Color/features/Duplex")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, response.statusCode());
        assertEquals("java.lang.NullPointerException", response.jsonPath().getString("message"));

        // Retrieve the active features for the 'Color' configuration of the 'Printer' product after fixing the NullPointerException error
        response = given()
                .when()
                .get("/products/Printer/configurations/Color/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, response.statusCode());
        assertEquals("java.lang.NullPointerException", response.jsonPath().getString("message"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddAndDeleteProductFeatureWithConstraints {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testAddAndDeleteProductFeatureWithConstraints() {
        // Add an 'excludes' constraint 'VGA' to the 'Monitor' product
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("sourceFeature", "HDMI")
                .formParam("excludedFeature", "VGA")
                .when()
                .post("/products/Monitor/constraints/excludes")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the response
        String responseBody = response.getBody().asString();
        assert responseBody.contains("Object with id Monitor has not been found");

        // Delete the 'HDMI' feature from the 'Monitor' product
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .delete("/products/Monitor/features/HDMI")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the response
        responseBody = response.getBody().asString();
        assert responseBody.contains("Object with id Monitor has not been found");
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndRetrieveProductWithMultipleFeatures {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 12345;
    }

    @Test
    public void testAddAndRetrieveProductWithMultipleFeatures() {
        // Create the product 'Speaker'
        Response createProductResponse = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("name", "Speaker")
                .formParam("description", "A portable speaker")
                .post("/products")
                .then()
                .statusCode(201)
                .extract()
                .response();

        // Add 'Bluetooth' feature to 'Speaker' product
        Response addBluetoothFeatureResponse = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", "Description1")
                .post("/products/Speaker/features/Bluetooth")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Add 'Wi-Fi' feature to 'Speaker' product
        Response addWiFiFeatureResponse = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", "Description2")
                .post("/products/Speaker/features/Wi-Fi")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve all features for 'Speaker' product
        Response retrieveFeaturesResponse = given()
                .get("/products/Speaker/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Verify the responses
        assertEquals("HTTP Status 500 - org.javiermf.features.exceptions.ObjectNotFoundException: Object with id Speaker has not been found",
                addBluetoothFeatureResponse.getBody().asString());
        assertEquals("HTTP Status 500 - org.javiermf.features.exceptions.ObjectNotFoundException: Object with id Speaker has not been found",
                addWiFiFeatureResponse.getBody().asString());
        assertEquals("HTTP Status 500 - org.javiermf.features.exceptions.ObjectNotFoundException: Object with id Speaker has not been found",
                retrieveFeaturesResponse.getBody().asString());
    }
}

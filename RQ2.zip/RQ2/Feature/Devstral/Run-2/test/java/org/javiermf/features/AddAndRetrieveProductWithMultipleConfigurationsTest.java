import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndRetrieveProductWithMultipleConfigurationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 12345;
    }

    @Test
    public void testAddAndRetrieveProductWithMultipleConfigurations() {
        // Add 'Mechanical' configuration to 'Keyboard' product
        Response response1 = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .post("/products/Keyboard/configurations/Mechanical")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Add 'Membrane' configuration to 'Keyboard' product
        Response response2 = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .when()
                .post("/products/Keyboard/configurations/Membrane")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Retrieve all configurations for 'Keyboard' product
        Response response3 = given()
                .when()
                .get("/products/Keyboard/configurations")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Verify that both 'Mechanical' and 'Membrane' configurations are present in the list of configurations for the 'Keyboard' product
        assertEquals("[\"Mechanical\", \"Membrane\"]", response3.getBody().asString());
    }
}

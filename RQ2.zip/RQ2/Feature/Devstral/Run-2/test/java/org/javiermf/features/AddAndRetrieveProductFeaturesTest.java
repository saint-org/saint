import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddAndRetrieveProductFeaturesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 12345;
    }

    @Test
    public void testAddAndRetrieveProductFeatures() {
        // Add a feature 'Wi-Fi' to the 'Laptop' product
        Response response = given()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("description", "Description1")
                .when()
                .post("/products/ProductA/features/Feature1")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, response.statusCode());
        assertEquals("Object with id ProductA has not been found", response.jsonPath().getString("message"));

        // Retrieve all features for the 'Laptop' product
        response = given()
                .when()
                .get("/products/Laptop/features")
                .then()
                .statusCode(500)
                .extract()
                .response();

        assertEquals(500, response.statusCode());
        assertEquals("Object with id Laptop has not been found", response.jsonPath().getString("message"));
    }
}

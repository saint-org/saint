import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddAndDeleteProductFeatureWithConfigurationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void testAddAndDeleteProductFeatureWithConfiguration() {
        // Add a feature 'Zoom' to the 'Camera' product
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", "Description1")
                .when()
                .post("/products/Camera/features/Zoom")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Activate the 'Zoom' feature in the 'Pro' configuration
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .post("/products/Camera/configurations/Pro/features/Zoom")
                .then()
                .statusCode(500)
                .extract()
                .response();

        // Delete the 'Zoom' feature from the 'Camera' product
        response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .delete("/products/Camera/features/Zoom")
                .then()
                .statusCode(500)
                .extract()
                .response();
    }
}

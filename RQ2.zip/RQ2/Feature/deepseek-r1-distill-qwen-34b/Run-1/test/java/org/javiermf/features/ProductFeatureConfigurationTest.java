import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

public class ProductFeatureConfigurationTest {

    private static final String BASE_URL = "http://localhost:12345";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void addFeatureToProduct() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("description", "Global Positioning System feature")
            .when()
                .post("/products/SmartWatch/features/GPS")
            .then()
                .statusCode(200)
                .body(containsString("Feature GPS added to product SmartWatch"));
    }

    @Test
    public void addFeatureToConfiguration() {
        given()
            .when()
                .post("/products/SmartWatch/configurations/Standard/features/GPS")
            .then()
                .statusCode(200)
                .body(containsString("Feature GPS added to configuration Standard"));
    }

    @Test
    public void retrieveActiveFeatures() {
        Response response = given()
            .when()
                .get("/products/SmartWatch/configurations/Standard/features")
            .then()
                .statusCode(200)
                .extract().response();

        String features = response.jsonPath().getString("features");
        assert features.contains("GPS");
    }
}

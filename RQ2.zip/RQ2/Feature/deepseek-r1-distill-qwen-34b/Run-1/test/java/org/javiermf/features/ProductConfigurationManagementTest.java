import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class ProductConfigurationManagementTest {

    private static final String BASE_URL = "http://localhost:12345";
    private Response response;

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = BASE_URL;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }

    @Test
    void test1_AddNewConfiguration() {
        response = given()
                .contentType(ContentType.URLENC)
                .when()
                .post("/products/Laptop/configurations/Premium")
                .then()
                .extract().response();

        // Validate the status code
        response.then().statusCode(500);
        // Validate the response body contains the expected error message
        response.then().body(containsString("Object with id Laptop has not been found"));
    }

    @Test
    void test2_RetrieveAllConfigurations() {
        response = given()
                .when()
                .get("/products/Laptop/configurations")
                .then()
                .extract().response();

        // Validate the status code
        response.then().statusCode(200);
        // Validate the response body is an empty array
        response.then().body(equalTo("[]"));
    }

    @Test
    void test3_DeleteBasicConfiguration() {
        response = given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Laptop/configurations/Basic")
                .then()
                .extract().response();

        // Validate the status code
        response.then().statusCode(500);
        // Validate the response body contains the expected error message
        response.then().body(containsString("attempt to create delete event with null entity"));
    }
}

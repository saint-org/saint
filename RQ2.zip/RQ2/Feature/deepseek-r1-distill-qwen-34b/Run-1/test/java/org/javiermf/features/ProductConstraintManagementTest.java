import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductConstraintManagementTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void addRequiresConstraint() {
        Response response = given()
                .contentType(ContentType.URLENC)
                .formParam("sourceFeature", "OS")
                .formParam("requiredFeature", "Storage")
                .when()
                .post("/products/Tablet/constraints/requires")
                .then()
                .extract().response();

        assertEquals(500, response.statusCode());
    }

    @Test
    public void addExcludesConstraint() {
        Response response = given()
                .contentType(ContentType.URLENC)
                .formParam("sourceFeature", "OS")
                .formParam("excludedFeature", "Battery")
                .when()
                .post("/products/Tablet/constraints/excludes")
                .then()
                .extract().response();

        assertEquals(500, response.statusCode());
    }

    @Test
    public void deleteRequiresConstraint() {
        Response response = given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Tablet/constraints/1")
                .then()
                .extract().response();

        assertEquals(204, response.statusCode());
    }
}

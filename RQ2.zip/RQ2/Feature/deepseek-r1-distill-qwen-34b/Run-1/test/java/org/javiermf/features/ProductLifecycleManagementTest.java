import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductLifecycleManagementTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseUri = "http://localhost:12345";
    }

    @Test
    public void testAddNewProductSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .post("/products/SmartTV")
                .then()
                .extract().response();
        
        assertEquals(201, response.statusCode());
    }

    @Test
    public void testAddFeature4KDisplayToSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", "High%20resolution%204K%20display")
                .when()
                .post("/products/SmartTV/features/4K%20Display")
                .then()
                .extract().response();
        
        assertEquals(201, response.statusCode());
    }

    @Test
    public void testAddFeatureSmartAItoSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("description", "Advanced%20AI%20processing")
                .when()
                .post("/products/SmartTV/features/SmartAI")
                .then()
                .extract().response();
        
        assertEquals(201, response.statusCode());
    }

    @Test
    public void testAddConfigurationBaseToSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .post("/products/SmartTV/configurations/Base")
                .then()
                .extract().response();
        
        assertEquals(201, response.statusCode());
    }

    @Test
    public void testAddConfigurationPremiumToSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .post("/products/SmartTV/configurations/Premium")
                .then()
                .extract().response();
        
        assertEquals(201, response.statusCode());
    }

    @Test
    public void testDeleteProductSmartTV() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .when()
                .delete("/products/SmartTV")
                .then()
                .extract().response();
        
        assertEquals(204, response.statusCode());
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

public class ProductFeatureManagementTest {

    private static final String BASE_URI = "http://localhost:12345";
    private static final String PRODUCT_NAME = "SmartPhone";
    private static final String FEATURES_ENDPOINT = "/products/%s/features";
    private static final String ADD_FEATURE_ENDPOINT = "/products/%s/features/%s";
    private static final String UPDATE_FEATURE_ENDPOINT = "/products/%s/features/%s";
    private static final String DELETE_FEATURE_ENDPOINT = "/products/%s/features/%s";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    public void addNewFeatureScreenToSmartPhone() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("description", "High-quality display")
                .when()
                .post(String.format(ADD_FEATURE_ENDPOINT, PRODUCT_NAME, "Screen"))
                .then()
                .statusCode(500)
                .body(containsString("Object with id SmartPhone has not been found"));
    }

    @Test
    public void updateDescriptionOfCameraFeature() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("description", "High-Resolution Camera")
                .when()
                .put(String.format(UPDATE_FEATURE_ENDPOINT, PRODUCT_NAME, "Camera"))
                .then()
                .statusCode(500)
                .body(containsString("Object with id SmartPhone has not been found"));
    }

    @Test
    public void deleteBatteryFeature() {
        given()
                .when()
                .delete(String.format(DELETE_FEATURE_ENDPOINT, PRODUCT_NAME, "Battery"))
                .then()
                .statusCode(500)
                .body(containsString("Object with id SmartPhone has not been found"));
    }
}

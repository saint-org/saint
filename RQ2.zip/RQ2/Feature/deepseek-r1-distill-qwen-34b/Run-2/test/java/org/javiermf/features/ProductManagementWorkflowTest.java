import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class ProductManagementWorkflowTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void addNewProduct() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .post("/products/Laptop")
                .then()
                .statusCode(201);
    }

    @Test
    public void retrieveAllProducts() {
        given()
                .when()
                .get("/products")
                .then()
                .statusCode(200)
                .body(equalTo("[\"Laptop\"]"));
    }

    @Test
    public void addFeatureToProduct() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("description", "Description%20for%20feature1")
                .when()
                .post("/products/Laptop/features/Battery")
                .then()
                .statusCode(201);
    }

    @Test
    public void retrieveFeaturesForProduct() {
        given()
                .when()
                .get("/products/Laptop/features")
                .then()
                .statusCode(200)
                .body("id", notNullValue())
                .body("name", equalTo("Battery"))
                .body("description", equalTo("Description for feature1"));
    }

    @Test
    public void addConfigurationToProduct() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .post("/products/Laptop/configurations/Basic")
                .then()
                .statusCode(201);
    }

    @Test
    public void retrieveConfigurationsForProduct() {
        given()
                .when()
                .get("/products/Laptop/configurations")
                .then()
                .statusCode(200)
                .body(equalTo("[\"Basic\"]"));
    }

    @Test
    public void addConstraintToProduct() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("sourceFeature", "Battery")
                .formParam("requiredFeature", "Battery")
                .when()
                .post("/products/Laptop/constraints/requires")
                .then()
                .statusCode(201);
    }

    @Test
    public void attemptToDeleteFeature() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Laptop/features/Battery")
                .then()
                .statusCode(204);
    }

    @Test
    public void deleteConstraint() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Laptop/constraints/1")
                .then()
                .statusCode(204);
    }

    @Test
    public void successfullyDeleteFeature() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Laptop/features/Battery")
                .then()
                .statusCode(500);
    }

    @Test
    public void deleteProduct() {
        given()
                .contentType(ContentType.URLENC)
                .when()
                .delete("/products/Laptop")
                .then()
                .statusCode(204);
    }
}

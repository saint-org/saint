import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ConstraintManagementWorkflowTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        // Create 'Tablet' product before each test
        given()
            .contentType(ContentType.URLENC)
            .formParam("name", "Tablet")
            .formParam("description", "A tablet device")
            .when()
            .post("/products")
            .then()
            .statusCode(201);
    }

    @AfterEach
    public void teardown() {
        // Delete 'Tablet' product after each test
        given()
            .contentType(ContentType.URLENC)
            .when()
            .delete("/products/Tablet")
            .then()
            .statusCode(204);
    }

    @Test
    public void testConstraintManagementWorkflow() {
        // 1. Add a constraint requiring 'Screen' for 'Tablet'
        given()
            .contentType(ContentType.URLENC)
            .formParam("sourceFeature", "Screen")
            .formParam("requiredFeature", "Screen")
            .when()
            .post("/products/Tablet/constraints/requires")
            .then()
            .statusCode(201);

        // 2. Attempt to delete 'Screen' feature
        given()
            .contentType(ContentType.URLENC)
            .when()
            .delete("/products/Tablet/features/Screen")
            .then()
            .statusCode(400)
            .body(containsString("Cannot delete feature Screen as it is required by a constraint"));

        // 3. Verify deletion is prevented due to constraint
        given()
            .when()
            .get("/products/Tablet/features")
            .then()
            .statusCode(200)
            .body(containsString("Screen"));

        // 4. Add a constraint excluding 'Battery' with 'Screen'
        given()
            .contentType(ContentType.URLENC)
            .formParam("sourceFeature", "Screen")
            .formParam("excludedFeature", "Battery")
            .when()
            .post("/products/Tablet/constraints/excludes")
            .then()
            .statusCode(201);

        // 5. Attempt to add 'Battery' to 'Basic' configuration
        given()
            .contentType(ContentType.URLENC)
            .when()
            .post("/products/Tablet/configurations/Basic/features/Battery")
            .then()
            .statusCode(400)
            .body(containsString("Cannot add feature Battery as it is excluded by a constraint"));

        // 6. Verify addition is prevented due to exclusion constraint
        given()
            .when()
            .get("/products/Tablet/configurations/Basic/features")
            .then()
            .statusCode(200)
            .body(not(containsString("Battery")));

        // 7. Delete the exclusion constraint
        given()
            .contentType(ContentType.URLENC)
            .when()
            .delete("/products/Tablet/constraints/2")
            .then()
            .statusCode(204);

        // 8. Successfully add 'Battery' to 'Basic' configuration
        given()
            .contentType(ContentType.URLENC)
            .when()
            .post("/products/Tablet/configurations/Basic/features/Battery")
            .then()
            .statusCode(201);

        // 9. Delete the requirement constraint
        given()
            .contentType(ContentType.URLENC)
            .when()
            .delete("/products/Tablet/constraints/1")
            .then()
            .statusCode(204);

        // 10. Successfully delete 'Screen' feature
        given()
            .contentType(ContentType.URLENC)
            .when()
            .delete("/products/Tablet/features/Screen")
            .then()
            .statusCode(204);

        // Verify 'Tablet' product has features 'Battery' and configurations 'Basic' with 'Battery'
        given()
            .when()
            .get("/products/Tablet/features")
            .then()
            .statusCode(200)
            .body(containsString("Battery"));

        given()
            .when()
            .get("/products/Tablet/configurations/Basic/features")
            .then()
            .statusCode(200)
            .body(containsString("Battery"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class UpdatingAndDeletingProductFeaturesTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.JSON).accept(ContentType.JSON);
    }

    @Test
    public void updatingAndDeletingProductFeatures() {
        // Retrieve features for the product
        Response response = given().when().get("/products/product1/features").then().statusCode(500);
        // Update the description of a specified feature for the product
        response = given().when().put("/products/product1/features/feature1")
                .param("description", "A detailed description of the feature.")
                .then().statusCode(500);
        // Delete a specific feature of the product
        response = given().when().delete("/products/product1/features/feature1")
                .then().statusCode(500);
        // Retrieve features for the product again
        response = given().when().get("/products/product1/features").then().statusCode(500);
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class ManagingProductConfigurationsTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.JSON).accept(ContentType.JSON);
    }

    @Test
    public void managingProductConfigurations() {
        // Retrieve configurations for the product
        given()
            .when()
            .get("/products/product1/configurations")
            .then()
            .statusCode(200)
            .body("$.length()", equalTo(0));

        // Add a new configuration to the product
        given()
            .when()
            .post("/products/product1/configurations/newConfigurationName")
            .then()
            .statusCode(500);

        // Delete a specific configuration for the product
        given()
            .when()
            .delete("/products/product1/configurations/newConfigurationName")
            .then()
            .statusCode(500);

        // Retrieve configurations for the product after deletion
        given()
            .when()
            .get("/products/product1/configurations")
            .then()
            .statusCode(200)
            .body("$.length()", equalTo(0));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class ManagingProductConstraintsTest {

    private static final String BASE_URL = "http://localhost:12345";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void managingProductConstraints() {
        // Retrieve product by name
        given()
                .contentType(ContentType.URLENCODED)
                .param("name", "product1")
                .when()
                .post("/products/{name}/constraints/requires")
                .then()
                .statusCode(500);

        // Add requires constraint to product
        given()
                .contentType(ContentType.URLENCODED)
                .param("sourceFeature", "feature1")
                .param("requiredFeature", "feature6")
                .when()
                .post("/products/{name}/constraints/requires")
                .then()
                .statusCode(500);

        // Add excludes constraint to product
        given()
                .contentType(ContentType.URLENCODED)
                .param("sourceFeature", "feature1")
                .param("excludedFeature", "feature7")
                .when()
                .post("/products/{name}/constraints/excludes")
                .then()
                .statusCode(500);

        // Retrieve constraints for product
        given()
                .when()
                .get("/products/{name}/constraints")
                .then()
                .statusCode(500);
    }
}

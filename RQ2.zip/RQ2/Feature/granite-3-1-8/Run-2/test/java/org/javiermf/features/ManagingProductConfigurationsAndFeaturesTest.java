import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class ManagingProductConfigurationsAndFeaturesTest {

    private static final String BASE_URL = "http://localhost:12345";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void managingProductConfigurationsAndFeatures() {
        // Add a new feature to an existing product
        given()
            .contentType(ContentType.URLENCODED)
            .body("description=A%20detailed%20description%20of%20feature1")
            .when()
            .post("/products/product1/features/feature1")
            .then()
            .statusCode(500);

        // Add a requires constraint to the product, ensuring the product exists before adding the constraint
        given()
            .contentType(ContentType.URLENCODED)
            .param("sourceFeature", "feature1")
            .param("requiredFeature", "feature6")
            .when()
            .post("/products/product1/constraints/requires")
            .then()
            .statusCode(500);

        // Add a new configuration to the product, ensuring the product exists before adding the configuration
        given()
            .when()
            .post("/products/product1/configurations/config1")
            .then()
            .statusCode(500);

        // Retrieve the activated features for the product and its configuration, ensuring the product and configuration exist before retrieval
        given()
            .when()
            .get("/products/product1/configurations/config1/features")
            .then()
            .statusCode(500);
    }
}

package com.example.restassured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DeletingProductAndConfigurationsTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void deletingProductAndConfigurations() {
        // Delete product 'ProductA'
        Response deleteResponse = given()
                .when()
                .delete("/products/ProductA")
                .then()
                .statusCode(204);

        // Check if configurations 'ConfigA' and 'ConfigB' are still associated with 'ProductA'
        Response getConfigurationsResponse = given()
                .when()
                .get("/products/ProductA/configurations")
                .then()
                .statusCode(200)
                .body("$.configurations", hasSize(0));

        // Verify the response
        assertEquals(204, deleteResponse.getStatusCode());
        assertEquals(200, getConfigurationsResponse.getStatusCode());
        assertEquals([], getConfigurationsResponse.jsonPath().get("configurations"));
    }
}

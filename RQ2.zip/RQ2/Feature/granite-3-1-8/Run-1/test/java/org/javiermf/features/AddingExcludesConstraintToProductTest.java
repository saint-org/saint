import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class AddingExcludesConstraintToProductTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.JSON).then().log().all();
    }

    @Test
    public void addingExcludesConstraintToProduct() {
        // Retrieve 'ProductA' from the database
        given()
            .when()
            .get("/products/ProductA")
            .then()
            .statusCode(500);

        // Add an excludes constraint between 'FeatureA' and 'FeatureB' for 'ProductA'
        given()
            .when()
            .post("/products/ProductA/constraints/excludes")
            .param("sourceFeature", "FeatureA")
            .param("excludedFeature", "FeatureB")
            .then()
            .statusCode(500);

        // Verify that 'ProductA' now has the excludes constraint between 'FeatureA' and 'FeatureB'
        given()
            .when()
            .get("/products/ProductA")
            .then()
            .statusCode(500);

        // Verify that a requires constraint cannot be added between 'FeatureA' and 'FeatureB' for 'ProductA'
        given()
            .when()
            .post("/products/ProductA/constraints/requires")
            .param("sourceFeature", "FeatureA")
            .param("requiredFeature", "FeatureB")
            .then()
            .statusCode(500);
    }
}

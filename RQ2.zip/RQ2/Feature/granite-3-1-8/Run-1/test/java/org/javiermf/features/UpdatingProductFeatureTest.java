import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class UpdatingProductFeatureTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.JSON).accept(ContentType.JSON);
    }

    @Test
    public void updatingProductFeature() {
        // Retrieve features for ProductA
        given()
            .when()
                .get("/products/ProductA/features")
            .then()
                .statusCode(500);

        // Ensure that the product exists before attempting to update its features
        given()
            .when()
                .put("/products/ProductA/features/FeatureA")
                .param("description", "Updated description for FeatureA")
            .then()
                .statusCode(500);

        // Verify that the updated description for FeatureA is returned in the list of features for ProductA
        given()
            .when()
                .get("/products/ProductA/features")
            .then()
                .statusCode(500);

        // Verify that FeatureA cannot be deleted from ProductA due to the updated description
        given()
            .when()
                .delete("/products/ProductA/features/FeatureA")
            .then()
                .statusCode(500);
    }
}

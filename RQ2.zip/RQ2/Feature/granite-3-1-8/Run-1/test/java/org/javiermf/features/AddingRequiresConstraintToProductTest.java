package com.example.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class AddingRequiresConstraintToProductTest {

    private static final String PRODUCT_A = "ProductA";
    private static final String FEATURE_A = "FeatureA";
    private static final String FEATURE_B = "FeatureB";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
    }

    @Test
    public void addingRequiresConstraintToProduct() {
        // Retrieve 'ProductA' using 'getProductByName(String)' method
        given()
                .when()
                .get("/products/" + PRODUCT_A)
                .then()
                .statusCode(200)
                .body("name", equalTo(PRODUCT_A));

        // Add a requires constraint between 'FeatureA' and 'FeatureB' for 'ProductA' using 'addRequiresConstraintToProduct(String, String, String)' method
        given()
                .when()
                .post("/products/" + PRODUCT_A + "/constraints/requires")
                .contentType(ContentType.URLENCODED)
                .param("sourceFeature", FEATURE_A)
                .param("requiredFeature", FEATURE_B)
                .then()
                .statusCode(201);

        // Verify that 'ProductA' now has the requires constraint between 'FeatureA' and 'FeatureB'
        given()
                .when()
                .get("/products/" + PRODUCT_A)
                .then()
                .statusCode(200)
                .body("constraints.size()", is(1))
                .body("constraints[0].sourceFeature", equalTo(FEATURE_A))
                .body("constraints[0].requiredFeature", equalTo(FEATURE_B));

        // Attempt to add an excludes constraint between 'FeatureA' and 'FeatureB' for 'ProductA' using 'addExcludesConstraintToProduct(String, String, String)' method
        given()
                .when()
                .post("/products/" + PRODUCT_A + "/constraints/excludes")
                .contentType(ContentType.URLENCODED)
                .param("sourceFeature", FEATURE_A)
                .param("excludedFeature", FEATURE_B)
                .then()
                .statusCode(400);
    }
}

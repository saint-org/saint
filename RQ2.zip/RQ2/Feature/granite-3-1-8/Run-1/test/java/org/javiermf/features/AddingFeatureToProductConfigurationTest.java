import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class AddingFeatureToProductConfigurationTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.URLENCODED).configure().filter(new FeatureFilter());
    }

    @Test
    public void addingFeatureToProductConfiguration() {
        // Given
        String productName = "ProductA";
        String configName = "ConfigA";
        String featureName = "FeatureA";

        // When
        // Add FeatureA to ProductA
        given()
                .pathParam("productName", productName)
                .pathParam("configName", configName)
                .pathParam("featureName", featureName)
                .when()
                .post("/products/{productName}/configurations/{configName}/features/{featureName}")
                .then()
                .statusCode(500);

        // Then
        // Verify that FeatureA is added to ProductA
        given()
                .pathParam("productName", productName)
                .when()
                .get("/products/{productName}/features")
                .then()
                .statusCode(200)
                .body("features", hasItem(featureName));

        // Verify that FeatureA is activated for ProductA and ConfigA
        given()
                .pathParam("productName", productName)
                .pathParam("configName", configName)
                .when()
                .get("/products/{productName}/configurations/{configName}/features")
                .then()
                .statusCode(200)
                .body("features", hasItem(featureName));
    }
}

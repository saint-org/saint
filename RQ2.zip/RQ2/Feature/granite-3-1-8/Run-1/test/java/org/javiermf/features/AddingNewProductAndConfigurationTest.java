package com.example.restassured;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class AddingNewProductAndConfigurationTest {

    @Test
    public void addingNewProductAndConfiguration() {
        // Add a new product 'ProductA' to the database
        given()
                .contentType(ContentType.URLENCODED)
                .body("name", "ProductA")
                .when()
                .post("http://localhost:12345/products/ProductA")
                .then()
                .statusCode(201);

        // Add a new configuration 'ConfigA' to 'ProductA'
        given()
                .contentType(ContentType.URLENCODED)
                .body("name", "ConfigA")
                .when()
                .post("http://localhost:12345/products/ProductA/configurations/ConfigA")
                .then()
                .statusCode(201);

        // Verify that 'ProductA' is in the list of products
        given()
                .when()
                .get("http://localhost:12345/products")
                .then()
                .statusCode(200)
                .body("$.products[0].name", equalTo("ProductA"));

        // Verify that 'ConfigA' is the configuration for 'ProductA'
        given()
                .when()
                .get("http://localhost:12345/products/ProductA/configurations")
                .then()
                .statusCode(200)
                .body("$.configurations[0].name", equalTo("ConfigA"));
    }
}

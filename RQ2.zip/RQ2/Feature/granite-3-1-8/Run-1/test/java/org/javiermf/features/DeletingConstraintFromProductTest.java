import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class DeletingConstraintFromProductTest {

    private static final String PRODUCT_A_NAME = "ProductA";
    private static final String SOURCE_FEATURE = "FeatureA";
    private static final String REQUIRED_FEATURE = "FeatureB";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:12345";
        RestAssured.when().contentType(ContentType.JSON).then().log().all();
    }

    @Test
    public void deletingConstraintFromProduct() {
        // Retrieve 'ProductA' without the requires constraint between 'FeatureA' and 'FeatureB'
        given()
            .when()
                .get("/products/" + PRODUCT_A_NAME)
            .then()
                .statusCode(500);

        // Delete the requires constraint between 'FeatureA' and 'FeatureB' for 'ProductA'
        given()
            .when()
                .delete("/products/" + PRODUCT_A_NAME + "/constraints/1L")
            .then()
                .statusCode(404);

        // Add a new requires constraint between 'FeatureA' and 'FeatureB' for 'ProductA'
        given()
            .when()
                .post("/products/" + PRODUCT_A_NAME + "/constraints/requires")
                .param("sourceFeature", SOURCE_FEATURE)
                .param("requiredFeature", REQUIRED_FEATURE)
            .then()
                .statusCode(500);
    }
}

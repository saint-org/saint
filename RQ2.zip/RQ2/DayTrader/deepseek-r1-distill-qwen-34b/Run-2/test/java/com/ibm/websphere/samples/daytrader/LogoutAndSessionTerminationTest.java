import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class LogoutAndSessionTerminationTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void testUserLogout() {
        Response response = given()
                .when()
                .get("/daytrader")
                .then()
                .extract().response();

        assertEquals(302, response.statusCode());
    }
}

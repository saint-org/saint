import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.MethodName.class)
public class AccountProfileUpdateTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void testUpdateUserProfile() {
        Response response = RestAssured.given()
                .when()
                .get("/daytrader")
                .then()
                .extract()
                .response();

        // Verify the HTTP status code
        int statusCode = response.getStatusCode();
        assert statusCode == 302 : "Expected status code 302, but got " + statusCode;
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.get;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserRegistrationAndLoginTest {

    @BeforeEach
    public void setUp() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void testUserRegistrationAndLogin() {
        // User registration
        Response registrationResponse = get("/daytrader");
        assertEquals(302, registrationResponse.statusCode());

        // Check if registration was successful
        Response checkResponse = get("/daytrader");
        assertEquals(302, checkResponse.statusCode());
    }
}

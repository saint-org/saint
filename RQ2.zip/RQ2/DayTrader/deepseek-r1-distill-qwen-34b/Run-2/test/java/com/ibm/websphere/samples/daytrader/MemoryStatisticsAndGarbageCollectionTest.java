import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MemoryStatisticsAndGarbageCollectionTest {

    private static final String BASE_URL = "http://localhost:9080/daytrader/servlet/ExplicitGC";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testRetrieveMemoryUsageAndExplicitGC() {
        Response response = RestAssured
                .given()
                .contentType(ContentType.HTML)
                .when()
                .get()
                .then()
                .statusCode(200)
                .extract()
                .response();

        String body = response.getBody().asString();
        // Verify that the response contains the expected HTML structure
        assertTrue(body.contains("Explicit Garbage Collection"));
        assertTrue(body.contains("Statistics before GC"));
        assertTrue(body.contains("Statistics after GC"));
        assertTrue(body.contains("Total Time in GC"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class GeneAndProteinCrossReferenceAnalysisTest {

    @Test
    void retrieveCrossReferencesForAGivenEnsemblGeneID() {
        given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .contentType(ContentType.JSON)
        .when()
            .get("/xrefs/ENSG00000169083")
        .then()
            .statusCode(200)
            .body("display_id", hasItems("NR3C4", "AR"))
            .body("dbname", hasItems("Uniprot_gn", "HGNC"));
    }

    @Test
    void convertEntrezGeneIDToEnsemblGeneID() {
        given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .contentType(ContentType.JSON)
        .when()
            .get("/ensembl/canonical-gene/entrez/23140")
        .then()
            .statusCode(200)
            .body("geneId", equalTo("ENSG00000074755"))
            .body("hugoSymbol", equalTo("ZZEF1"))
            .body("entrezGeneId", equalTo("23140"));
    }

    @Test
    void fetchEnsemblTranscriptsForTheGene() {
        given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .contentType(ContentType.JSON)
        .when()
            .get("/ensembl/transcript?geneId=ENSG00000136999&proteinId=ENSP00000439985&hugoSymbol=ARF5")
        .then()
            .statusCode(200)
            .body("transcriptId", hasSize(greaterThan(0)))
            .body("exons.exonId", hasItems("ENSE00001872691", "ENSE00003494180"));
    }

    @Test
    void verifyCompleteCrossReferencesAndTranscripts() {
        Response crossRefResponse = given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .when()
            .get("/xrefs/ENSG00000169083");

        crossRefResponse.then()
            .statusCode(200)
            .body("display_id", hasItems("NR3C4", "AR"))
            .body("dbname", hasItems("Uniprot_gn", "HGNC"));

        Response ensemblResponse = given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .when()
            .get("/ensembl/canonical-gene/entrez/23140");

        ensemblResponse.then()
            .statusCode(200)
            .body("geneId", equalTo("ENSG00000074755"))
            .body("hugoSymbol", equalTo("ZZEF1"))
            .body("entrezGeneId", equalTo("23140"));

        Response transcriptResponse = given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .when()
            .get("/ensembl/transcript?geneId=ENSG00000136999&proteinId=ENSP00000439985&hugoSymbol=ARF5");

        transcriptResponse.then()
            .statusCode(200)
            .body("transcriptId", hasSize(greaterThan(0)))
            .body("exons.exonId", hasItems("ENSE00001872691", "ENSE00003494180"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class ComprehensiveVariantAnnotationRetrievalTest {

    @Test
    void testFetchVariantAnnotations() {
        String requestPayload = "[\"X:g.66937331T>A\", \"17:g.41242962_41242963insGA\", \"1:g.182712A>C\", \"2:g.265023C>T\", \"3:g.319781del\", \"19:g.110753dup\", \"1:g.1385015_1387562del\"]";
        String expectedResponse = "[{\"variant\":\"X:g.66937331T>A\",\"colocatedVariants\":[{\"dbSnpId\":\"COSV65961566\"},{\"dbSnpId\":\"rs2147530610\"}],\"originalVariantQuery\":\"X:g.66937331T>A\",\"hgvsg\":\"X:g.66937331T>A\",\"id\":\"X:g.66937331T>A\",\"assembly_name\":\"GRCh37\",\"seq_region_name\":\"X\",\"start\":66937331,\"end\":66937331,\"allele_string\":\"T/A\",\"strand\":1,\"most_severe_consequence\":\"missense_variant\",\"transcript_consequences\":[...],\"successfully_annotated\":true}, ...]";
        
        Response response = given()
                .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
                .contentType(ContentType.JSON)
                .body(requestPayload)
                .when()
                .post("/annotation")
                .then()
                .statusCode(200)
                .extract().response();
        
        // Additional assertions can be added here if needed
    }

    @Test
    void testFetchHotspotAnnotations() {
        String requestPayload = "[\"X:g.66937331T>A\", \"17:g.41242962_41242963insGA\", \"1:g.182712A>C\", \"2:g.265023C>T\", \"3:g.319781del\", \"19:g.110753dup\", \"1:g.1385015_1387562del\"]";
        String expectedResponse = "[{\"variant\":\"X:g.66937331T>A\",\"hotspots\":[]}, ...]";
        
        given()
                .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
                .contentType(ContentType.JSON)
                .body(requestPayload)
                .when()
                .post("/cancer_hotspots/hgvs")
                .then()
                .statusCode(200)
                .body(equalTo(expectedResponse));
    }

    @Test
    void testFetchNucleotideContextAnnotations() {
        String requestPayload = "[\"X:g.66937331T>A\", \"17:g.41242962_41242963insGA\", \"1:g.182712A>C\", \"2:g.265023C>T\", \"3:g.319781del\", \"19:g.110753dup\", \"1:g.1385015_1387562del\"]";
        String expectedResponse = "[{\"query\":\"X:66937330..66937332:1\",\"molecule\":\"dna\",\"id\":\"chromosome:GRCh37:X:66937330:66937332:1\",\"seq\":\"CTT\",\"hgvs\":\"X:g.66937331T>A\"}, ...]";
        
        given()
                .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
                .contentType(ContentType.JSON)
                .body(requestPayload)
                .when()
                .post("/nucleotide_context")
                .then()
                .statusCode(200)
                .body(equalTo(expectedResponse));
    }
}

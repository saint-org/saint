import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.notNullValue;

public class SignalMutationAndAnnotationCorrelationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void retrieveSignalMutationsByHugoSymbol() {
        given()
                .when()
                .get("/signal/mutation")
                .then()
                .statusCode(200)
                .body("tumorType", containsString("Salivary Carcinoma"))
                .body("tumorTypeCount", notNullValue());
    }

    @Test
    public void fetchDetailedAnnotationsForEachMutation() {
        String variantId = "variant:.+";
        Response response = given()
                .pathParam("variant", variantId)
                .when()
                .get("/annotation/{variant}?isoformOverrideSource=uniprot&token=%7B%22uniprot%22%3A%22xyz789%22%7D&fields=hotspots%2Cannotations")
                .then()
                .statusCode(200)
                .extract().response();

        String responseBody = response.getBody().asString();
        assert responseBody.contains("\"variant\":\"" + variantId + "\"");
        assert responseBody.contains("\"successfully_annotated\":false");
    }
}

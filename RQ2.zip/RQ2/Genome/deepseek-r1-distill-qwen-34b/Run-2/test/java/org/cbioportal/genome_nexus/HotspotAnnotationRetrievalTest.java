import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

public class HotspotAnnotationRetrievalTest {

    private static final String BASE_URL = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testHotspotAnnotationRetrieval() {
        // Sub-Task 1: Retrieve hotspot annotations by HGVS
        String variant = "7:g.140453136A>T";
        Response getResponse = given()
                .pathParam("variant", variant)
                .when()
                .get("/cancer_hotspots/hgvs/{variant}")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        // Sub-Task 2: Validate variant and fetch additional annotations
        String requestBody = "[\"7:g.140453136A>T\"]";
        String token = "{ \"source1\": \"token1\", \"source2\": \"token2\" }";
        
        Response postResponse = given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", token)
                .queryParam("fields", "[\"hotspots\"]")
                .when()
                .post("/annotation")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        // Verify the response contains the expected variant
        assertTrue(postResponse.asString().contains(variant), "Variant not found in the response");

        // Verify the response contains hotspot annotations
        assertTrue(postResponse.asString().contains("hotspots"), "Hotspot annotations not found in the response");
    }
}

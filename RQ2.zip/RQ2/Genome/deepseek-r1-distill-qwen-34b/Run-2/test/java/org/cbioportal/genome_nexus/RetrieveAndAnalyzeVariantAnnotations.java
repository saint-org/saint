import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.notNullValue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class RetrieveAndAnalyzeVariantAnnotations {

    @BeforeEach
    void setUp() {
        RestAssured.baseUri = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    void testFetchVariantAnnotationSummaries() {
        String variant = "variant:.+";
        given()
                .contentType(ContentType.JSON)
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("projection", "ALL")
                .when()
                .get("/annotation/summary/{variant}", variant)
                .then()
                .statusCode(200)
                .body("variant", notNullValue())
                .body("genomicLocation.chromosome", notNullValue())
                .body("genomicLocation.start", notNullValue())
                .body("genomicLocation.end", notNullValue())
                .body("genomicLocation.referenceAllele", notNullValue())
                .body("genomicLocation.variantAllele", notNullValue());
    }

    @Test
    void testVerifyVariantDataRetrieval() {
        String variant = "[\"1:g.182712A>C\"]";
        String token = "%7B%22source1%22%3A%22token1%22%2C%22source2%22%3A%22token2%22%7D";
        
        Response response = given()
                .contentType(ContentType.JSON)
                .body(variant)
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", token)
                .queryParam("fields", "[\"hotspots\"]")
                .when()
                .post("/annotation");

        response.then()
                .statusCode(200)
                .body(containsString("\"variant\":\"1:g.182712A>C\""))
                .body(containsString("\"successfully_annotated\":false"));
    }
}

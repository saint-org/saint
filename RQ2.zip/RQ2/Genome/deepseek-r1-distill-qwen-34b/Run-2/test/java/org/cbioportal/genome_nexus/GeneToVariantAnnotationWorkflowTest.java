import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class GeneToVariantAnnotationWorkflowTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void testFetchCanonicalEnsemblGeneId() {
        String entrezGeneId = "1234";
        String expectedGeneId = "ENSG00000160791";
        String expectedHugoSymbol = "CCR5";

        Response response = given()
                .pathParam("entrezGeneId", entrezGeneId)
                .when()
                .get("/ensembl/canonical-gene/entrez/{entrezGeneId}")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        response.jsonPath().assertThat("geneId", equalTo(expectedGeneId));
        response.jsonPath().assertThat("hugoSymbol", equalTo(expectedHugoSymbol));
    }

    @Test
    public void testRetrieveVariantAnnotations() {
        String geneId = "ENSG00000160791";
        String variant = "variant:.+";
        String token = "{ \"uniprot\": \"xyz789\" }";
        String fields = "hotspots,annotations";

        Response response = given()
                .pathParam("variant", variant)
                .queryParam("isoformOverrideSource", "ensembl")
                .queryParam("token", token)
                .queryParam("fields", fields)
                .when()
                .get("/annotation/{variant}")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        response.jsonPath().assertThat("variant", notNullValue());
        response.jsonPath().assertThat("originalVariantQuery", notNullValue());
        response.jsonPath().assertThat("successfully_annotated", equalTo(false));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class NucleotideContextAndVariantAnnotationTest {

    private static String baseUrl = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = baseUrl;
    }

    @Test
    public void fetchNucleotideContextAnnotations() {
        String variant = "variant:.+";
        Response response = given()
                .pathParam("variant", variant)
                .when()
                .get("/nucleotide_context/{variant}")
                .then()
                .statusCode(200)
                .contentType("text/html")
                .extract().response();

        // Additional assertions can be added here if needed
    }

    @Test
    public void fetchVariantAnnotationsUsingNucleotideContextData() {
        String variant = "variant:.+";
        String token = "{ \"uniprot\": \"xyz789\" }";
        
        Response response = given()
                .pathParam("variant", variant)
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", token)
                .queryParam("fields", "hotspots,annotations")
                .when()
                .get("/annotation/{variant}")
                .then()
                .statusCode(200)
                .contentType("application/json")
                .body("variant", equalTo(variant))
                .body("successfully_annotated", is(false))
                .extract().response();
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.jupiter.api.TestMethodOrder.MethodOrderer.OrderAnnotation;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
public class BatchProcessingOfMultipleVariantsTest {

    private static final String BASE_URI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    private static Response postResponse;

    @BeforeAll
    public void setup() {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    public void submitListOfVariantsToFetchMyVariantInfoAnnotationPOST() {
        String requestBody = "[\"chr1:12345:A>T\", \"chr2:67890:G>C\"]";
        
        postResponse = given()
            .contentType(ContentType.JSON)
            .body(requestBody)
            .when()
            .post("/my_variant_info/variant")
            .then()
            .statusCode(200)
            .extract().response();
    }

    @Test
    public void checkVariantDataAvailabilityAndRetrieveDetails() {
        // Assuming the POST response contains variant IDs or data needed for GET requests
        // Extract variant IDs from postResponse if necessary
        
        String[] variants = {"chr1:12345:A>T", "chr2:67890:G>C"};
        
        for (String variant : variants) {
            given()
                .pathParam("variant", variant)
                .when()
                .get("/my_variant_info/variant/{variant}")
                .then()
                .statusCode(200);
        }
    }
}

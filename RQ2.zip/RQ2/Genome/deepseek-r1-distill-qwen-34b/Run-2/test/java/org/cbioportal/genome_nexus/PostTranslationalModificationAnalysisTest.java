import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class PostTranslationalModificationAnalysisTest {

    private String baseUri;

    @BeforeEach
    void setUp() {
        baseUri = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.baseURI = baseUri;
    }

    @Test
    void testFetchPTMDataForTranscript() {
        String ensemblTranscriptId = "ENST00000646891";
        String endpoint = "/ptm/experimental?ensemblTranscriptId=" + ensemblTranscriptId;

        Response response = given()
                .contentType(ContentType.JSON)
                .when()
                .get(endpoint)
                .then()
                .statusCode(200)
                .extract().response();

        // Add more specific assertions if needed
        response.jsonPath().getList("uniprotEntry").forEach(entry -> 
            assert entry.equals("BRAF_HUMAN"));
    }

    @Test
    void testFetchVariantAnnotationsUsingPTMData() {
        String variant = "rs12345"; // Replace with actual variant
        String endpoint = "/annotation/" + variant + 
                         "?isoformOverrideSource=ensembl&token=%7B%22uniprot%22%3A%22xyz789%22%7D&fields=hotspots%2Cannotations";

        given()
                .contentType(ContentType.JSON)
                .when()
                .get(endpoint)
                .then()
                .statusCode(200)
                .body("variant", equalTo(variant))
                .body("successfully_annotated", equalTo(false));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

public class CuriousCasesAndVariantAnalysisTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void testRetrieveCuriousCases() {
        Response response = given()
                .when()
                .get("/curious_cases/1%2C1%2C1%2CA%2C-")
                .then()
                .statusCode(200)
                .extract().response();

        assertTrue(response.getBody().asString().contains("Genome Nexus"), "Response does not contain expected content");
    }

    @Test
    public void testFetchVariantAnnotations() {
        String variant = "variant:.+";
        Response response = given()
                .when()
                .get("/annotation/{variant}", variant)
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", "{uniprot:xyz789}")
                .queryParam("fields", "hotspots,annotations")
                .then()
                .statusCode(200)
                .extract().response();

        String responseBody = response.getBody().asString();
        assertTrue(responseBody.contains("\"variant\":\"" + variant + "\""), "Variant not found in response");
        assertTrue(responseBody.contains("\"successfully_annotated\":false"), "Annotation status not as expected");
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class PfamDomainAndVariantAnnotationTest {

    private static final String BASE_URL = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testRetrievePfamDomains() {
        given()
                .when()
                .get("/pfam/domain/PF02827")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("pfamAccession", equalTo("PF02827"))
                .body("name", equalTo("PKI"))
                .body("description", equalTo("cAMP-dependent protein kinase inhibitor"));
    }

    @Test
    public void testFetchVariantAnnotation() {
        String variant = "variant:.+";
        String token = "{ \"uniprot\": \"xyz789\" }";
        
        given()
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", token)
                .queryParam("fields", "hotspots,annotations")
                .when()
                .get("/annotation/" + variant)
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("variant", equalTo(variant))
                .body("successfully_annotated", equalTo(false));
    }
}

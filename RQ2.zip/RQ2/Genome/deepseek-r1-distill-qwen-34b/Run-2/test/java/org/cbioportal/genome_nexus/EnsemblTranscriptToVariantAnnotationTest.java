import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class EnsemblTranscriptToVariantAnnotationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void testFetchEnsemblTranscripts() {
        given()
            .contentType(ContentType.JSON)
            .when()
            .get("/ensembl/transcript?geneId=ENSG00000136999")
            .then()
            .statusCode(200)
            .body("[0].transcriptId", equalTo("ENST00000259526"))
            .body("[1].transcriptId", equalTo("ENST00000520082"))
            .body("[0].geneId", equalTo("ENSG00000136999"))
            .body("[0].exons[*].exonId", hasItems("ENSE00001176176", "ENSE00000702270"))
            .body("[0].pfamDomains[*].pfamDomainId", hasItems("PF00093", "PF00219"))
            .body("[0].utrs[*].type", hasItems("five_prime_UTR", "three_prime_UTR"))
            .body("[0].uniprotId", equalTo("P48745"))
            .body("[1].hugoSymbols[0]", equalTo("CCN3"))
            .body("[1].exons[*].exonId", hasItems("ENSE00002097566", "ENSE00002128897"));
    }

    @Test
    public void testRetrieveVariantAnnotations() {
        String transcriptIds = "ENST00000259526,ENST00000520082";
        
        given()
            .contentType(ContentType.JSON)
            .when()
            .get("/annotation/variant:.+?isoformOverrideSource=uniprot&token=%7B%22uniprot%22%3A%22xyz789%22%7D&fields=hotspots%2Cannotations")
            .then()
            .statusCode(200)
            .body("variant", equalTo("variant:.+"))
            .body("originalVariantQuery", equalTo("variant:.+"))
            .body("successfully_annotated", equalTo(false));
    }
}

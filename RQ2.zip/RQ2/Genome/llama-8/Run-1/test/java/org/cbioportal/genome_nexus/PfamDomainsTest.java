import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.equalTo;

public class PfamDomainsTest {

    @Test
    public void testFetchPfamDomainsByPfamAccessionPOST() {
        RestAssured.given()
                .header("Content-Type", "application/json")
                .body("[\"PF00001\", \"PF00002\", \"PF00003\", \"PF00004\", \"PF00005\", \"PF00006\", \"PF00007\", \"PF00008\", \"PF00009\", \"PF00010\"]")
                .when()
                .post("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain")
                .then()
                .statusCode(200)
                .body("size()", equalTo(10));
    }

    @Test
    public void testFetchPfamDomainsByAccessionGET() {
        RestAssured.given()
                .when()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain/PF00001")
                .then()
                .statusCode(200)
                .body("pfamAccession", equalTo("PF00001"));
    }

    @Test
    public void testFetchPfamDomainsByPfamAccessionPOSTAndGET() {
        RestAssured.given()
                .header("Content-Type", "application/json")
                .body("[\"PF00001\", \"PF00002\", \"PF00003\", \"PF00004\", \"PF00005\", \"PF00006\", \"PF00007\", \"PF00008\", \"PF00009\", \"PF00010\"]")
                .when()
                .post("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain")
                .then()
                .statusCode(200)
                .body("size()", equalTo(10));

        RestAssured.given()
                .when()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain/PF00001")
                .then()
                .statusCode(200)
                .body("pfamAccession", equalTo("PF00001"));
    }
}

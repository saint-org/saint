import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.hamcrest.Matchers.equalTo;

public class CuriousCasesTest {

    @Test
    public void testFetchCuriousCasesGET() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
        RestAssured.basePath = "/web-1.1.49-SNAPSHOT/curious_cases/7%2C116411883%2C116411905%2CTTCTTTCTCTCTGTTTTAAGATC%2C-";

        RestAssured.given()
                .when()
                .get()
                .then()
                .statusCode(200)
                .body("genomicLocation", equalTo("7,116411883,116411905,TTCTTTCTCTCTGTTTTAAGATC,-"))
                .body("comment", equalTo("Potential Exon Skip Event common in Non-small Cell Lung Cancer"))
                .body("pubmedIds", equalTo(null))
                .body("hugoGeneSymbol", equalTo("MET"));
    }

    @Test
    public void testFetchCuriousCasesPOST() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
        RestAssured.basePath = "/web-1.1.49-SNAPSHOT/curious_cases";

        String genomicLocation = "7,116411883,116411905,TTCTTTCTCTCTGTTTTAAGATC,-";

        RestAssured.given()
                .header("Content-Type", "application/json")
                .body(genomicLocation)
                .when()
                .post()
                .then()
                .statusCode(200)
                .body("genomicLocation", equalTo(genomicLocation))
                .body("comment", equalTo("Potential Exon Skip Event common in Non-small Cell Lung Cancer"))
                .body("pubmedIds", equalTo(null))
                .body("hugoGeneSymbol", equalTo("MET"));
    }

    @Test
    public void testFetchCuriousCasesPOSTMatchesGET() {
        String genomicLocation = "7,116411883,116411905,TTCTTTCTCTCTGTTTTAAGATC,-";

        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
        RestAssured.basePath = "/web-1.1.49-SNAPSHOT/curious_cases";

        RestAssured.given()
                .header("Content-Type", "application/json")
                .body(genomicLocation)
                .when()
                .post()
                .then()
                .statusCode(200)
                .extract()
                .response()
                .asString();

        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
        RestAssured.basePath = "/web-1.1.49-SNAPSHOT/curious_cases/" + genomicLocation;

        RestAssured.given()
                .when()
                .get()
                .then()
                .statusCode(200)
                .body("genomicLocation", equalTo(genomicLocation))
                .body("comment", equalTo("Potential Exon Skip Event common in Non-small Cell Lung Cancer"))
                .body("pubmedIds", equalTo(null))
                .body("hugoGeneSymbol", equalTo("MET"));
    }
}

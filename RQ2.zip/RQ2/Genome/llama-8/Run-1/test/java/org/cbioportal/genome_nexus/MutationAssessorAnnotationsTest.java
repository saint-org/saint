import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class MutationAssessorAnnotationsTest {

    @Test
    void fetchMutationAssessorAnnotationsByVariantsUsingFetchMutationAssessorAnnotationPOST() {
        String mutationString = "7:g.140453136A>T,12:g.25398285C>A,1:g.12345678C>T,3:g.90123456A>C,5:g.11111111G>A,9:g.99999999T>C";
        RestAssured.given()
                .header("Content-Type", "application/json")
                .body(mutationString)
                .when()
                .post("http://localhost:9080/web-1.1.49-SNAPSHOT/mutation_assessor")
                .then()
                .statusCode(400);
    }

    @Test
    void fetchMutationAssessorAnnotationsByVariantsUsingFetchMutationAssessorAnnotationGETWithCorrectMutationString() {
        String variant = "7:g.140453136A>T";
        RestAssured.given()
                .when()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT/mutation_assessor/" + variant)
                .then()
                .statusCode(404)
                .body("message", is("Mutation Assessor annotation not found for variant: " + variant));
    }

    @Test
    void fetchMutationAssessorAnnotationsByVariantsUsingFetchMutationAssessorAnnotationGETWithMultipleVariants() {
        String mutationString = "7:g.140453136A>T,12:g.25398285C>A,1:g.12345678C>T,3:g.90123456A>C,5:g.11111111G>A,9:g.99999999T>C";
        RestAssured.given()
                .header("Content-Type", "application/json")
                .body(mutationString)
                .when()
                .post("http://localhost:9080/web-1.1.49-SNAPSHOT/mutation_assessor")
                .then()
                .statusCode(400);

        String[] variants = mutationString.split(",");
        for (String variant : variants) {
            RestAssured.given()
                    .when()
                    .get("http://localhost:9080/web-1.1.49-SNAPSHOT/mutation_assessor/" + variant.trim())
                    .then()
                    .statusCode(404)
                    .body("message", is("Mutation Assessor annotation not found for variant: " + variant.trim()));
        }
    }
}

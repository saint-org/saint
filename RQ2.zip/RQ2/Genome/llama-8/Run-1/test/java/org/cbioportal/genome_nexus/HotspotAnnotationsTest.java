import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

import java.util.Arrays;

public class HotspotAnnotationsTest {

    @Test
    public void fetchHotspotAnnotationsByHgvsPOST() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.given()
                .contentType(ContentType.JSON)
                .when()
                .get("/cancer_hotspots/hgvs/{variant:.+}")
                .then()
                .statusCode(200)
                .body(is("[]"));
    }

    @Test
    public void fetchHotspotAnnotationsByHgvsGET() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        String[] hgvsVariants = {"variant1", "variant2", "variant3"};
        RestAssured.given()
                .contentType(ContentType.JSON)
                .when()
                .get("/cancer_hotspots/hgvs/" + String.join(",", hgvsVariants))
                .then()
                .statusCode(200)
                .body(is(Arrays.toString(new String[]{}) + "[]"));
    }
}

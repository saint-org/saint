import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class PostTranslationalModificationsTest {

    @Test
    public void testFetchPostTranslationalModificationsByPtmFilterPOST() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.basePath = "/ptm/experimental";

        String jsonBody = "{\"transcriptIds\": [\"ENST00000420316\", \"ENST00000646891\", \"ENST00000371953\"]}";

        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(jsonBody)
                .when()
                .post()
                .then()
                .statusCode(200)
                .body("length()", is(25))
                .body("uniprotEntry", hasItem("EGFR_HUMAN"))
                .body("uniprotAccession", hasItem("P00533"))
                .body("ensemblTranscriptIds", hasItem("ENST00000420316.6"))
                .body("position", hasItem(3))
                .body("type", hasItem("N-linked Glycosylation"))
                .body("pubmedIds", hasItem("2249995"))
                .body("sequence", hasItem("--------MNNSTNSSNNSLA"));
    }

    @Test
    public void testFetchPostTranslationalModificationsGET() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.basePath = "/ptm/experimental";

        String queryParam = "ensemblTranscriptId=ENST00000420316";

        RestAssured.given()
                .queryParam(queryParam)
                .when()
                .get()
                .then()
                .statusCode(200)
                .body("length()", is(7))
                .body("uniprotEntry", hasItem("EGFR_HUMAN"))
                .body("uniprotAccession", hasItem("P00533"))
                .body("ensemblTranscriptIds", hasItem("ENST00000420316.6"))
                .body("position", hasItem(3))
                .body("type", hasItem("N-linked Glycosylation"))
                .body("pubmedIds", hasItem("2249995"))
                .body("sequence", hasItem("--------MNNSTNSSNNSLA"));
    }
}

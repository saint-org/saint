import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class VariantAnnotationTest {

    @Test
    public void testFetchVariantAnnotationByDbSnpIdGet() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.basePath = "/annotation/dbsnp/{variantId}";

        RestAssured.given()
                .param("isoformOverrideSource", "uniprot")
                .param("token", "token1")
                .param("fields", "[\"annotation_summary\", \"gene_name\", \"protein_change\"]")
                .when()
                .get("/{variantId:.+}")
                .then()
                .statusCode(200)
                .body("variant", notNullValue())
                .body("originalVariantQuery", notNullValue())
                .body("successfully_annotated", is(false));
    }

    @Test
    public void testFetchVariantAnnotationByDbSnpIdPost() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
        RestAssured.basePath = "/annotation/dbsnp";

        String variantId = "variantId:.+";
        String isoformOverrideSource = "uniprot";
        String token = "token1";
        String fields = "[\"annotation_summary\", \"gene_name\", \"protein_change\"]";

        RestAssured.given()
                .param("variantId", variantId)
                .param("isoformOverrideSource", isoformOverrideSource)
                .param("token", token)
                .param("fields", fields)
                .when()
                .post()
                .then()
                .statusCode(200)
                .body("variant", notNullValue())
                .body("originalVariantQuery", notNullValue())
                .body("successfully_annotated", is(false));
    }
}

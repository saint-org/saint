import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class EnsemblGeneIdTest {

    @Test
    public void testFetchEnsemblGeneIdByHugoSymbolGET() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT//ensembl/canonical-gene/hgnc";
        RestAssured.given()
                .param("hugoSymbol", "TP53")
                .when()
                .get()
                .then()
                .statusCode(200)
                .body("geneId", equalTo("ENSG00000141510"))
                .body("hugoSymbol", equalTo("TP53"))
                .body("synonyms", hasItem("p53"))
                .body("synonyms", hasItem("LFS1"))
                .body("entrezGeneId", equalTo("7157"));
    }

    @Test
    public void testFetchEnsemblGeneIdByHugoSymbolPOST() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT//ensembl/canonical-gene/hgnc";
        RestAssured.given()
                .header("Content-Type", "application/json")
                .body("[\"TP53\"]")
                .when()
                .post()
                .then()
                .statusCode(200)
                .body("geneId", hasItem("ENSG00000141510"))
                .body("hugoSymbol", hasItem("TP53"))
                .body("synonyms", hasItem("p53"))
                .body("synonyms", hasItem("LFS1"))
                .body("entrezGeneId", hasItem("7157"));
    }
}

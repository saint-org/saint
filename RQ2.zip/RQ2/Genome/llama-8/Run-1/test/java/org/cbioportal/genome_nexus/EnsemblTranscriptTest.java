import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class EnsemblTranscriptTest {

    @Test
    public void testFetchEnsemblTranscriptByTranscriptIdGET() {
        String ensemblId = "ENST00000361390";
        String url = "http://localhost:9080/web-1.1.49-SNAPSHOT//ensembl/transcript/" + ensemblId;

        Response response = RestAssured.get(url);
        int statusCode = response.getStatusCode();
        assertEquals(200, statusCode);

        String responseBody = response.getBody().asString();
        String expectedResponse = "{\"transcriptId\":\"ENST00000361390\",\"geneId\":\"ENSG00000198888\",\"refseqMrnaId\":\"NC_012920\",\"hugoSymbols\":[\"MT-ND1\"],\"proteinId\":\"ENSP00000354687\",\"proteinLength\":318,\"pfamDomains\":[{\"pfamDomainId\":\"PF00146\",\"pfamDomainStart\":2,\"pfamDomainEnd\":308}],\"exons\":[{\"exonId\":\"ENSE00001435714\",\"exonStart\":3307,\"exonEnd\":4262,\"rank\":1,\"strand\":1,\"version\":2}],\"uniprotId\":\"P03886\"}";
        assertEquals(expectedResponse, responseBody);
    }

    @Test
    public void testFetchEnsemblTranscriptByTranscriptIdPOST() {
        String ensemblId = "ENST00000361390";
        String url = "http://localhost:9080/web-1.1.49-SNAPSHOT//ensembl/transcript";
        String requestBody = "{\"ensemblId\":\"" + ensemblId + "\"}";

        Response response = RestAssured.given()
                .contentType("application/json")
                .body(requestBody)
                .post(url);
        int statusCode = response.getStatusCode();
        assertEquals(200, statusCode);

        String responseBody = response.getBody().asString();
        String expectedResponse = "{\"transcriptId\":\"ENST00000361390\",\"geneId\":\"ENSG00000198888\",\"refseqMrnaId\":\"NC_012920\",\"hugoSymbols\":[\"MT-ND1\"],\"proteinId\":\"ENSP00000354687\",\"proteinLength\":318,\"pfamDomains\":[{\"pfamDomainId\":\"PF00146\",\"pfamDomainStart\":2,\"pfamDomainEnd\":308}],\"exons\":[{\"exonId\":\"ENSE00001435714\",\"exonStart\":3307,\"exonEnd\":4262,\"rank\":1,\"strand\":1,\"version\":2}],\"uniprotId\":\"P03886\"}";
        assertEquals(expectedResponse, responseBody);
    }
}

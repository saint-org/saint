import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class NucleotideContextAnnotationsTest {

    @Test
    public void testFetchNucleotideContextAnnotationsByVariantsUsingFetchNucleotideContextAnnotationPOST() {
        RestAssured.given()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//nucleotide_context/{variant:.+}")
                .then()
                .statusCode(200)
                .body(notNull());
    }

    @Test
    public void testFetchNucleotideContextAnnotationsByVariantsUsingFetchNucleotideContextAnnotationGET() {
        RestAssured.given()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//nucleotide_context/{variant:.+}")
                .then()
                .statusCode(200)
                .body(notNull());
    }

    @Test
    public void testFetchNucleotideContextAnnotationsByVariantsUsingFetchNucleotideContextAnnotationPOSTAndFetchNucleotideContextAnnotationGET() {
        String responsePOST = RestAssured.given()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//nucleotide_context/{variant:.+}")
                .then()
                .statusCode(200)
                .extract().asString();

        String responseGET = RestAssured.given()
                .get("http://localhost:9080/web-1.1.49-SNAPSHOT//nucleotide_context/{variant:.+}")
                .then()
                .statusCode(200)
                .extract().asString();

        assertThat(responsePOST, equalTo(responseGET));
    }
}

package org.example.tests;

import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import io.restassured.http.ContentType;

public class Scenario7RetrievingPfamDomainDataForSingleAndMultipleQueriesTest {

    @Test
    void testGetPfamDomainInformationForSingleAccessionID() {
        given()
        .when()
            .get("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain/PF02827")
        .then()
            .statusCode(200)
            .body("pfamAccession", equalTo("PF02827"))
            .body("name", equalTo("PKI"))
            .body("description", equalTo("cAMP-dependent protein kinase inhibitor"));
    }

    @Test
    void testGetPfamDomainInformationForMultipleAccessionIDs() {
        given()
            .contentType(ContentType.JSON)
            .body("[\"PF02827\", \"PF15345\"]")
        .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT//pfam/domain")
        .then()
            .statusCode(200)
            .body("[0].pfamAccession", equalTo("PF02827"))
            .body("[0].name", equalTo("PKI"))
            .body("[0].description", equalTo("cAMP-dependent protein kinase inhibitor"))
            .body("[1].pfamAccession", equalTo("PF15345"))
            .body("[1].name", equalTo("TMEM51"))
            .body("[1].description", equalTo("Transmembrane protein 51"));
    }
}

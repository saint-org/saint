package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@DisplayName("Scenario #2: Fetching single and multiple PDB headers, including an error route")
public class Scenario2FetchingSingleAndMultiplePDBHeadersIncludingAnErrorRouteTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.basePath = "/web-1.1.49-SNAPSHOT/pdb/header";
    }

    @Test
    @DisplayName("Fetch PDB header for a known ID")
    void fetchPdbHeaderForKnownIdTest() {
        given()
            .when()
            .get("/1a37")
            .then()
            .statusCode(200)
            .body("pdbId", equalTo("1a37"))
            .body("title", equalTo("14-3-3 protein zeta bound to ps-raf259 peptide"))
            .body("compound.'1'.molecule", equalTo("14-3-3 protein zeta"))
            .body("compound.'2'.molecule", containsString("ps-raf259"))
            .body("source.'1'.organism_scientific", equalTo("bos taurus"));
    }

    @Test
    @DisplayName("Fetch multiple PDB headers in a single call")
    void fetchMultiplePdbHeadersInSingleCallTest() {
        given()
            .contentType("application/json")
            .body("[\"1A4O\", \"2bbm\"]")
            .when()
            .post()
            .then()
            .statusCode(200)
            .body("$", hasSize(2))
            .body("[0].pdbId", equalTo("1A4O"))
            .body("[1].pdbId", equalTo("2bbm"))
            .body("[0].compound.'1'.chain", hasItems("a", "b", "c", "d"))
            .body("[1].compound.'2'.molecule", equalTo("myosin light chain kinase"));
    }

    @Test
    @DisplayName("Submit an invalid PDB ID to trigger error route")
    void submitInvalidPdbIdTest() {
        given()
            .when()
            .get("/1a37") // As per the sub-task details, this is the same endpoint provided
            .then()
            .statusCode(200)
            .body("pdbId", equalTo("1a37"))
            .body("title", equalTo("14-3-3 protein zeta bound to ps-raf259 peptide"));
    }
}

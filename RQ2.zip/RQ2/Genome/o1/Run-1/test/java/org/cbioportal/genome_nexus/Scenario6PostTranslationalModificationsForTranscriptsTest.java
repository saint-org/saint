import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Scenario6PostTranslationalModificationsForTranscriptsTest {

    @Test
    public void testRetrievePTMsForSingleKnownTranscript() {
        given()
            .when()
            .get("http://localhost:9080/web-1.1.49-SNAPSHOT//ptm/experimental?ensemblTranscriptId=ENST00000646891")
            .then()
            .statusCode(200)
            .body("[0].uniprotEntry", equalTo("BRAF_HUMAN"));
    }

    @Test
    public void testFilterPTMsForASetOfTranscriptIDs() {
        given()
            .contentType("application/json")
            .body("[\"ENST00000420316\", \"ENST00000646891\", \"ENST00000371953\"]")
            .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT//ptm/experimental")
            .then()
            .statusCode(400)
            .body(containsString("Error 400:"));
    }
}

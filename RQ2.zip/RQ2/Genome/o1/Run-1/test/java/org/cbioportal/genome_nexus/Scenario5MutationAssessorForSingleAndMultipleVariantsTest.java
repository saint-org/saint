import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class Scenario5MutationAssessorForSingleAndMultipleVariantsTest {

    @Test
    void fetchMutationAssessorAnnotationForSingleVariant() {
        given()
            .pathParam("variant", "exampleVariant")
        .when()
            .get("http://localhost:9080/web-1.1.49-SNAPSHOT//mutation_assessor/{variant}")
        .then()
            .statusCode(404)
            .body("message", equalTo("Mutation Assessor annotation not found for variant: exampleVariant"));
    }

    @Test
    void fetchMutationAssessorAnnotationsForMultipleVariants() {
        given()
            .contentType("application/json")
            .body("[\"5:g.123456A>G\", \"9:g.234567C>T\", \"13:g.111111C>G\", \"X:g.9999999delAC\", \"19:g.1000000insT\", \"7:g.140453136A>T\"]")
        .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT//mutation_assessor")
        .then()
            // The scenario indicates a timeout response with status code -100; this is not a standard HTTP code.
            // For demonstration, we simply log the response or status to reflect the timed out behavior.
            .log().all();
    }
}

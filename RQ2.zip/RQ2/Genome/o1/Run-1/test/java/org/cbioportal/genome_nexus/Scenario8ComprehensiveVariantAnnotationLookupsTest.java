package com.example.tests;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@DisplayName("Scenario #8: Comprehensive variant annotation lookups (GET, POST, dbSNP, genomic location)")
public class Scenario8ComprehensiveVariantAnnotationLookupsTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        // Adjust the basePath as needed for your environment
    }

    @Test
    @DisplayName("1. Retrieve annotation for a single variant via GET (token-based filtering, isoform override)")
    void retrieveSingleVariantAnnotationViaGET() {
        given()
            .basePath("/web-1.1.49-SNAPSHOT/annotation")
            .pathParam("variant", "testVariant123")
        .when()
            .get("/{variant}")
        .then()
            .statusCode(200)
            .body("variant", matchesRegex("variant:.+"))
            .body("originalVariantQuery", matchesRegex("variant:.+"))
            .body("successfully_annotated", is(false));
    }

    @Test
    @DisplayName("2. Retrieve annotation for a single dbSNP ID via GET (isoform override, token-based)")
    void retrieveSingleDbSNPViaGET() {
        given()
            .basePath("/web-1.1.49-SNAPSHOT/annotation/dbsnp")
            .pathParam("variantId", "rsTest123")
            .queryParam("isoformOverrideSource", "uniprot")
            .queryParam("token", "{\"source1\":\"abcd1234\"}")
            .queryParam("fields", "annotation_summary,transcript_consequences")
        .when()
            .get("/{variantId}")
        .then()
            .statusCode(200)
            .body("variant", matchesRegex("variantId:.+"))
            .body("originalVariantQuery", matchesRegex("variantId:.+"))
            .body("successfully_annotated", is(false))
            .body("annotation_summary.variant", matchesRegex("variantId:.+"))
            .body("annotation_summary.transcriptConsequences", notNullValue())
            .body("annotation_summary.transcriptConsequenceSummaries", notNullValue());
    }
}

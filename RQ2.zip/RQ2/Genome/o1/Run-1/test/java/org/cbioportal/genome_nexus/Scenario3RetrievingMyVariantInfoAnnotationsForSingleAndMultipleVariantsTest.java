import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.http.ContentType.*;
import static org.hamcrest.Matchers.*;

public class Scenario3RetrievingMyVariantInfoAnnotationsForSingleAndMultipleVariantsTest {

    @Test
    public void testRetrieveMyVariantInfoAnnotationForSingleVariant() {
        given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
        .when()
            .get("/my_variant_info/variant/{variant:.+}", "12:g.25398285C>A")
        .then()
            .statusCode(200)
            .contentType(HTML);
    }

    @Test
    public void testRetrieveMyVariantInfoAnnotationForMultipleVariants() {
        String requestBody = "[\"12:g.25398285C>A\", \"1:g.12345G>A\", \"X:g.9999A>G\"]";

        given()
            .baseUri("http://localhost:9080/web-1.1.49-SNAPSHOT")
            .contentType(JSON)
            .body(requestBody)
        .when()
            .post("/my_variant_info/variant")
        .then()
            .statusCode(200)
            .contentType(JSON)
            .body("size()", greaterThan(0))
            .body("[0].variant", equalTo("chr12:g.25398285C>A"));
    }
}

import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Scenario4FetchingAnnotationSummaryForSingleAndMultipleVariantsAlongsideRawAnnotationsTest {

    @Test
    void fetchSingleVariantAnnotationSummary() {
        given()
            .when()
            .get("http://localhost:9080/web-1.1.49-SNAPSHOT/annotation/summary/{variant}?isoformOverrideSource=uniprot&projection=CANONICAL",
                    "17:g.41242962_41242963insGA")
            .then()
            .statusCode(200)
            .body("variant", containsString("17:g.41242962_41242963insGA"));
    }

    @Test
    void fetchMultipleVariantAnnotationSummary() {
        given()
            .contentType("application/json")
            .body("[\"17:g.41242962_41242963insGA\", \"1:g.1385015_1387562del\"]")
            .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT/annotation/summary?isoformOverrideSource=uniprot&projection=CANONICAL")
            .then()
            .statusCode(200)
            .body("[0].variant", equalTo("17:g.41242962_41242963insGA"))
            .body("[1].variant", equalTo("1:g.1385015_1387562del"));
    }

    @Test
    void fetchRawAnnotationDataForSameVariants() {
        given()
            .contentType("application/json")
            .body("[\"17:g.41242962_41242963insGA\", \"1:g.1385015_1387562del\"]")
            .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT/annotation?isoformOverrideSource=uniprot&token=&fields=%5B%27exacAF%27%2C%20%27variantConsequence%27%2C%20%27customField%27%5D")
            .then()
            .statusCode(200)
            .body("[0].variant", equalTo("17:g.41242962_41242963insGA"))
            .body("[1].variant", equalTo("1:g.1385015_1387562del"));
    }
}

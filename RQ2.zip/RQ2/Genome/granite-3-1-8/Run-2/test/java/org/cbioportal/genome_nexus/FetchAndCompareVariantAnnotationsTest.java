
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FetchAndCompareVariantAnnotationsTest {

    private static final String BASE_URL = "http://localhost:9080";
    private static final String ANNOTATION_ENDPOINT = "/web-1.1.49-SNAPSHOT/annotation";
    private static final String MUTATION_ASSESSOR_ENDPOINT = "/web-1.1.49-SNAPSHOT/mutation_assessor";
    private static final String VARIANTS = "[\"X:g.66937331T>A\", \"17:g.41242962_41242963insGA (GRCh37)\", \"1:g.182712A>C\", \"2:g.265023C>T\", \"3:g.319781del\", \"19:g.110753dup\", \"1:g.1385015_1387562del (GRCh38)\"]";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void fetchAndCompareVariantAnnotations() {
        // Fetch variant annotations
        Response variantAnnotationsResponse = given()
                .contentType("application/json")
                .body(VARIANTS)
                .param("isoformOverrideSource", "uniprot")
                .param("token", "{\"source1\":\"token1\",\"source2\":\"token2\"}")
                .param("fields", Arrays.asList("hotspots", "consequences", "population_frequencies"))
                .when()
                .post(ANNOTATION_ENDPOINT)
                .then()
                .statusCode(200);

        // Fetch mutation assessor annotations
        Response mutationAssessorAnnotationsResponse = given()
                .contentType("application/json")
                .body(VARIANTS)
                .when()
                .post(MUTATION_ASSESSOR_ENDPOINT)
                .then()
                .statusCode(200);

        // Validate the responses
        assertEquals(variantAnnotationsResponse.jsonPath().get("size()"), 5);
        assertEquals(mutationAssessorAnnotationsResponse.jsonPath().get("size()"), 5);

        // Compare the annotations
        variantAnnotationsResponse.jsonPath().each("variant")
                .read()
                .isEqualTo(mutationAssessorAnnotationsResponse.jsonPath().each("variant")
                        .read());
    }
}

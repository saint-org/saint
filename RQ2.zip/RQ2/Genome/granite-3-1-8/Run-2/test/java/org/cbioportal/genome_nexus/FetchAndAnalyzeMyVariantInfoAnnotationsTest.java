import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class FetchAndAnalyzeMyVariantInfoAnnotationsTest {

    @Test
    public void fetchAndAnalyzeMyVariantInfoAnnotations() {
        String[] variants = {"X:g.66937331T>A", "17:g.41242962_41242963insGA", "1:g.182712A>C", "2:g.265023C>T", "3:g.319781del", "19:g.110753dup", "1:g.1385015_1387562del"};

        // Fetch MyVariantInfo annotations for a list of variants
        given()
            .contentType(ContentType.JSON)
            .body("[\"%s\"]".formatted(String.join(",", variants)))
            .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT/my_variant_info/variant")
            .then()
            .statusCode(400);

        // Fetch additional annotations for the same list of variants
        given()
            .contentType(ContentType.JSON)
            .body("[\"%s\"]".formatted(String.join(",", variants)))
            .header("Content-Type", "application/json")
            .header("isoformOverrideSource", "uniprot")
            .header("token.source1", "token1")
            .header("token.source2", "token2")
            .header("fields", "%5B%27hotspots%27%2C%20%27consequences%27%2C%20%27population_frequencies%27%5D")
            .when()
            .post("http://localhost:9080/web-1.1.49-SNAPSHOT/annotation")
            .then()
            .statusCode(200);
    }
}

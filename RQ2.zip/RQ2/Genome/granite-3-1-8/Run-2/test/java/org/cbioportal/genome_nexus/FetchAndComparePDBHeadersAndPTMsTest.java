package com.example.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class FetchAndComparePDBHeadersAndPTMsTest {

    private final String baseURL = "http://localhost:9080";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = baseURL;
    }

    @Test
    public void fetchAndComparePDBHeadersAndPTMs() {
        // Fetch PDB headers for a set of PDB IDs
        String pdbId1 = "1a37";
        String expectedPDBHeaderResponse = "{\"pdbId\":\"1a37\",\"title\":\"14-3-3 protein zeta bound to ps-raf259 peptide\",\"compound\":{\"1\":{\"other_details\":\"complexed with phosphoserine-containing peptide derived from raf\",\"chain\":[\"a\",\"b\"],\"engineered\":\"yes\",\"molecule\":\"14-3-3 protein zeta\",\"mol_id\":\"1\"},\"2\":{\"chain\":[\"p\",\"q\"],\"molecule\":\"ps-raf259 peptide lsqrqrst(sep)tpnvhm\",\"mol_id\":\"2\"}},\"source\":{\"1\":{\"organism_scientific\":\"bos taurus\",\"organism_common\":\"cattle\",\"organism_taxid\":\"9913\",\"expression_system_taxid\":\"562\",\"expression_system\":\"escherichia coli\",\"mol_id\":\"1\"}}}";

        given()
                .when()
                .get("/pdb/header/" + pdbId1)
                .then()
                .statusCode(200)
                .body("pdbId", equalTo(pdbId1))
                .body("title", equalTo("14-3-3 protein zeta bound to ps-raf259 peptide"))
                .body("compound[1].other_details", equalTo("complexed with phosphoserine-containing peptide derived from raf"))
                .body("compound[1].chain", equalTo(Arrays.asList("a", "b")))
                .body("compound[1].engineered", equalTo("yes"))
                .body("compound[1].molecule", equalTo("14-3-3 protein zeta"))
                .body("compound[1].mol_id", equalTo("1"))
                .body("compound[2].chain", equalTo(Arrays.asList("p", "q")))
                .body("compound[2].molecule", equalTo("ps-raf259 peptide lsqrqrst(sep)tpnvhm"))
                .body("compound[2].mol_id", equalTo("2"))
                .body("source[1].organism_scientific", equalTo("bos taurus"))
                .body("source[1].organism_common", equalTo("cattle"))
                .body("source[1].organism_taxid", equalTo("9913"))
                .body("source[1].expression_system_taxid", equalTo("562"))
                .body("source[1].expression_system", equalTo("escherichia coli"))
                .body("source[1].mol_id", equalTo("1"));

        // Fetch post-translational modifications for a set of PDB IDs
        String expectedPTMResponse = "{\"postTranslationalModifications\": [{\"residue\": \"S\", \"position\": 10, \"modification\": \"Phosphorylation\"}]}";

        given()
                .when()
                .contentType(ContentType.JSON)
                .body("{\"pdbIds\": [" + pdbId1 + "]}")
                .post("/ptm/experimental")
                .then()
                .statusCode(200)
                .body("postTranslationalModifications", hasSize(1))
                .body("postTranslationalModifications[0].residue", equalTo("S"))
                .body("postTranslationalModifications[0].position", equalTo(10))
                .body("postTranslationalModifications[0].modification", equalTo("Phosphorylation"));
    }
}

package com.example.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class FetchPfamDomainsTest {

    private static final String BASE_URL = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void fetchPfamDomainsAndAdditionalAnnotations() {
        String pfamAccessionIds = "[\"PFAM123\", \"PFAM456\", \"PFAM789\"]";

        // Fetch Pfam domains for a list of PFAM accession IDs
        given()
            .contentType(ContentType.JSON)
            .body(pfamAccessionIds)
            .when()
            .post("/pfam/domain")
            .then()
            .statusCode(200)
            .extract()
            .response();

        // Fetch additional annotations for the same list of PFAM accession IDs
        given()
            .contentType(ContentType.JSON)
            .body(pfamAccessionIds)
            .when()
            .post("/annotation")
            .then()
            .statusCode(400)
            .extract()
            .response();
    }
}

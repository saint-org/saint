import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class FetchAndAnalyzeNucleotideContextAnnotationsTest {

    private static final String BASE_URL = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testFetchingAndAnalyzingNucleotideContextAnnotations() {
        // Fetch nucleotide context annotations for a list of variants
        String nucleotideContextAnnotations = given()
                .contentType(ContentType.JSON)
                .body("[\"7:g.140453136A>T\", \"12:g.25398285C>A\"]")
                .when()
                .post("/nucleotide_context")
                .then()
                .statusCode(200)
                .extract().body().asString();

        // Fetch additional annotations for the same list of variants
        String additionalAnnotations = given()
                .contentType(ContentType.JSON)
                .header("Content-Type", "application/json")
                .body("[\"7:g.140453136A>T\", \"12:g.25398285C>A\"]")
                .body("isoformOverrideSource=uniprot")
                .body("token=%7B%22source1%22%3A%22token1%22%2C%22source2%22%3A%22token2%22%7D")
                .body("fields=%5B%27hotspots%27%2C%20%27consequences%27%2C%20%27population_frequencies%27%5D")
                .when()
                .post("/annotation")
                .then()
                .statusCode(200)
                .extract().body().asString();

        // Assertions to verify the response
        // You can add your assertions here based on the expected response format
    }
}

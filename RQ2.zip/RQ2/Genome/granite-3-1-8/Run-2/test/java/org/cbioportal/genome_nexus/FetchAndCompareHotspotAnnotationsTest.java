import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

public class FetchAndCompareHotspotAnnotationsTest {

    private static final String BASE_URL = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void fetchAndCompareHotspotAnnotations() {
        String variants = "[\"7:g.140453136A>T\", \"12:g.25398285C>A\", \"...\", \"100:g.100000C>G\"]";

        // Fetch hotspot annotations for a list of variants
        given()
                .contentType(ContentType.JSON)
                .body(variants)
                .when()
                .post("/cancer_hotspots/hgvs")
                .then()
                .statusCode(200)
                .body("hotspots[0].hugoSymbol", equalTo("BRAF"))
                .body("hotspots[0].transcriptId", equalTo("ENST00000288602"))
                .body("hotspots[0].residue", equalTo("V600"))
                .body("hotspots[0].tumorCount", equalTo(897))
                .body("hotspots[0].type", equalTo("single residue"))
                .body("hotspots[1].hugoSymbol", equalTo("KRAS"))
                .body("hotspots[1].transcriptId", equalTo("ENST00000256078"))
                .body("hotspots[1].residue", equalTo("G12"))
                .body("hotspots[1].tumorCount", equalTo(2175));

        // Fetch additional annotations for a list of variants
        given()
                .contentType(ContentType.JSON)
                .body(variants)
                .body("isoformOverrideSource", equalTo("uniprot"))
                .body("token.source1", equalTo("token1"))
                .body("token.source2", equalTo("token2"))
                .body("fields", equalTo("[\"consequences\",\"population_frequencies\"]"))
                .when()
                .post("/annotation")
                .then()
                .statusCode(200)
                .body("colocatedVariants[0].dbSnpId", equalTo("CM112509"))
                .body("colocatedVariants[1].dbSnpId", equalTo("COSV56056643"))
                .body("colocatedVariants[2].dbSnpId", equalTo("COSV56065204"))
                .body("colocatedVariants[3].dbSnpId", equalTo("COSV56080151"))
                .body("colocatedVariants[4].dbSnpId", equalTo("rs113488022"));
    }
}

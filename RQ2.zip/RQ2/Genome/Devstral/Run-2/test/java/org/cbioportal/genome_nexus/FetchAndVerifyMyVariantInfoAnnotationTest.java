import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyMyVariantInfoAnnotationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT/";
    }

    @Test
    public void fetchMyVariantInfoAnnotation() {
        String variant = "rs12345678"; // Replace with the actual variant ID
        Response response = given()
                .when()
                .get("/my_variant_info/variant/{variant}", variant)
                .then()
                .statusCode(200)
                .contentType(ContentType.HTML)
                .body(containsString("Genome Nexus"))
                .extract()
                .response();

        // Additional assertions can be added here to verify the response content
    }
}

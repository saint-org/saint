import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndVerifyHotspotAnnotationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchHotspotAnnotationsByVariant() {
        String variant = "exampleVariant"; // Replace with a valid variant ID
        Response response = given()
                .when()
                .get("/cancer_hotspots/hgvs/{variant}", variant)
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Validate the response
        response.then().body(equalTo("[]"));
    }
}

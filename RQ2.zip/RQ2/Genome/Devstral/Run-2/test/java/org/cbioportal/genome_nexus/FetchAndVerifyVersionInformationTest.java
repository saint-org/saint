import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyVersionInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchVersionInformation() {
        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/version")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String jsonResponse = response.asString();
        System.out.println(jsonResponse);

        response.then().body("genomeNexus.server.version", equalTo("1.0.2"));
        response.then().body("genomeNexus.server.static", equalTo(true));
        response.then().body("genomeNexus.database.version", equalTo("3.6.2"));
        response.then().body("genomeNexus.database.static", equalTo(true));
        response.then().body("vep.server.version", equalTo("NA"));
        response.then().body("vep.server.static", equalTo(false));
        response.then().body("vep.cache.version", equalTo("NA"));
        response.then().body("vep.cache.static", equalTo(false));
        response.then().body("vep.comment", equalTo("VEP annotations are currently externally sourced from ENSEMBL. Results are subject to change without notice."));
    }
}

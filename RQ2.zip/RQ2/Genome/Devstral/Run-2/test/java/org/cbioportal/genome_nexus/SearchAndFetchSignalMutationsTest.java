import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class SearchAndFetchSignalMutationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void searchForSignalMutationsBasedOnKeywordAndLimit() {
        Response response = given()
                .queryParam("keyword", "BRCA")
                .queryParam("limit", 20)
                .when()
                .get("/signal/search")
                .then()
                .statusCode(200)
                .body("size()", is(2))
                .body("[0].queryType", is("GENE"))
                .body("[0].matchType", is("STARTS_WITH"))
                .body("[0].hugoSymbol", is("BRCA1"))
                .body("[0].description", is("619 unique mutations"))
                .body("[1].queryType", is("GENE"))
                .body("[1].matchType", is("STARTS_WITH"))
                .body("[1].hugoSymbol", is("BRCA2"))
                .body("[1].description", is("1132 unique mutations"))
                .extract()
                .response();
    }
}

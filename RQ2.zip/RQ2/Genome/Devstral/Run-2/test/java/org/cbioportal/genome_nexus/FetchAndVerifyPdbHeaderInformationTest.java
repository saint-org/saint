import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyPdbHeaderInformationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchPdbHeaderInformation() {
        Response response = given()
                .when()
                .get("/pdb/header/1a37")
                .then()
                .statusCode(200)
                .extract()
                .response();

        response.then()
                .body("pdbId", equalTo("1a37"))
                .body("title", notNullValue())
                .body("experimentalMethod", notNullValue());
    }
}

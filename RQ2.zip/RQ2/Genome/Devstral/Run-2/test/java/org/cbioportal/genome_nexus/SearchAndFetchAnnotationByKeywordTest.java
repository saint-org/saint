import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class SearchAndFetchAnnotationByKeywordTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    public void searchAnnotationsByKeyword() {
        Response response = given()
                .queryParam("keyword", "TP53 p.R273C")
                .queryParam("limit", 10)
                .when()
                .get("/web-1.1.49-SNAPSHOT/search")
                .then()
                .statusCode(200)
                .body("[0].queryType", equalTo("GENE_HGVSPSHORT"))
                .body("[0].results", equalTo("[]"))
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

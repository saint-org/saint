import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyNucleotideContextAnnotationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchNucleotideContextAnnotationForGivenVariant() {
        String variant = "exampleVariant"; // Replace with actual variant ID

        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/nucleotide_context/{variant}", variant)
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertThat(responseBody, containsString("variant ID"));
        assertThat(responseBody, containsString("gene symbol"));
        assertThat(responseBody, containsString("nucleotide context"));
    }
}

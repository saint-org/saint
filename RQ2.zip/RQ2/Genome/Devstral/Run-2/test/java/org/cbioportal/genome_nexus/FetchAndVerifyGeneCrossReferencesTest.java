import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FetchAndVerifyGeneCrossReferencesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchGeneCrossReferencesForSpecificEnsemblGeneAccession() {
        String accession = "accession";
        Response response = given()
                .when()
                .get("/xrefs/{accession}", accession)
                .then()
                .statusCode(400)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertEquals("{\"message\":\"{\\\"error\\\":\\\"ID 'accession' not found\\\"}\"}", responseBody);
    }
}

 ```java
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyPostTranslationalModificationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchPostTranslationalModifications() {
        Response response = given()
                .when()
                .get("/ptm/experimental?ensemblTranscriptId=ENST00000646891")
                .then()
                .statusCode(200)
                .extract()
                .response();

        response.then().body("size()", is(26));
        response.then().body("[0].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[0].uniprotAccession", is("P15056"));
        response.then().body("[0].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[0].position", is(154));
        response.then().body("[0].type", is("Acetylation"));
        response.then().body("[0].pubmedIds", hasItems("25953088"));
        response.then().body("[0].sequence", is("VARSNPKSPQKPIVRVFLPNK"));

        response.then().body("[1].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[1].uniprotAccession", is("P15056"));
        response.then().body("[1].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[1].position", is(253));
        response.then().body("[1].type", is("Acetylation"));
        response.then().body("[1].pubmedIds", hasItems("7709589"));
        response.then().body("[1].sequence", is("FTLAFCDFCRKLLFQGFRCQT"));

        response.then().body("[2].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[2].uniprotAccession", is("P15056"));
        response.then().body("[2].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[2].position", is(418));
        response.then().body("[2].type", is("Acetylation"));
        response.then().body("[2].pubmedIds", hasItems("19608861"));
        response.then().body("[2].sequence", is("GSLTNVKALQKSPGPQRERKS"));

        response.then().body("[3].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[3].uniprotAccession", is("P15056"));
        response.then().body("[3].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[3].position", is(671));
        response.then().body("[3].type", is("Methylation"));
        response.then().body("[3].pubmedIds", hasItems("21917714"));
        response.then().body("[3].sequence", is("NRDQIIFMVGRGYLSPDLSKV"));

        response.then().body("[4].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[4].uniprotAccession", is("P15056"));
        response.then().body("[4].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[4].position", is(88));
        response.then().body("[4].type", is("Ubiquitination"));
        response.then().body("[4].pubmedIds", hasItems("22053931"));
        response.then().body("[4].sequence", is("YLEAYEEYTSKLDALQQREQQ"));

        response.then().body("[5].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[5].uniprotAccession", is("P15056"));
        response.then().body("[5].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[5].position", is(578));
        response.then().body("[5].type", is("Ubiquitination"));
        response.then().body("[5].pubmedIds", hasItems("23907581", "PubMed"));
        response.then().body("[5].sequence", is("HAKSIIHRDLKSNNIFLHEDL"));

        response.then().body("[6].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[6].uniprotAccession", is("P15056"));
        response.then().body("[6].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[6].position", is(119));
        response.then().body("[6].type", is("Phosphorylation"));
        response.then().body("[6].pubmedIds", hasItems("16858395"));
        response.then().body("[6].sequence", is("FSVSSSASMDTVTSSSSSSLS"));

        response.then().body("[7].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[7].uniprotAccession", is("P15056"));
        response.then().body("[7].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[7].position", is(147));
        response.then().body("[7].type", is("Phosphorylation"));
        response.then().body("[7].pubmedIds", hasItems("17192257"));
        response.then().body("[7].sequence", is("VFQNPTDVARSNPKSPQKPIV"));

        response.then().body("[8].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[8].uniprotAccession", is("P15056"));
        response.then().body("[8].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[8].position", is(151));
        response.then().body("[8].type", is("Phosphorylation"));
        response.then().body("[8].pubmedIds", hasItems("23186163", "24275569"));
        response.then().body("[8].sequence", is("PTDVARSNPKSPQKPIVRVFL"));

        response.then().body("[9].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[9].uniprotAccession", is("P15056"));
        response.then().body("[9].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[9].position", is(244));
        response.then().body("[9].type", is("Phosphorylation"));
        response.then().body("[9].pubmedIds", hasItems("22135298"));
        response.then().body("[9].sequence", is("THNFVRKTFFTLAFCDFCRKL"));

        response.then().body("[10].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[10].uniprotAccession", is("P15056"));
        response.then().body("[10].ensemblTranscriptIds", hasItems("ENST00000646891
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndVerifyCuriousCases {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchCuriousCasesForSpecificGenomicLocation() {
        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/curious_cases/7%2C116411883%2C116411905%2CTTCTTTCTCTCTGTTTTAAGATC%2C-")
                .then()
                .statusCode(200)
                .body("genomicLocation", equalTo("7,116411883,116411905,TTCTTTCTCTCTGTTTTAAGATC,-"))
                .body("comment", equalTo("Potential Exon Skip Event common in Non-small Cell Lung Cancer"))
                .body("hugoGeneSymbol", equalTo("MET"))
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

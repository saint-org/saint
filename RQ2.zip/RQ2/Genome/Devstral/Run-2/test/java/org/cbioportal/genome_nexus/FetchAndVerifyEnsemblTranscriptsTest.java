import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FetchAndVerifyEnsemblTranscriptsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchEnsemblTranscriptsForSpecificGeneID() {
        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/ensembl/transcript")
                .then()
                .statusCode(200)
                .extract()
                .response();

        assertEquals("[]", response.getBody().asString());
    }
}

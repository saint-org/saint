import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndVerifyCanonicalEnsemblGeneIDTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchCanonicalEnsemblGeneIdByEntrezGeneIdGET() {
        Response response = given()
                .when()
                .get("/ensembl/canonical-gene/entrez/23140")
                .then()
                .statusCode(200)
                .body("geneId", equalTo("ENSG00000074755"))
                .body("hugoSymbol", equalTo("ZZEF1"))
                .body("synonyms[0]", equalTo("KIAA0399"))
                .body("synonyms[1]", equalTo("ZZZ4"))
                .body("synonyms[2]", equalTo("FLJ10821"))
                .body("entrezGeneId", equalTo("23140"))
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndVerifyMutationAssessorAnnotationTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchMutationAssessorAnnotationForGivenVariant() {
        String variant = "variant:.+";
        Response response = given()
                .when()
                .get("/mutation_assessor/{variant}", variant)
                .then()
                .statusCode(404)
                .extract()
                .response();

        String expectedResponse = "{\"message\":\"Mutation Assessor annotation not found for variant: variant:.+\"}";
        assert response.getBody().asString().equals(expectedResponse);
    }
}

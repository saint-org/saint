import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FetchAndVerifyPfamDomains {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchPfamDomainsByAccessionGET() {
        String pfamAccession = "pfamAccession"; // Replace with actual accession ID for testing

        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/pfam/domain/{pfamAccession}", pfamAccession)
                .then()
                .statusCode(404)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertEquals("{\"message\":\"PFAM domain not found: pfamAccession\"}", responseBody);
    }
}

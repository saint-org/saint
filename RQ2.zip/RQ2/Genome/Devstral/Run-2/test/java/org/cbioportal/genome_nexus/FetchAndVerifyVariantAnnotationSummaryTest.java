import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndVerifyVariantAnnotationSummaryTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void testFetchVariantAnnotationSummary() {
        String variant = "variant:.+";

        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/annotation/summary/{variant}", variant)
                .then()
                .statusCode(200)
                .body("variant", equalTo(variant))
                .body("genomicLocation.chromosome", nullValue())
                .body("genomicLocation.start", nullValue())
                .body("genomicLocation.end", nullValue())
                .body("genomicLocation.referenceAllele", nullValue())
                .body("genomicLocation.variantAllele", nullValue())
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndVerifyVariantAnnotationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchVariantAnnotationData() {
        String variant = "variant:.+";
        String token = "{\"source1\":\"token1\",\"source2\":\"token2\"}";
        String fields = "[\"hotspots\",\"conservation\"]";

        Response response = given()
                .header("Content-Type", "application/json")
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("token", token)
                .queryParam("fields", fields)
                .when()
                .get("/web-1.1.49-SNAPSHOT/annotation/{variant}", variant)
                .then()
                .statusCode(200)
                .body("variant", equalTo(variant))
                .body("originalVariantQuery", equalTo(variant))
                .body("successfully_annotated", equalTo(false))
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

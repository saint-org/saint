 ```java
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndAnalyzeVariantAnnotationSummariesTest {

    private static final String BASE_URI = "http://localhost:9080/web-1.1.49-SNAPSHOT";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = BASE_URI;
    }

    @Test
    public void fetchVariantAnnotationSummaryBasedOnVariant() {
        Response response = given()
                .pathParam("variant", "variant:.+")
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("projection", "CANONICAL")
                .when()
                .get("/annotation/summary/{variant}")
                .then()
                .statusCode(200)
                .body("variant", equalTo("variant:.+"))
                .body("genomicLocation.chromosome", nullValue())
                .body("genomicLocation.start", nullValue())
                .body("genomicLocation.end", nullValue())
                .body("genomicLocation.referenceAllele", nullValue())
                .body("genomicLocation.variantAllele", nullValue())
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchVariantAnnotationSummaryBasedOnListOfVariants() {
        Response response = given()
                .header("Content-Type", "application/json")
                .body("[\"17:g.41242962_41242963insGA\"]")
                .queryParam("isoformOverrideSource", "uniprot")
                .queryParam("projection", "CANONICAL")
                .when()
                .post("/annotation/summary")
                .then()
                .statusCode(200)
                .body("[0].variant", equalTo("17:g.41242962_41242963insGA"))
                .body("[0].genomicLocation.chromosome", equalTo("17"))
                .body("[0].genomicLocation.start", equalTo(41242962))
                .body("[0].genomicLocation.end", equalTo(41242963))
                .body("[0].genomicLocation.referenceAllele", equalTo("-"))
                .body("[0].genomicLocation.variantAllele", equalTo("GA"))
                .body("[0].strandSign", equalTo("+"))
                .body("[0].variantType", equalTo("INS"))
                .body("[0].assemblyName", equalTo("GRCh37"))
                .body("[0].canonicalTranscriptId", equalTo("ENST00000357654"))
                .body("[0].transcriptConsequences", hasSize(20))
                .body("[0].transcriptConsequenceSummaries", hasSize(20))
                .body("[0].transcriptConsequenceSummary.transcriptId", equalTo("ENST00000357654"))
                .body("[0].transcriptConsequenceSummary.codonChange", equalTo("cag/cTCag"))
                .body("[0].transcriptConsequenceSummary.aminoAcids", equalTo("Q/LX"))
                .body("[0].transcriptConsequenceSummary.aminoAcidRef", equalTo("Q"))
                .body("[0].transcriptConsequenceSummary.aminoAcidAlt", equalTo("LX"))
                .body("[0].transcriptConsequenceSummary.entrezGeneId", equalTo(672))
                .body("[0].transcriptConsequenceSummary.consequenceTerms", containsInAnyOrder("frameshift_variant", "splice_region_variant"))
                .body("[0].transcriptConsequenceSummary.hugoGeneSymbol", equalTo("BRCA1"))
                .body("[0].transcriptConsequenceSummary.hgvspShort", equalTo("p.Q1395Lfs*11"))
                .body("[0].transcriptConsequenceSummary.hgvsp", equalTo("p.Gln1395LeufsTer11"))
                .body("[0].transcriptConsequenceSummary.hgvsc", equalTo("ENST00000357654.3:c.4182_4183dup"))
                .body("[0].transcriptConsequenceSummary.proteinPosition.start", equalTo(1395))
                .body("[0].transcriptConsequenceSummary.proteinPosition.end", equalTo(1395))
                .body("[0].transcriptConsequenceSummary.refSeq", equalTo("NM_007294.3"))
                .body("[0].transcriptConsequenceSummary.variantClassification", equalTo("Frame_Shift_Ins"))
                .body("[0].transcriptConsequenceSummary.exon", equalTo("11/23"))
                .body("[0].transcriptConsequenceSummary.uniprotId", equalTo("P38398"))
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchCanonicalEnsemblTranscriptByHugoSymbol() {
        Response response = given()
                .pathParam("hgnc", "TP53")
                .queryParam("isoformOverrideSource", "uniprot")
                .when()
                .get("/ensembl/canonical-transcript/hgnc/{hgnc}")
                .then()
                .statusCode(200)
                .body("transcriptId", equalTo("ENST00000269305"))
                .body("geneId", equalTo("ENSG00000141510"))
                .body("refseqMrnaId", equalTo("NM_000546"))
                .body("ccdsId", equalTo("CCDS11118"))
                .body("hugoSymbols", hasItem("TP53"))
                .body("proteinId", equalTo("ENSP00000269305"))
                .body("proteinLength", equalTo(393))
                .body("pfamDomains", hasSize(3))
                .body("pfamDomains[0].pfamDomainId", equalTo("PF07710"))
                .body("pfamDomains[0].pfamDomainStart", equalTo(318))
                .body("pfamDomains[0].pfamDomainEnd", equalTo(358))
                .body("pfamDomains[1].pfamDomainId", equalTo("PF08563"))
                .body("pfamDomains[1].pfamDomainStart", equalTo(6))
                .body("pfamDomains[1].pfamDomainEnd", equalTo(29))
                .body("pfamDomains[2].pfamDomainId", equalTo("PF00870"))
                .body("pfamDomains[2].pfamDomainStart", equalTo(95))
                .body("pfamDomains[2].pfamDomainEnd", equalTo(288))
                .body("exons", hasSize(11))
                .body("exons[0].exonId", equalTo("ENSE00003605891"))
                .body("exons[0].exonStart", equalTo(7571720))
                .body("exons[0].exonEnd", equalTo(7573008))
                .body("exons[0].rank", equalTo(11))
                .body("exons[0].strand", equalTo(-1))
                .body("exons[0].version", equalTo(1))
                .body("utrs", hasSize(3))
                .body("utrs[0].type", equalTo("three_prime_UTR"))
                .body("utrs[0].start", equalTo(7571720))
                .body("utrs[0].end", equalTo(7572926))
                .body("utrs[0].strand", equalTo(-1))
                .body("utrs[1].type", equalTo("five_prime_UTR"))
                .body("utrs[1].start", equalTo(7579913))
                .body("utrs[1].end", equalTo(7579940))
                .body("utrs[1].strand", equalTo(-1))
                .body("utrs[2].type", equalTo("five_prime_UTR"))
                .body("utrs[2].start", equalTo(7590695))
                .body("utrs[2].end", equalTo(7590856))
                .body("utrs[2].strand", equalTo(-1))
                .body("uniprotId", equalTo("P04637"))
                .extract()
                .response();

        System
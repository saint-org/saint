import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndAnalyzePostTranslationalModificationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchPostTranslationalModifications() {
        Response response = given()
                .when()
                .get("/ptm/experimental?ensemblTranscriptId=ENST00000646891")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Validate the response
        response.then().body("size()", is(25));
        response.then().body("[0].uniprotEntry", is("BRAF_HUMAN"));
        response.then().body("[0].uniprotAccession", is("P15056"));
        response.then().body("[0].ensemblTranscriptIds", hasItems("ENST00000646891.1", "ENST00000288602.6"));
        response.then().body("[0].position", is(154));
        response.then().body("[0].type", is("Acetylation"));
        response.then().body("[0].pubmedIds", hasItems("25953088"));
        response.then().body("[0].sequence", is("VARSNPKSPQKPIVRVFLPNK"));
    }

    @Test
    public void fetchPostTranslationalModificationsByPtmFilter() {
        Response response = given()
                .header("Content-Type", "application/json")
                .body("{\"ensemblTranscriptId\": \"ENST00000646891\"}")
                .when()
                .post("/ptm/experimental")
                .then()
                .statusCode(400)
                .extract()
                .response();

        // Validate the response
        response.then().body("error", is("Bad Request"));
    }

    @Test
    public void fetchCanonicalEnsemblTranscriptByHugoSymbol() {
        Response response = given()
                .when()
                .get("/ensembl/canonical-transcript/hgnc/TP53?isoformOverrideSource=uniprot")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Validate the response
        response.then().body("transcriptId", is("ENST00000269305"));
        response.then().body("geneId", is("ENSG00000141510"));
        response.then().body("refseqMrnaId", is("NM_000546"));
        response.then().body("ccdsId", is("CCDS11118"));
        response.then().body("hugoSymbols", hasItems("TP53"));
        response.then().body("proteinId", is("ENSP00000269305"));
        response.then().body("proteinLength", is(393));
        response.then().body("pfamDomains.size()", is(3));
        response.then().body("pfamDomains[0].pfamDomainId", is("PF07710"));
        response.then().body("pfamDomains[0].pfamDomainStart", is(318));
        response.then().body("pfamDomains[0].pfamDomainEnd", is(358));
        response.then().body("exons.size()", is(11));
        response.then().body("exons[0].exonId", is("ENSE00003605891"));
        response.then().body("exons[0].exonStart", is(7571720));
        response.then().body("exons[0].exonEnd", is(7573008));
        response.then().body("exons[0].rank", is(11));
        response.then().body("exons[0].strand", is(-1));
        response.then().body("exons[0].version", is(1));
        response.then().body("utrs.size()", is(3));
        response.then().body("utrs[0].type", is("three_prime_UTR"));
        response.then().body("utrs[0].start", is(7571720));
        response.then().body("utrs[0].end", is(7572926));
        response.then().body("utrs[0].strand", is(-1));
        response.then().body("uniprotId", is("P04637"));
    }
}

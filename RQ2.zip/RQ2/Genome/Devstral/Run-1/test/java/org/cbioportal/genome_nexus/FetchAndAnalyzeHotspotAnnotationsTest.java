import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndAnalyzeHotspotAnnotationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchHotspotAnnotationsByVariant() {
        String variant = "7:g.140453136A>T";
        Response response = given()
                .when()
                .get("/cancer_hotspots/hgvs/{variant}", variant)
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        System.out.println("Fetch hotspot annotations by variant response: " + responseBody);
    }

    @Test
    public void fetchHotspotAnnotationsByGenomicLocation() {
        String genomicLocation = "7:140453136";
        Response response = given()
                .when()
                .get("/cancer_hotspots/genomic/{genomicLocation}", genomicLocation)
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        System.out.println("Fetch hotspot annotations by genomic location response: " + responseBody);
    }

    @Test
    public void fetchHotspotAnnotationsForListOfVariants() {
        String[] variants = {"7:g.140453136A>T", "12:g.25398285C>A"};
        Response response = given()
                .contentType("application/json")
                .body(variants)
                .when()
                .post("/cancer_hotspots/hgvs")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        System.out.println("Fetch hotspot annotations for list of variants response: " + responseBody);
    }
}

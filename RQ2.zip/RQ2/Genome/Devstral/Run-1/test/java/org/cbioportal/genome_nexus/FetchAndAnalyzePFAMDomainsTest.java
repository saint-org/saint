import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndAnalyzePFAMDomainsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchPfamDomainByAccession() {
        Response response = given()
                .when()
                .get("/pfam/domain/PF02827")
                .then()
                .statusCode(200)
                .body("pfamAccession", equalTo("PF02827"))
                .body("name", equalTo("PKI"))
                .body("description", equalTo("cAMP-dependent protein kinase inhibitor"))
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchPfamDomainsByAccessionIds() {
        Response response = given()
                .contentType("application/json")
                .body("[\"PF02827\", \"PF00093\", \"PF15276\"]")
                .when()
                .post("/pfam/domain")
                .then()
                .statusCode(200)
                .body("[0].pfamAccession", equalTo("PF00093"))
                .body("[0].name", equalTo("VWC"))
                .body("[0].description", equalTo("von Willebrand factor type C domain"))
                .body("[1].pfamAccession", equalTo("PF02827"))
                .body("[1].name", equalTo("PKI"))
                .body("[1].description", equalTo("cAMP-dependent protein kinase inhibitor"))
                .body("[2].pfamAccession", equalTo("PF15276"))
                .body("[2].name", equalTo("PP1_bind"))
                .body("[2].description", equalTo("Protein phosphatase 1 binding"))
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchCanonicalEnsemblTranscriptByHugoSymbol() {
        Response response = given()
                .when()
                .get("/ensembl/canonical-transcript/hgnc/TP53?isoformOverrideSource=uniprot")
                .then()
                .statusCode(200)
                .body("transcriptId", equalTo("ENST00000269305"))
                .body("geneId", equalTo("ENSG00000141510"))
                .body("refseqMrnaId", equalTo("NM_000546"))
                .body("ccdsId", equalTo("CCDS11118"))
                .body("hugoSymbols[0]", equalTo("TP53"))
                .body("proteinId", equalTo("ENSP00000269305"))
                .body("proteinLength", equalTo(393))
                .body("pfamDomains[0].pfamDomainId", equalTo("PF07710"))
                .body("pfamDomains[0].pfamDomainStart", equalTo(318))
                .body("pfamDomains[0].pfamDomainEnd", equalTo(358))
                .body("pfamDomains[1].pfamDomainId", equalTo("PF08563"))
                .body("pfamDomains[1].pfamDomainStart", equalTo(6))
                .body("pfamDomains[1].pfamDomainEnd", equalTo(29))
                .body("pfamDomains[2].pfamDomainId", equalTo("PF00870"))
                .body("pfamDomains[2].pfamDomainStart", equalTo(95))
                .body("pfamDomains[2].pfamDomainEnd", equalTo(288))
                .body("exons[0].exonId", equalTo("ENSE00003605891"))
                .body("exons[0].exonStart", equalTo(7571720))
                .body("exons[0].exonEnd", equalTo(7573008))
                .body("exons[0].rank", equalTo(11))
                .body("exons[0].strand", equalTo(-1))
                .body("exons[0].version", equalTo(1))
                .body("utrs[0].type", equalTo("three_prime_UTR"))
                .body("utrs[0].start", equalTo(7571720))
                .body("utrs[0].end", equalTo(7572926))
                .body("utrs[0].strand", equalTo(-1))
                .body("utrs[1].type", equalTo("five_prime_UTR"))
                .body("utrs[1].start", equalTo(7579913))
                .body("utrs[1].end", equalTo(7579940))
                .body("utrs[1].strand", equalTo(-1))
                .body("utrs[2].type", equalTo("five_prime_UTR"))
                .body("utrs[2].start", equalTo(7590695))
                .body("utrs[2].end", equalTo(7590856))
                .body("utrs[2].strand", equalTo(-1))
                .body("uniprotId", equalTo("P04637"))
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

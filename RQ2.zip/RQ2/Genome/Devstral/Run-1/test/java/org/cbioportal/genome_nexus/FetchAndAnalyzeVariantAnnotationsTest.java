import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndAnalyzeVariantAnnotationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchVariantAnnotationByGenomicLocation() {
        Response response = given()
                .queryParam("isoformOverrideSource", "ensembl")
                .queryParam("token", "{\"source2\":\"token5\",\"source3\":\"token6\"}")
                .queryParam("fields", "[\"hotspots\",\"conservation\",\"disease\"]")
                .when()
                .get("/annotation/genomic/{genomicLocation:.+}")
                .then()
                .statusCode(-100)
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchCanonicalEnsemblTranscriptByHugoSymbol() {
        Response response = given()
                .when()
                .get("/ensembl/canonical-transcript/hgnc/BRCA1?isoformOverrideSource=refseq")
                .then()
                .statusCode(200)
                .body("transcriptId", equalTo("ENST00000357654"))
                .body("geneId", equalTo("ENSG00000012048"))
                .body("refseqMrnaId", equalTo("NM_007294"))
                .body("ccdsId", equalTo("CCDS11453"))
                .body("hugoSymbols", hasItem("BRCA1"))
                .body("proteinId", equalTo("ENSP00000350283"))
                .body("proteinLength", equalTo(1863))
                .body("pfamDomains", hasSize(5))
                .body("exons", hasSize(23))
                .body("utrs", hasSize(3))
                .body("uniprotId", equalTo("P38398"))
                .extract()
                .response();

        System.out.println(response.asString());
    }

    @Test
    public void fetchNucleotideContextAnnotationForTheVariant() {
        Response response = given()
                .when()
                .get("/nucleotide_context/{variant:.+}")
                .then()
                .statusCode(200)
                .extract()
                .response();

        System.out.println(response.asString());
    }
}

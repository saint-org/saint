import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FetchAndAnalyzeCuriousCasesTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.port = 9080;
    }

    @Test
    public void fetchAndAnalyzeCuriousCases() {
        // Fetch curious cases based on a given genomic location
        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/curious_cases/7%2C116411883%2C116411905%2CTTCTTTCTCTCTGTTTTAAGATC%2C-")
                .then()
                .statusCode(200)
                .body("genomicLocation", equalTo("7,116411883,116411905,TTCTTTCTCTCTGTTTTAAGATC,-"))
                .body("comment", equalTo("Potential Exon Skip Event common in Non-small Cell Lung Cancer"))
                .body("hugoGeneSymbol", equalTo("MET"))
                .extract()
                .response();

        // Fetch canonical Ensembl transcript by Hugo Symbol MET
        response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/ensembl/canonical-transcript/hgnc/TP53?isoformOverrideSource=uniprot")
                .then()
                .statusCode(200)
                .body("transcriptId", equalTo("ENST00000269305"))
                .body("geneId", equalTo("ENSG00000141510"))
                .body("refseqMrnaId", equalTo("NM_000546"))
                .body("ccdsId", equalTo("CCDS11118"))
                .body("hugoSymbols[0]", equalTo("TP53"))
                .body("proteinId", equalTo("ENSP00000269305"))
                .body("proteinLength", equalTo(393))
                .body("pfamDomains[0].pfamDomainId", equalTo("PF07710"))
                .body("pfamDomains[0].pfamDomainStart", equalTo(318))
                .body("pfamDomains[0].pfamDomainEnd", equalTo(358))
                .body("pfamDomains[1].pfamDomainId", equalTo("PF08563"))
                .body("pfamDomains[1].pfamDomainStart", equalTo(6))
                .body("pfamDomains[1].pfamDomainEnd", equalTo(29))
                .body("pfamDomains[2].pfamDomainId", equalTo("PF00870"))
                .body("pfamDomains[2].pfamDomainStart", equalTo(95))
                .body("pfamDomains[2].pfamDomainEnd", equalTo(288))
                .body("exons[0].exonId", equalTo("ENSE00003605891"))
                .body("exons[0].exonStart", equalTo(7571720))
                .body("exons[0].exonEnd", equalTo(7573008))
                .body("exons[0].rank", equalTo(11))
                .body("exons[0].strand", equalTo(-1))
                .body("exons[0].version", equalTo(1))
                .body("utrs[0].type", equalTo("three_prime_UTR"))
                .body("utrs[0].start", equalTo(7571720))
                .body("utrs[0].end", equalTo(7572926))
                .body("utrs[0].strand", equalTo(-1))
                .body("utrs[1].type", equalTo("five_prime_UTR"))
                .body("utrs[1].start", equalTo(7579913))
                .body("utrs[1].end", equalTo(7579940))
                .body("utrs[1].strand", equalTo(-1))
                .body("utrs[2].type", equalTo("five_prime_UTR"))
                .body("utrs[2].start", equalTo(7590695))
                .body("utrs[2].end", equalTo(7590856))
                .body("utrs[2].strand", equalTo(-1))
                .body("uniprotId", equalTo("P04637"))
                .extract()
                .response();

        // Fetch nucleotide context annotation for a given variant
        response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/nucleotide_context/7%2C116411883%2C116411905%2CTTCTTTCTCTCTGTTTTAAGATC%2C-")
                .then()
                .statusCode(200)
                .extract()
                .response();
    }
}

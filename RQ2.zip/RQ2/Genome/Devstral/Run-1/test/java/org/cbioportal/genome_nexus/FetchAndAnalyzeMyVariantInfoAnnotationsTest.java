import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FetchAndAnalyzeMyVariantInfoAnnotationsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/web-1.1.49-SNAPSHOT";
    }

    @Test
    public void fetchMyVariantInfoAnnotationData() {
        Response response = given()
                .when()
                .get("/my_variant_info/variant/7:g.140453136A>T")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertThat(responseBody, containsString("<!doctype html>"));
    }

    @Test
    public void fetchMyVariantInfoAnnotationForListOfVariants() {
        Response response = given()
                .header("Content-Type", "application/json")
                .body("[\"7:g.140453136A>T\", \"12:g.25398285C>A\"]")
                .when()
                .post("/my_variant_info/variant")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertThat(responseBody, containsString("{\"variant\":\"chr7:g.140453136A>T\""));
    }

    @Test
    public void fetchCanonicalEnsemblTranscriptByHugoSymbol() {
        Response response = given()
                .when()
                .get("/ensembl/canonical-transcript/hgnc/TP53?isoformOverrideSource=uniprot")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String responseBody = response.getBody().asString();
        assertThat(responseBody, containsString("{\"transcriptId\":\"ENST00000269305\""));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FetchAndComparePDBHeadersTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void fetchAndComparePDBHeaders() {
        // Fetch PDB header information for a given PDB ID
        Response response = given()
                .when()
                .get("/web-1.1.49-SNAPSHOT/pdb/header/1a37")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String pdbHeader1 = response.asString();

        // Fetch a list of PDB headers based on the provided PDB IDs
        Response responseList = given()
                .contentType("application/json")
                .body("[\"1a37\", \"1a4o\"]")
                .when()
                .post("/web-1.1.49-SNAPSHOT/pdb/header")
                .then()
                .statusCode(200)
                .extract()
                .response();

        String pdbHeaderList = responseList.asString();

        // Compare the PDB headers
        assertEquals(pdbHeader1, pdbHeaderList.substring(0, pdbHeader1.length()));
    }
}

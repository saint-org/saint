package com.example.restassured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SearchingForCountriesByDemonymAndCallingCodeTest {

    @Test
    public void searchingForCountriesByDemonymAndCallingCode() {
        // Retrieve countries by demonym
        Response demonymResponse = given()
                .when()
                .get("http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2/demonym/German?fields=name%2Ccapital%2Cpopulation%2Carea%2Ccurrency%2Clanguages%2Cdemonym%2Ccontinent%2Cregion%2Csubregion%2Cflag%2Cwikipedia%2Cwikipedia_url%2Ccia_factbook%2Ccia_factbook_url%2Citu_code%2Citu_dialing_code%2Ctimezones%2Ccurrencies%2Clanguages_codes%2Cneighboring_countries%2Cmember_of%2Ccapital_native%2Ccapital_romaji%2Cnative%2Cofficial_native%2Cofficial_romaji")
                .then()
                .statusCode(200)
                .extract().response();

        List<com.restcountries.restcountriesapi.models.Country> demonymCountries = demonymResponse.jsonPath().getList("countries", com.restcountries.restcountriesapi.models.Country.class);

        // Retrieve countries by calling code
        Response callingCodeResponse = given()
                .when()
                .get("http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2/callingcode/%2B49?fields=name%2Ccapital%2Cpopulation%2Carea%2Ccurrency%2Clanguages%2Cdemonym%2Ccontinent%2Cregion%2Csubregion%2Cflag%2Cwikipedia%2Cwikipedia_url%2Ccia_factbook%2Ccia_factbook_url%2Citu_code%2Citu_dialing_code%2Ctimezones%2Ccurrencies%2Clanguages_codes%2Cneighboring_countries%2Cmember_of%2Ccapital_native%2Ccapital_romaji%2Cnative%2Cofficial_native%2Cofficial_romaji")
                .then()
                .statusCode(404)
                .extract().response();

        List<com.restcountries.restcountriesapi.models.Country> callingCodeCountries = callingCodeResponse.jsonPath().getList("countries", com.restcountries.restcountriesapi.models.Country.class);

        // Combine results
        List<com.restcountries.restcountriesapi.models.Country> combinedCountries = new ArrayList<>();
        combinedCountries.addAll(demonymCountries);
        combinedCountries.addAll(callingCodeCountries);

        // Validate combined result
        assertEquals(2, combinedCountries.size(), "Expected 2 countries in the combined result");
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class RetrieveCountriesByRegionAndCurrencyTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";
        RestAssured.when().contentType(ContentType.URLENCODED);
    }

    @Test
    public void retrievingCountriesByRegionAndCurrency() {
        // Handle a POST request to doPOST() endpoint
        Response postResponse = given()
                .when()
                .post()
                .contentType(ContentType.URLENCODED)
                .body("regionalbloc", "EU")
                .body("currency", "EUR")
                .then()
                .statusCode(405);

        // Retrieve countries in the European Union using Euro as currency
        Response getResponse = given()
                .when()
                .get("/regionalbloc/EU?fields=")
                .then()
                .statusCode(200);

        // Verify the response
        Response response = getResponse.jsonPath().get("data");
        response.jsonPath().isArray().shouldBe(true);

        // Verify the first country in the response
        response.jsonPath().get(0).jsonPath().get("name").shouldBe("Åland Islands");
        response.jsonPath().get(0).jsonPath().get("alpha2Code").shouldBe("AX");
        response.jsonPath().get(0).jsonPath().get("alpha3Code").shouldBe("ALA");
        response.jsonPath().get(0).jsonPath().get("callingCodes").shouldBe("358");
        response.jsonPath().get(0).jsonPath().get("capital").shouldBe("Mariehamn");
        response.jsonPath().get(0).jsonPath().get("currencies[0].code").shouldBe("EUR");
        response.jsonPath().get(0).jsonPath().get("currencies[0].name").shouldBe("Euro");
        response.jsonPath().get(0).jsonPath().get("currencies[0].symbol").shouldBe("€");
        response.jsonPath().get(0).jsonPath().get("languages[0].iso639_1").shouldBe("sv");
        response.jsonPath().get(0).jsonPath().get("languages[0].iso639_2").shouldBe("swe");
        response.jsonPath().get(0).jsonPath().get("languages[0].name").shouldBe("Swedish");
        response.jsonPath().get(0).jsonPath().get("regionalBlocs[0].acronym").shouldBe("EU");
        response.jsonPath().get(0).jsonPath().get("regionalBlocs[0].name").shouldBe("European Union");
    }
}

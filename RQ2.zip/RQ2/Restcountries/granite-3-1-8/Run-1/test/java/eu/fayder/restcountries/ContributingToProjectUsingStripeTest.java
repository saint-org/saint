package com.example.stripeintegration;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class ContributingToProjectUsingStripeTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
        RestAssured.contentType = ContentType.URLENCODED;
    }

    @Test
    public void contributingToProjectUsingStripe() {
        Contribution contribution = new Contribution(100, "stripe_token_here");

        given()
                .contentType(ContentType.URLENCODED)
                .body(contribution.toString())
                .when()
                .post("/rest/contribute")
                .then()
                .statusCode(200)
                .log().all()
                .extract().response();

        // Assuming that the application logs the successful charge creation
        // and the response contains a success message or status
        // You may need to adjust the assertion based on the actual response structure
        // and logging mechanism used in the application.
        // Here, we are just checking the status code for now.
    }
}

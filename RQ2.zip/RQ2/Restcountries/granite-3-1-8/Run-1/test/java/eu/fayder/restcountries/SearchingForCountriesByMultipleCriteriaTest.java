package com.example.restassured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class SearchingForCountriesByMultipleCriteriaTest {

    @BeforeEach
    public void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";
    }

    @Test
    public void searchingForCountriesByMultipleCriteria() {
        Response responseByRegion = given()
                .when()
                .get("/region/Europe?fields=name%2Ccapital%2Cpopulation%2Carea%2Ccurrency%2Clanguages%2Ctimezones%2Ccurrencies%2Ccalling_codes")
                .then()
                .statusCode(200);

        Response responseByCapital = given()
                .when()
                .get("/capital/Paris?fields=name%2Ccapital%2Cpopulation%2Carea%2Ccurrency%2Clanguages%2Ctimezones%2Ccurrencies%2Ccalling_codes")
                .then()
                .statusCode(200);

        Response responseByLanguage = given()
                .when()
                .get("/lang/fr?fields=name%2Ccapital%2Cpopulation%2Carea%2Ccurrency%2Clanguages%2Ctimezones%2Ccurrencies_used%2Ccalling_codes")
                .then()
                .statusCode(200);

        // Assuming the combined result is a list of countries that meet all three criteria
        // This is a simplified example, as the actual implementation would require parsing the JSON response and comparing the data
        // For the purpose of this example, we'll just check if the status codes are 200
        responseByRegion.getBody().jsonPath().get("length()").isEqualTo(100); // Assuming there are 100 countries in Europe
        responseByCapital.getBody().jsonPath().get("length()").isEqualTo(10); // Assuming there are 10 countries with Paris as their capital
        responseByLanguage.getBody().jsonPath().get("length()").isEqualTo(28); // Assuming there are 28 countries where French is the official language
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

public class SearchCountriesByLanguageAndValidate {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080";
        RestAssured.basePath = "/restcountries-2.0.6-SNAPSHOT/rest/v2";
    }

    @Test
    public void retrieveCountriesWhereSpanishIsOfficialLanguage() {
        String endpoint = "/lang/es";
        String queryParam = "fields=name,region";

        Response response = given()
                .contentType(ContentType.JSON)
                .queryParam("fields", queryParam)
                .when()
                .get(endpoint)
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        response.jsonPath().getList("name").forEach(countryName -> {
            System.out.println("Country Name: " + countryName);
        });

        response.jsonPath().getList("region").forEach(region -> {
            System.out.println("Region: " + region);
        });

        response.then().body("name", hasSize(greaterThan(0)));
        response.then().body("region", hasSize(greaterThan(0)));
        response.then().body("name[0]", notNullValue());
        response.then().body("region[0]", notNullValue());
    }
}

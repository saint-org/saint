import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SearchCountriesBySubregion {

    @Test
    public void retrieveCountriesBySubregionExcludingFields() {
        RestAssured.baseURI = "http://localhost:9080";
        given()
                .baseUri("http://localhost:9080")
                .pathParam("subregion", "northern_europe")
                .queryParams("fields=name;population;area;currency;language;gdp;inflation;unemployment;latitude;longitude;timezone")
                .contentType(ContentType.JSON)
                .log().all()
                .when()
                .get("/restcountries-2.0.6-SNAPSHOT/rest/v2/subregion/{subregion}")
                .then()
                .statusCode(404)
                .body("message", equalTo("Not Found"));
    }
}

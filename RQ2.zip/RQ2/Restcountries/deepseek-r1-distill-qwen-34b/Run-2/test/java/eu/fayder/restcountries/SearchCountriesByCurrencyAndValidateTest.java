import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SearchCountriesByCurrencyAndValidateTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    void retrieveCountriesByCurrencyWithSpecificFields() {
        Response response = given()
                .contentType(ContentType.JSON)
                .when()
                .get("/rest/v2/currency/EUR?fields=name,region")
                .then()
                .statusCode(200)
                .extract().response();

        // Validate response content
        String jsonPath = "$[0].name";
        String countryName = response.jsonPath().getString(jsonPath);
        assertTrue(countryName != null && !countryName.isEmpty(), "Country name should not be empty");

        String regionPath = "$[0].region";
        String region = response.jsonPath().getString(regionPath);
        assertTrue(region != null && !region.isEmpty(), "Region should not be empty");

        // Verify the response is not empty
        String responseContent = response.getBody().asString();
        assertEquals("[{}]", responseContent, "Response should contain multiple country objects");
    }
}

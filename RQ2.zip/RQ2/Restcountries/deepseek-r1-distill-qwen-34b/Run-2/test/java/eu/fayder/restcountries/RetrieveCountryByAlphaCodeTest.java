import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

class RetrieveCountryByAlphaCodeTest {

    @Test
    void retrieveCountryDataByAlphaCodeWithSpecifiedFields() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2/alpha/GBR";

        given()
                .queryParam("fields", "name;region")
                .when()
                .get()
                .then()
                .statusCode(200)
                .and()
                .body("name", equalTo("United Kingdom of Great Britain and Northern Ireland"))
                .and()
                .body("region", equalTo("Europe"));
    }
}

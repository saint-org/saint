import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import java.util.List;
import java.util.Map;

public class RetrieveCountriesByRegionAndFilterFieldsTest {

    @Test
    public void retrieveCountryDataForEuropeWithSpecificFields() {
        // Set up the base URI
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2/region/Europe";

        // Send the GET request with query parameters
        Response response = given()
                .queryParam("fields", "name;population")
                .when()
                .get();

        // Verify the response status code
        response.then().statusCode(200);

        // Convert the response to a list of maps
        List<Map<String, Object>> countries = response.jsonPath().getList("");

        // Verify each country contains only the specified fields
        for (Map<String, Object> country : countries) {
            // Check that 'name' and 'population' fields are present
            country.forEach((key, value) -> {
                if (!key.equals("name") && !key.equals("population")) {
                    throw new RuntimeException("Unexpected field: " + key);
                }
            });
        }
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class RetrieveAllCountriesWithExclusionsTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseUri = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";
    }

    @Test
    public void retrieveAllCountriesExcludingFields() {
        Response response = given()
                .when()
                .get("/all?fields=all")
                .then()
                .statusCode(200)
                .extract().response();

        // Verify that the response contains all countries
        assertThat(response.jsonPath().getList("[]"), hasSize(250));

        // Verify that 'capital' and 'currency' fields are excluded
        response.jsonPath().getList("[]").forEach(country -> {
            assertThat(country, hasNoKey("capital"));
            assertThat(country, hasNoKey("currency"));
        });
    }
}

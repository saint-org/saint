import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class SearchCountriesByCapitalAndExcludeFieldsTest {

    @Test
    public void retrieveCountriesByCapitalWithExcludedFields() {
        // Set base URI
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";

        // Send GET request with query parameter
        Response response = given()
                .contentType(ContentType.JSON)
                .queryParam("exclude", "currency")
                .when()
                .get("/capital/Paris")
                .then()
                .statusCode(200)
                .extract().response();

        // Validate the JSON response
        response.then().body("name", equalTo("France"))
                .body("capital", equalTo("Paris"))
                .body("population", equalTo(66710000))
                .body("currency", notNullValue());
    }
}

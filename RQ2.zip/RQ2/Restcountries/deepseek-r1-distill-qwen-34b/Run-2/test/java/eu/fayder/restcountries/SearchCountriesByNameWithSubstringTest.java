import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;

@TestInstance(PER_CLASS)
public class SearchCountriesByNameWithSubstringTest {

    @BeforeEach
    void setup() {
        RestAssured.baseURI = "http://localhost:9080";
    }

    @Test
    void testRetrieveCountriesBySubstringName() {
        Response response = given()
                .queryParams("fullText", "False")
                .queryParams("fields", "name,capital,population")
                .when()
                .get("/restcountries-2.0.6-SNAPSHOT/rest/v2/name/Fran")
                .then()
                .statusCode(200)
                .extract().response();

        response.then().body("[0].name", notNullValue())
                .body("[0].capital", notNullValue())
                .body("[0].population", notNullValue());
    }
}

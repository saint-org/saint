import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ProcessPaymentContributionViaStripeTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    void processPaymentContribution_WhenValidContributionObjectSent_ShouldReturn415() {
        given()
            .header("Content-Type", "application/x-www-form-urlencoded")
        .when()
            .post("/rest/contribute")
        .then()
            .assertThatStatusCodeIs(415);
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import static io.restassured.RestAssured.given;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class RetrieveCountriesByAlphaCodesAndFilterTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2/alpha/";
    }

    @Test
    public void retrieveCountryDataWithFilteredFields() {
        given()
            .contentType(ContentType.JSON)
            .queryParam("codes", "FRA;DEU")
            .queryParam("fields", "name;capital")
        .when()
            .get()
        .then()
            .statusCode(200)
            .rootPath("$")
            .body("", hasSize(2))
            .body("[0].name", is("France"))
            .body("[0].capital", is("Paris"))
            .body("[1].name", is("Germany"))
            .body("[1].capital", is("Berlin"))
            .body("[0].population", is(nullValue()))
            .body("[1].population", is(nullValue()));
    }
}

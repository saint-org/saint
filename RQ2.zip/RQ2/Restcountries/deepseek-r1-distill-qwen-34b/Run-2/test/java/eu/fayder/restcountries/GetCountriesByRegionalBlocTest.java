import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.TestMethodOrder.MethodOrderer.OrderAnnotation;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
public class GetCountriesByRegionalBlocTest {

    private RequestSpecBuilder requestSpecBuilder;
    private static final String BASE_URI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";

    @BeforeEach
    void setUp() {
        requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setBaseUri(BASE_URI);
        requestSpecBuilder.setContentType(ContentType.JSON);
    }

    @Test
    public void testRetrieveCountriesByRegionalBlocWithSpecifiedFields() {
        // Create the request specification
        RestAssured.requestSpecification = requestSpecBuilder.build();

        // Send the GET request
        Response response = given()
                .queryParam("fields", "name;region")
                .when()
                .get("/rest/v2/regionalbloc/EEA")
                .then()
                .extract().response();

        // Verify the response status code
        response.then().statusCode(200);

        // Verify the response content
        response.then().body("status", is(200));
        response.then().body("message", is("OK"));
        response.then().body("region", is("Europe"));
        response.then().body("name", is("European Union"));
        response.then().body("countries.size()", greaterThan(0));
        response.then().body("countries[*].name", hasItems("Austria", "Belgium", "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Ireland", "Italy", "Latvia", "Lithuania", "Luxembourg", "Malta", "Netherlands", "Poland", "Portugal", "Romania", "Slovakia", "Slovenia", "Spain", "Sweden"));

        // Verify the response is not null and is JSON
        response.then().assertThat().body(notNullValue());
        response.then().assertThat().contentType(ContentType.JSON);
    }
}

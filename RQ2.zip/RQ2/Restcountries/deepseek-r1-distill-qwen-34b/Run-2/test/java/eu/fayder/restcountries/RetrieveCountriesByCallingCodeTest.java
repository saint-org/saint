import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class RetrieveCountriesByCallingCodeTest {

    @Test
    public void retrieveCountryDataByCallingCodeWithSpecificFields() {
        RestAssured.baseURI = "http://localhost:9080";
        String endpoint = "/restcountries-2.0.6-SNAPSHOT/rest/v2/callingcode/33";
        String queryParam = "fields=name;region";

        Response response = given()
                .queryParam("fields", queryParam)
                .when()
                .get(endpoint)
                .then()
                .statusCode(200)
                .extract().response();

        response.then().body("[0].name", equalTo("France"))
                .and().body("[0].region", equalTo("Europe"));
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

public class PaymentProcessingWithMultipleCountryChecksTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    public void testPaymentProcessingWithMultipleCountryChecks() {
        // Process a contribution
        Response contributeResponse = given()
                .contentType(ContentType.URLENC)
                .when()
                .post("/rest/contribute")
                .then()
                .extract().response();
        
        assertEquals(415, contributeResponse.statusCode());

        // Retrieve country by capital
        Response getByCapitalResponse = given()
                .when()
                .get("/rest/v2/capital/Rome?fields=name%3Bcapital%3Bpopulation")
                .then()
                .extract().response();
        
        assertEquals(200, getByCapitalResponse.statusCode());
        assertTrue(getByCapitalResponse.jsonPath().getList("name").contains("Holy See"));
        assertTrue(getByCapitalResponse.jsonPath().getList("name").contains("Italy"));

        // Retrieve country by currency
        Response getByCurrencyResponse = given()
                .when()
                .get("/rest/v2/currency/EUR?fields=name%3Bcapital%3Bpopulation")
                .then()
                .extract().response();
        
        assertEquals(200, getByCurrencyResponse.statusCode());
        assertTrue(getByCurrencyResponse.jsonPath().getList("name").contains("France"));
        assertTrue(getByCurrencyResponse.jsonPath().getList("name").contains("Germany"));
    }
}

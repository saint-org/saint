import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;

public class BatchCountryRetrievalByAlphaCodes {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    public void retrieveMultipleCountriesUsingAlphaCodes() {
        String codes = "A;B;C";
        String fields = "name;capital";
        
        Response response = given()
                .contentType(ContentType.JSON)
                .queryParam("codes", codes)
                .queryParam("fields", fields)
                .when()
                .get("/rest/v2/alpha/")
                .then()
                .statusCode(200)
                .extract().response();

        // Verify the response contains the expected fields
        response.jsonPath().getList("name").forEach(name -> 
            System.out.println("Country name: " + name));
        response.jsonPath().getList("capital").forEach(capital -> 
            System.out.println("Capital: " + capital));
        
        // Additional validations can be added here if needed
    }
}

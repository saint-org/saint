import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.notNullValue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MultiEndpointCountryDataRetrievalTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    void testRetrieveAllCountries() {
        given()
                .contentType(ContentType.JSON)
                .when()
                .get("/rest/v2/all?fields=name%2Ccapital%2Cpopulation")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body(notNullValue());
    }

    @Test
    void testFilterCountriesByCurrency() {
        given()
                .contentType(ContentType.JSON)
                .when()
                .get("/rest/v2/currency/USD?fields=name%2Ccapital%2Cpopulation")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body(notNullValue());
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ErrorHandlingInCountrySearchTest {

    @Test
    public void testSearchWithInvalidAlphaCode() {
        // Set the base URI
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";

        // Send the GET request
        Response response = given()
                .when()
                .get("/rest/v2/alpha/invalidcode?fields=");

        // Verify the status code
        assertEquals(400, response.getStatusCode());

        // Verify the response content
        String status = response.jsonPath().getString("status");
        String message = response.jsonPath().getString("message");

        assertEquals("400", status);
        assertEquals("Bad Request", message);
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CountrySearchAndFilterByRegionAndLanguageTest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    void retrieveCountriesInEuropeRegionExcludingSpecifiedFields() {
        Response response = get("/rest/v2/region/Europe?fields=name%2Ccurrency");
        assertEquals(200, response.getStatusCode());
        response.then().contentType("application/json")
                .body("name", notNullValue())
                .body("currency", notNullValue());
    }

    @Test
    void retrieveCountriesThatSpeakEnglishExcludingSpecifiedFields() {
        Response response = get("/rest/v2/lang/en?fields=name%2Ccurrency");
        assertEquals(200, response.getStatusCode());
        response.then().contentType("application/json")
                .body("name", notNullValue())
                .body("currency", notNullValue());
    }
}

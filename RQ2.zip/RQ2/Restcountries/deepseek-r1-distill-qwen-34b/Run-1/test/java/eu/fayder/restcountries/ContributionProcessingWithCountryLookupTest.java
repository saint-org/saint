import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

class ContributionProcessingWithCountryLookupTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    void processContribution() {
        given()
                .contentType(ContentType.URLENC)
                .formParam("amount", "100")
                .formParam("currency", "USD")
                .formParam("email", "test@example.com")
                .when()
                .post("/rest/contribute")
                .then()
                .expectStatus(415);
    }

    @Test
    void retrieveCountryDetails() {
        Response response = given()
                .contentType(ContentType.JSON)
                .when()
                .get("/rest/v2/alpha/US?fields=name")
                .then()
                .expectStatus(200)
                .extract().response();

        String countryName = response.jsonPath().getString("name");
        assert countryName.equals("United States of America");
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CombiningRegionAndSubregionSearchTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";
    }

    @Test
    public void retrieveCountriesInAsiaRegionExcludingSpecifiedFields() {
        String endpoint = "/region/asia?fields=name%2Ccapital%2Cpopulation";
        
        Response response = given()
                .contentType(ContentType.JSON)
                .when()
                .get(endpoint)
                .then()
                .statusCode(200)
                .extract().response();

        assertEquals(200, response.statusCode());
        // Add more assertions for the response body if needed
    }

    @Test
    public void retrieveCountriesInSouthAsiaSubregionWithSpecifiedFields() {
        String endpoint = "/subregion/south_america?fields=name%3Bcapital%3Bpopulation";
        
        Response response = given()
                .contentType(ContentType.JSON)
                .when()
                .get(endpoint)
                .then()
                .statusCode(404)
                .extract().response();

        assertEquals(404, response.statusCode());
        assertEquals("Not Found", response.jsonPath().getString("message"));
    }
}

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PaymentContributionWithCountryValidation {

    static {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT";
    }

    @Test
    public void testUserAttemptsToContribute() {
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .post("/rest/contribute");
        
        assertEquals(415, response.getStatusCode());
    }

    @Test
    public void testValidateUsersCountryUsingCallingCode() {
        Response response = given()
                .get("/rest/v2/callingcode/+1?fields=all");
        
        assertEquals(404, response.getStatusCode());
        assertEquals("{\"status\":404,\"message\":\"Not Found\"}", response.getBody().asString());
    }
}

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AdvancedCountrySearchTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost:9080/restcountries-2.0.6-SNAPSHOT/rest/v2";
    }

    @Test
    public void testSearchCountriesByName() {
        given()
                .queryParam("fullText", "false")
                .queryParam("fields", "name;capital;population")
                .when()
                .get("/name/United%20States")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("[0].name", containsString("United States Minor Outlying Islands"))
                .body("[1].name", containsString("United States of America"))
                .body("[0].capital", equalTo(""))
                .body("[1].capital", containsString("Washington, D.C."))
                .body("[0].population", equalTo(300))
                .body("[1].population", equalTo(323947000));
    }

    @Test
    public void testFilterCountriesByRegionalBloc() {
        given()
                .queryParam("fields", "name;capital;population")
                .when()
                .get("/regionalbloc/UN")
                .then()
                .statusCode(404)
                .contentType(ContentType.JSON)
                .body("status", equalTo(404))
                .body("message", equalTo("Not Found"));
    }
}
